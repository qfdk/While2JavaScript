var nil;

function f0 (ret, v0, v1) {
	var v0;
	var v1;
	
	
	var tampon = new Array();
	tampon.push(v1);
	
	var valRet = new Array();
	f1(valRet, v0, v1);
	tampon.push(valRet[0]);
	
	v0 = tampon[0];
	v1 = tampon[1];
	

	ret.push(v0);
	ret.push(v1);
	return ret;
}

function f1 (ret, v0, v1) {
	var v2;
	var v1;
	var v0;
	
	
	var cpt0 = v0.countRight();
	for (var i0 = 0; i0 < cpt0; i0++){
		
		var cpt1 = v1.countRight();
		for (var i1 = 0; i1 < cpt1; i1++){
			
			var tampon = new Array();
			tampon.push(new Tree("cons", nil, v2));
			v2 = tampon[0];
			
			
			console.log("Nop");
			
		}
		
	}
	

	ret.push(v2);
	return ret;
}

