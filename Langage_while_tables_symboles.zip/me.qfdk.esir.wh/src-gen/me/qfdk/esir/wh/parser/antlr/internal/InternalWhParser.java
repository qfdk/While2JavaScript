package me.qfdk.esir.wh.parser.antlr.internal; 

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import me.qfdk.esir.wh.services.WhGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
@SuppressWarnings("all")
public class InternalWhParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_SYMBOL", "RULE_VARIABLE", "RULE_ID", "RULE_INT", "RULE_STRING", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'function'", "':'", "'read'", "'%'", "'write'", "','", "';'", "'nop'", "':='", "'while'", "'do'", "'od'", "'for'", "'if'", "'then'", "'else'", "'fi'", "'foreach'", "'in'", "'nil'", "'('", "'cons'", "')'", "'list'", "'hd'", "'tl'", "'and'", "'or'", "'not'", "'=?'"
    };
    public static final int T__42=42;
    public static final int RULE_ID=6;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__29=29;
    public static final int T__28=28;
    public static final int T__27=27;
    public static final int T__26=26;
    public static final int T__25=25;
    public static final int T__24=24;
    public static final int T__23=23;
    public static final int T__22=22;
    public static final int RULE_ANY_OTHER=12;
    public static final int T__21=21;
    public static final int T__20=20;
    public static final int RULE_SL_COMMENT=10;
    public static final int EOF=-1;
    public static final int RULE_ML_COMMENT=9;
    public static final int T__30=30;
    public static final int T__19=19;
    public static final int T__31=31;
    public static final int RULE_STRING=8;
    public static final int T__32=32;
    public static final int T__33=33;
    public static final int T__16=16;
    public static final int T__34=34;
    public static final int T__15=15;
    public static final int T__35=35;
    public static final int T__18=18;
    public static final int RULE_VARIABLE=5;
    public static final int T__36=36;
    public static final int T__17=17;
    public static final int T__37=37;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__14=14;
    public static final int T__13=13;
    public static final int RULE_INT=7;
    public static final int RULE_SYMBOL=4;
    public static final int RULE_WS=11;

    // delegates
    // delegators


        public InternalWhParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalWhParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalWhParser.tokenNames; }
    public String getGrammarFileName() { return "../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g"; }



     	private WhGrammarAccess grammarAccess;
     	
        public InternalWhParser(TokenStream input, WhGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }
        
        @Override
        protected String getFirstRuleName() {
        	return "wh";	
       	}
       	
       	@Override
       	protected WhGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}



    // $ANTLR start "entryRulewh"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:67:1: entryRulewh returns [EObject current=null] : iv_rulewh= rulewh EOF ;
    public final EObject entryRulewh() throws RecognitionException {
        EObject current = null;

        EObject iv_rulewh = null;


        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:68:2: (iv_rulewh= rulewh EOF )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:69:2: iv_rulewh= rulewh EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getWhRule()); 
            }
            pushFollow(FOLLOW_rulewh_in_entryRulewh75);
            iv_rulewh=rulewh();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulewh; 
            }
            match(input,EOF,FOLLOW_EOF_in_entryRulewh85); if (state.failed) return current;

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulewh"


    // $ANTLR start "rulewh"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:76:1: rulewh returns [EObject current=null] : ( (lv_elements_0_0= ruleFunction ) )* ;
    public final EObject rulewh() throws RecognitionException {
        EObject current = null;

        EObject lv_elements_0_0 = null;


         enterRule(); 
            
        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:79:28: ( ( (lv_elements_0_0= ruleFunction ) )* )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:80:1: ( (lv_elements_0_0= ruleFunction ) )*
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:80:1: ( (lv_elements_0_0= ruleFunction ) )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==13) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:81:1: (lv_elements_0_0= ruleFunction )
            	    {
            	    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:81:1: (lv_elements_0_0= ruleFunction )
            	    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:82:3: lv_elements_0_0= ruleFunction
            	    {
            	    if ( state.backtracking==0 ) {
            	       
            	      	        newCompositeNode(grammarAccess.getWhAccess().getElementsFunctionParserRuleCall_0()); 
            	      	    
            	    }
            	    pushFollow(FOLLOW_ruleFunction_in_rulewh130);
            	    lv_elements_0_0=ruleFunction();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      	        if (current==null) {
            	      	            current = createModelElementForParent(grammarAccess.getWhRule());
            	      	        }
            	             		add(
            	             			current, 
            	             			"elements",
            	              		lv_elements_0_0, 
            	              		"Function");
            	      	        afterParserOrEnumRuleCall();
            	      	    
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);


            }

            if ( state.backtracking==0 ) {
               leaveRule(); 
            }
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "rulewh"


    // $ANTLR start "entryRuleFunction"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:106:1: entryRuleFunction returns [EObject current=null] : iv_ruleFunction= ruleFunction EOF ;
    public final EObject entryRuleFunction() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFunction = null;


        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:107:2: (iv_ruleFunction= ruleFunction EOF )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:108:2: iv_ruleFunction= ruleFunction EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getFunctionRule()); 
            }
            pushFollow(FOLLOW_ruleFunction_in_entryRuleFunction166);
            iv_ruleFunction=ruleFunction();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleFunction; 
            }
            match(input,EOF,FOLLOW_EOF_in_entryRuleFunction176); if (state.failed) return current;

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFunction"


    // $ANTLR start "ruleFunction"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:115:1: ruleFunction returns [EObject current=null] : (otherlv_0= 'function' ( (lv_name_1_0= RULE_SYMBOL ) ) otherlv_2= ':' ( (lv_def_3_0= ruleDefinition ) ) ) ;
    public final EObject ruleFunction() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        EObject lv_def_3_0 = null;


         enterRule(); 
            
        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:118:28: ( (otherlv_0= 'function' ( (lv_name_1_0= RULE_SYMBOL ) ) otherlv_2= ':' ( (lv_def_3_0= ruleDefinition ) ) ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:119:1: (otherlv_0= 'function' ( (lv_name_1_0= RULE_SYMBOL ) ) otherlv_2= ':' ( (lv_def_3_0= ruleDefinition ) ) )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:119:1: (otherlv_0= 'function' ( (lv_name_1_0= RULE_SYMBOL ) ) otherlv_2= ':' ( (lv_def_3_0= ruleDefinition ) ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:119:3: otherlv_0= 'function' ( (lv_name_1_0= RULE_SYMBOL ) ) otherlv_2= ':' ( (lv_def_3_0= ruleDefinition ) )
            {
            otherlv_0=(Token)match(input,13,FOLLOW_13_in_ruleFunction213); if (state.failed) return current;
            if ( state.backtracking==0 ) {

                  	newLeafNode(otherlv_0, grammarAccess.getFunctionAccess().getFunctionKeyword_0());
                  
            }
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:123:1: ( (lv_name_1_0= RULE_SYMBOL ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:124:1: (lv_name_1_0= RULE_SYMBOL )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:124:1: (lv_name_1_0= RULE_SYMBOL )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:125:3: lv_name_1_0= RULE_SYMBOL
            {
            lv_name_1_0=(Token)match(input,RULE_SYMBOL,FOLLOW_RULE_SYMBOL_in_ruleFunction230); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(lv_name_1_0, grammarAccess.getFunctionAccess().getNameSYMBOLTerminalRuleCall_1_0()); 
              		
            }
            if ( state.backtracking==0 ) {

              	        if (current==null) {
              	            current = createModelElement(grammarAccess.getFunctionRule());
              	        }
                     		setWithLastConsumed(
                     			current, 
                     			"name",
                      		lv_name_1_0, 
                      		"SYMBOL");
              	    
            }

            }


            }

            otherlv_2=(Token)match(input,14,FOLLOW_14_in_ruleFunction247); if (state.failed) return current;
            if ( state.backtracking==0 ) {

                  	newLeafNode(otherlv_2, grammarAccess.getFunctionAccess().getColonKeyword_2());
                  
            }
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:145:1: ( (lv_def_3_0= ruleDefinition ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:146:1: (lv_def_3_0= ruleDefinition )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:146:1: (lv_def_3_0= ruleDefinition )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:147:3: lv_def_3_0= ruleDefinition
            {
            if ( state.backtracking==0 ) {
               
              	        newCompositeNode(grammarAccess.getFunctionAccess().getDefDefinitionParserRuleCall_3_0()); 
              	    
            }
            pushFollow(FOLLOW_ruleDefinition_in_ruleFunction268);
            lv_def_3_0=ruleDefinition();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              	        if (current==null) {
              	            current = createModelElementForParent(grammarAccess.getFunctionRule());
              	        }
                     		add(
                     			current, 
                     			"def",
                      		lv_def_3_0, 
                      		"Definition");
              	        afterParserOrEnumRuleCall();
              	    
            }

            }


            }


            }


            }

            if ( state.backtracking==0 ) {
               leaveRule(); 
            }
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFunction"


    // $ANTLR start "entryRuleDefinition"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:171:1: entryRuleDefinition returns [EObject current=null] : iv_ruleDefinition= ruleDefinition EOF ;
    public final EObject entryRuleDefinition() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDefinition = null;


        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:172:2: (iv_ruleDefinition= ruleDefinition EOF )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:173:2: iv_ruleDefinition= ruleDefinition EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getDefinitionRule()); 
            }
            pushFollow(FOLLOW_ruleDefinition_in_entryRuleDefinition304);
            iv_ruleDefinition=ruleDefinition();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleDefinition; 
            }
            match(input,EOF,FOLLOW_EOF_in_entryRuleDefinition314); if (state.failed) return current;

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDefinition"


    // $ANTLR start "ruleDefinition"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:180:1: ruleDefinition returns [EObject current=null] : (otherlv_0= 'read' ( (lv_entree_1_0= ruleInput ) ) otherlv_2= '%' ( (lv_cmd_3_0= ruleCommands ) ) otherlv_4= '%' otherlv_5= 'write' ( (lv_sortie_6_0= ruleOutput ) ) ) ;
    public final EObject ruleDefinition() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        EObject lv_entree_1_0 = null;

        EObject lv_cmd_3_0 = null;

        EObject lv_sortie_6_0 = null;


         enterRule(); 
            
        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:183:28: ( (otherlv_0= 'read' ( (lv_entree_1_0= ruleInput ) ) otherlv_2= '%' ( (lv_cmd_3_0= ruleCommands ) ) otherlv_4= '%' otherlv_5= 'write' ( (lv_sortie_6_0= ruleOutput ) ) ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:184:1: (otherlv_0= 'read' ( (lv_entree_1_0= ruleInput ) ) otherlv_2= '%' ( (lv_cmd_3_0= ruleCommands ) ) otherlv_4= '%' otherlv_5= 'write' ( (lv_sortie_6_0= ruleOutput ) ) )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:184:1: (otherlv_0= 'read' ( (lv_entree_1_0= ruleInput ) ) otherlv_2= '%' ( (lv_cmd_3_0= ruleCommands ) ) otherlv_4= '%' otherlv_5= 'write' ( (lv_sortie_6_0= ruleOutput ) ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:184:3: otherlv_0= 'read' ( (lv_entree_1_0= ruleInput ) ) otherlv_2= '%' ( (lv_cmd_3_0= ruleCommands ) ) otherlv_4= '%' otherlv_5= 'write' ( (lv_sortie_6_0= ruleOutput ) )
            {
            otherlv_0=(Token)match(input,15,FOLLOW_15_in_ruleDefinition351); if (state.failed) return current;
            if ( state.backtracking==0 ) {

                  	newLeafNode(otherlv_0, grammarAccess.getDefinitionAccess().getReadKeyword_0());
                  
            }
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:188:1: ( (lv_entree_1_0= ruleInput ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:189:1: (lv_entree_1_0= ruleInput )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:189:1: (lv_entree_1_0= ruleInput )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:190:3: lv_entree_1_0= ruleInput
            {
            if ( state.backtracking==0 ) {
               
              	        newCompositeNode(grammarAccess.getDefinitionAccess().getEntreeInputParserRuleCall_1_0()); 
              	    
            }
            pushFollow(FOLLOW_ruleInput_in_ruleDefinition372);
            lv_entree_1_0=ruleInput();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              	        if (current==null) {
              	            current = createModelElementForParent(grammarAccess.getDefinitionRule());
              	        }
                     		add(
                     			current, 
                     			"entree",
                      		lv_entree_1_0, 
                      		"Input");
              	        afterParserOrEnumRuleCall();
              	    
            }

            }


            }

            otherlv_2=(Token)match(input,16,FOLLOW_16_in_ruleDefinition384); if (state.failed) return current;
            if ( state.backtracking==0 ) {

                  	newLeafNode(otherlv_2, grammarAccess.getDefinitionAccess().getPercentSignKeyword_2());
                  
            }
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:210:1: ( (lv_cmd_3_0= ruleCommands ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:211:1: (lv_cmd_3_0= ruleCommands )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:211:1: (lv_cmd_3_0= ruleCommands )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:212:3: lv_cmd_3_0= ruleCommands
            {
            if ( state.backtracking==0 ) {
               
              	        newCompositeNode(grammarAccess.getDefinitionAccess().getCmdCommandsParserRuleCall_3_0()); 
              	    
            }
            pushFollow(FOLLOW_ruleCommands_in_ruleDefinition405);
            lv_cmd_3_0=ruleCommands();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              	        if (current==null) {
              	            current = createModelElementForParent(grammarAccess.getDefinitionRule());
              	        }
                     		add(
                     			current, 
                     			"cmd",
                      		lv_cmd_3_0, 
                      		"Commands");
              	        afterParserOrEnumRuleCall();
              	    
            }

            }


            }

            otherlv_4=(Token)match(input,16,FOLLOW_16_in_ruleDefinition417); if (state.failed) return current;
            if ( state.backtracking==0 ) {

                  	newLeafNode(otherlv_4, grammarAccess.getDefinitionAccess().getPercentSignKeyword_4());
                  
            }
            otherlv_5=(Token)match(input,17,FOLLOW_17_in_ruleDefinition429); if (state.failed) return current;
            if ( state.backtracking==0 ) {

                  	newLeafNode(otherlv_5, grammarAccess.getDefinitionAccess().getWriteKeyword_5());
                  
            }
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:236:1: ( (lv_sortie_6_0= ruleOutput ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:237:1: (lv_sortie_6_0= ruleOutput )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:237:1: (lv_sortie_6_0= ruleOutput )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:238:3: lv_sortie_6_0= ruleOutput
            {
            if ( state.backtracking==0 ) {
               
              	        newCompositeNode(grammarAccess.getDefinitionAccess().getSortieOutputParserRuleCall_6_0()); 
              	    
            }
            pushFollow(FOLLOW_ruleOutput_in_ruleDefinition450);
            lv_sortie_6_0=ruleOutput();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              	        if (current==null) {
              	            current = createModelElementForParent(grammarAccess.getDefinitionRule());
              	        }
                     		add(
                     			current, 
                     			"sortie",
                      		lv_sortie_6_0, 
                      		"Output");
              	        afterParserOrEnumRuleCall();
              	    
            }

            }


            }


            }


            }

            if ( state.backtracking==0 ) {
               leaveRule(); 
            }
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDefinition"


    // $ANTLR start "entryRuleInput"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:262:1: entryRuleInput returns [EObject current=null] : iv_ruleInput= ruleInput EOF ;
    public final EObject entryRuleInput() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInput = null;


        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:263:2: (iv_ruleInput= ruleInput EOF )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:264:2: iv_ruleInput= ruleInput EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getInputRule()); 
            }
            pushFollow(FOLLOW_ruleInput_in_entryRuleInput486);
            iv_ruleInput=ruleInput();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleInput; 
            }
            match(input,EOF,FOLLOW_EOF_in_entryRuleInput496); if (state.failed) return current;

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInput"


    // $ANTLR start "ruleInput"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:271:1: ruleInput returns [EObject current=null] : ( ( ( (lv_name_0_0= RULE_VARIABLE ) ) otherlv_1= ',' ( (lv_entree_2_0= ruleInput ) ) ) | ( (lv_name_3_0= RULE_VARIABLE ) ) ) ;
    public final EObject ruleInput() throws RecognitionException {
        EObject current = null;

        Token lv_name_0_0=null;
        Token otherlv_1=null;
        Token lv_name_3_0=null;
        EObject lv_entree_2_0 = null;


         enterRule(); 
            
        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:274:28: ( ( ( ( (lv_name_0_0= RULE_VARIABLE ) ) otherlv_1= ',' ( (lv_entree_2_0= ruleInput ) ) ) | ( (lv_name_3_0= RULE_VARIABLE ) ) ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:275:1: ( ( ( (lv_name_0_0= RULE_VARIABLE ) ) otherlv_1= ',' ( (lv_entree_2_0= ruleInput ) ) ) | ( (lv_name_3_0= RULE_VARIABLE ) ) )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:275:1: ( ( ( (lv_name_0_0= RULE_VARIABLE ) ) otherlv_1= ',' ( (lv_entree_2_0= ruleInput ) ) ) | ( (lv_name_3_0= RULE_VARIABLE ) ) )
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==RULE_VARIABLE) ) {
                int LA2_1 = input.LA(2);

                if ( (LA2_1==18) ) {
                    alt2=1;
                }
                else if ( (LA2_1==EOF||LA2_1==16) ) {
                    alt2=2;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return current;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 2, 1, input);

                    throw nvae;
                }
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }
            switch (alt2) {
                case 1 :
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:275:2: ( ( (lv_name_0_0= RULE_VARIABLE ) ) otherlv_1= ',' ( (lv_entree_2_0= ruleInput ) ) )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:275:2: ( ( (lv_name_0_0= RULE_VARIABLE ) ) otherlv_1= ',' ( (lv_entree_2_0= ruleInput ) ) )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:275:3: ( (lv_name_0_0= RULE_VARIABLE ) ) otherlv_1= ',' ( (lv_entree_2_0= ruleInput ) )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:275:3: ( (lv_name_0_0= RULE_VARIABLE ) )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:276:1: (lv_name_0_0= RULE_VARIABLE )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:276:1: (lv_name_0_0= RULE_VARIABLE )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:277:3: lv_name_0_0= RULE_VARIABLE
                    {
                    lv_name_0_0=(Token)match(input,RULE_VARIABLE,FOLLOW_RULE_VARIABLE_in_ruleInput539); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			newLeafNode(lv_name_0_0, grammarAccess.getInputAccess().getNameVARIABLETerminalRuleCall_0_0_0()); 
                      		
                    }
                    if ( state.backtracking==0 ) {

                      	        if (current==null) {
                      	            current = createModelElement(grammarAccess.getInputRule());
                      	        }
                             		setWithLastConsumed(
                             			current, 
                             			"name",
                              		lv_name_0_0, 
                              		"VARIABLE");
                      	    
                    }

                    }


                    }

                    otherlv_1=(Token)match(input,18,FOLLOW_18_in_ruleInput556); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                          	newLeafNode(otherlv_1, grammarAccess.getInputAccess().getCommaKeyword_0_1());
                          
                    }
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:297:1: ( (lv_entree_2_0= ruleInput ) )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:298:1: (lv_entree_2_0= ruleInput )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:298:1: (lv_entree_2_0= ruleInput )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:299:3: lv_entree_2_0= ruleInput
                    {
                    if ( state.backtracking==0 ) {
                       
                      	        newCompositeNode(grammarAccess.getInputAccess().getEntreeInputParserRuleCall_0_2_0()); 
                      	    
                    }
                    pushFollow(FOLLOW_ruleInput_in_ruleInput577);
                    lv_entree_2_0=ruleInput();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      	        if (current==null) {
                      	            current = createModelElementForParent(grammarAccess.getInputRule());
                      	        }
                             		add(
                             			current, 
                             			"entree",
                              		lv_entree_2_0, 
                              		"Input");
                      	        afterParserOrEnumRuleCall();
                      	    
                    }

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:316:6: ( (lv_name_3_0= RULE_VARIABLE ) )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:316:6: ( (lv_name_3_0= RULE_VARIABLE ) )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:317:1: (lv_name_3_0= RULE_VARIABLE )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:317:1: (lv_name_3_0= RULE_VARIABLE )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:318:3: lv_name_3_0= RULE_VARIABLE
                    {
                    lv_name_3_0=(Token)match(input,RULE_VARIABLE,FOLLOW_RULE_VARIABLE_in_ruleInput601); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			newLeafNode(lv_name_3_0, grammarAccess.getInputAccess().getNameVARIABLETerminalRuleCall_1_0()); 
                      		
                    }
                    if ( state.backtracking==0 ) {

                      	        if (current==null) {
                      	            current = createModelElement(grammarAccess.getInputRule());
                      	        }
                             		setWithLastConsumed(
                             			current, 
                             			"name",
                              		lv_name_3_0, 
                              		"VARIABLE");
                      	    
                    }

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {
               leaveRule(); 
            }
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInput"


    // $ANTLR start "entryRuleOutput"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:342:1: entryRuleOutput returns [EObject current=null] : iv_ruleOutput= ruleOutput EOF ;
    public final EObject entryRuleOutput() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleOutput = null;


        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:343:2: (iv_ruleOutput= ruleOutput EOF )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:344:2: iv_ruleOutput= ruleOutput EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getOutputRule()); 
            }
            pushFollow(FOLLOW_ruleOutput_in_entryRuleOutput642);
            iv_ruleOutput=ruleOutput();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleOutput; 
            }
            match(input,EOF,FOLLOW_EOF_in_entryRuleOutput652); if (state.failed) return current;

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleOutput"


    // $ANTLR start "ruleOutput"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:351:1: ruleOutput returns [EObject current=null] : ( ( ( (lv_name_0_0= RULE_VARIABLE ) ) otherlv_1= ',' ( (lv_sortie_2_0= ruleOutput ) ) ) | ( (lv_name_3_0= RULE_VARIABLE ) ) ) ;
    public final EObject ruleOutput() throws RecognitionException {
        EObject current = null;

        Token lv_name_0_0=null;
        Token otherlv_1=null;
        Token lv_name_3_0=null;
        EObject lv_sortie_2_0 = null;


         enterRule(); 
            
        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:354:28: ( ( ( ( (lv_name_0_0= RULE_VARIABLE ) ) otherlv_1= ',' ( (lv_sortie_2_0= ruleOutput ) ) ) | ( (lv_name_3_0= RULE_VARIABLE ) ) ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:355:1: ( ( ( (lv_name_0_0= RULE_VARIABLE ) ) otherlv_1= ',' ( (lv_sortie_2_0= ruleOutput ) ) ) | ( (lv_name_3_0= RULE_VARIABLE ) ) )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:355:1: ( ( ( (lv_name_0_0= RULE_VARIABLE ) ) otherlv_1= ',' ( (lv_sortie_2_0= ruleOutput ) ) ) | ( (lv_name_3_0= RULE_VARIABLE ) ) )
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==RULE_VARIABLE) ) {
                int LA3_1 = input.LA(2);

                if ( (LA3_1==EOF||LA3_1==13) ) {
                    alt3=2;
                }
                else if ( (LA3_1==18) ) {
                    alt3=1;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return current;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 3, 1, input);

                    throw nvae;
                }
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }
            switch (alt3) {
                case 1 :
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:355:2: ( ( (lv_name_0_0= RULE_VARIABLE ) ) otherlv_1= ',' ( (lv_sortie_2_0= ruleOutput ) ) )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:355:2: ( ( (lv_name_0_0= RULE_VARIABLE ) ) otherlv_1= ',' ( (lv_sortie_2_0= ruleOutput ) ) )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:355:3: ( (lv_name_0_0= RULE_VARIABLE ) ) otherlv_1= ',' ( (lv_sortie_2_0= ruleOutput ) )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:355:3: ( (lv_name_0_0= RULE_VARIABLE ) )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:356:1: (lv_name_0_0= RULE_VARIABLE )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:356:1: (lv_name_0_0= RULE_VARIABLE )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:357:3: lv_name_0_0= RULE_VARIABLE
                    {
                    lv_name_0_0=(Token)match(input,RULE_VARIABLE,FOLLOW_RULE_VARIABLE_in_ruleOutput695); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			newLeafNode(lv_name_0_0, grammarAccess.getOutputAccess().getNameVARIABLETerminalRuleCall_0_0_0()); 
                      		
                    }
                    if ( state.backtracking==0 ) {

                      	        if (current==null) {
                      	            current = createModelElement(grammarAccess.getOutputRule());
                      	        }
                             		setWithLastConsumed(
                             			current, 
                             			"name",
                              		lv_name_0_0, 
                              		"VARIABLE");
                      	    
                    }

                    }


                    }

                    otherlv_1=(Token)match(input,18,FOLLOW_18_in_ruleOutput712); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                          	newLeafNode(otherlv_1, grammarAccess.getOutputAccess().getCommaKeyword_0_1());
                          
                    }
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:377:1: ( (lv_sortie_2_0= ruleOutput ) )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:378:1: (lv_sortie_2_0= ruleOutput )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:378:1: (lv_sortie_2_0= ruleOutput )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:379:3: lv_sortie_2_0= ruleOutput
                    {
                    if ( state.backtracking==0 ) {
                       
                      	        newCompositeNode(grammarAccess.getOutputAccess().getSortieOutputParserRuleCall_0_2_0()); 
                      	    
                    }
                    pushFollow(FOLLOW_ruleOutput_in_ruleOutput733);
                    lv_sortie_2_0=ruleOutput();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      	        if (current==null) {
                      	            current = createModelElementForParent(grammarAccess.getOutputRule());
                      	        }
                             		add(
                             			current, 
                             			"sortie",
                              		lv_sortie_2_0, 
                              		"Output");
                      	        afterParserOrEnumRuleCall();
                      	    
                    }

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:396:6: ( (lv_name_3_0= RULE_VARIABLE ) )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:396:6: ( (lv_name_3_0= RULE_VARIABLE ) )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:397:1: (lv_name_3_0= RULE_VARIABLE )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:397:1: (lv_name_3_0= RULE_VARIABLE )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:398:3: lv_name_3_0= RULE_VARIABLE
                    {
                    lv_name_3_0=(Token)match(input,RULE_VARIABLE,FOLLOW_RULE_VARIABLE_in_ruleOutput757); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			newLeafNode(lv_name_3_0, grammarAccess.getOutputAccess().getNameVARIABLETerminalRuleCall_1_0()); 
                      		
                    }
                    if ( state.backtracking==0 ) {

                      	        if (current==null) {
                      	            current = createModelElement(grammarAccess.getOutputRule());
                      	        }
                             		setWithLastConsumed(
                             			current, 
                             			"name",
                              		lv_name_3_0, 
                              		"VARIABLE");
                      	    
                    }

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {
               leaveRule(); 
            }
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleOutput"


    // $ANTLR start "entryRuleCommands"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:422:1: entryRuleCommands returns [EObject current=null] : iv_ruleCommands= ruleCommands EOF ;
    public final EObject entryRuleCommands() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCommands = null;


        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:423:2: (iv_ruleCommands= ruleCommands EOF )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:424:2: iv_ruleCommands= ruleCommands EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getCommandsRule()); 
            }
            pushFollow(FOLLOW_ruleCommands_in_entryRuleCommands798);
            iv_ruleCommands=ruleCommands();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleCommands; 
            }
            match(input,EOF,FOLLOW_EOF_in_entryRuleCommands808); if (state.failed) return current;

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCommands"


    // $ANTLR start "ruleCommands"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:431:1: ruleCommands returns [EObject current=null] : ( ( (lv_cmd1_0_0= ruleCommand ) ) (otherlv_1= ';' ( (lv_cmd_2_0= ruleCommands ) ) )? ) ;
    public final EObject ruleCommands() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        EObject lv_cmd1_0_0 = null;

        EObject lv_cmd_2_0 = null;


         enterRule(); 
            
        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:434:28: ( ( ( (lv_cmd1_0_0= ruleCommand ) ) (otherlv_1= ';' ( (lv_cmd_2_0= ruleCommands ) ) )? ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:435:1: ( ( (lv_cmd1_0_0= ruleCommand ) ) (otherlv_1= ';' ( (lv_cmd_2_0= ruleCommands ) ) )? )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:435:1: ( ( (lv_cmd1_0_0= ruleCommand ) ) (otherlv_1= ';' ( (lv_cmd_2_0= ruleCommands ) ) )? )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:435:2: ( (lv_cmd1_0_0= ruleCommand ) ) (otherlv_1= ';' ( (lv_cmd_2_0= ruleCommands ) ) )?
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:435:2: ( (lv_cmd1_0_0= ruleCommand ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:436:1: (lv_cmd1_0_0= ruleCommand )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:436:1: (lv_cmd1_0_0= ruleCommand )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:437:3: lv_cmd1_0_0= ruleCommand
            {
            if ( state.backtracking==0 ) {
               
              	        newCompositeNode(grammarAccess.getCommandsAccess().getCmd1CommandParserRuleCall_0_0()); 
              	    
            }
            pushFollow(FOLLOW_ruleCommand_in_ruleCommands854);
            lv_cmd1_0_0=ruleCommand();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              	        if (current==null) {
              	            current = createModelElementForParent(grammarAccess.getCommandsRule());
              	        }
                     		add(
                     			current, 
                     			"cmd1",
                      		lv_cmd1_0_0, 
                      		"Command");
              	        afterParserOrEnumRuleCall();
              	    
            }

            }


            }

            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:453:2: (otherlv_1= ';' ( (lv_cmd_2_0= ruleCommands ) ) )?
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==19) ) {
                alt4=1;
            }
            switch (alt4) {
                case 1 :
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:453:4: otherlv_1= ';' ( (lv_cmd_2_0= ruleCommands ) )
                    {
                    otherlv_1=(Token)match(input,19,FOLLOW_19_in_ruleCommands867); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                          	newLeafNode(otherlv_1, grammarAccess.getCommandsAccess().getSemicolonKeyword_1_0());
                          
                    }
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:457:1: ( (lv_cmd_2_0= ruleCommands ) )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:458:1: (lv_cmd_2_0= ruleCommands )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:458:1: (lv_cmd_2_0= ruleCommands )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:459:3: lv_cmd_2_0= ruleCommands
                    {
                    if ( state.backtracking==0 ) {
                       
                      	        newCompositeNode(grammarAccess.getCommandsAccess().getCmdCommandsParserRuleCall_1_1_0()); 
                      	    
                    }
                    pushFollow(FOLLOW_ruleCommands_in_ruleCommands888);
                    lv_cmd_2_0=ruleCommands();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      	        if (current==null) {
                      	            current = createModelElementForParent(grammarAccess.getCommandsRule());
                      	        }
                             		add(
                             			current, 
                             			"cmd",
                              		lv_cmd_2_0, 
                              		"Commands");
                      	        afterParserOrEnumRuleCall();
                      	    
                    }

                    }


                    }


                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {
               leaveRule(); 
            }
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCommands"


    // $ANTLR start "entryRuleCommand"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:483:1: entryRuleCommand returns [EObject current=null] : iv_ruleCommand= ruleCommand EOF ;
    public final EObject entryRuleCommand() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCommand = null;


        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:484:2: (iv_ruleCommand= ruleCommand EOF )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:485:2: iv_ruleCommand= ruleCommand EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getCommandRule()); 
            }
            pushFollow(FOLLOW_ruleCommand_in_entryRuleCommand926);
            iv_ruleCommand=ruleCommand();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleCommand; 
            }
            match(input,EOF,FOLLOW_EOF_in_entryRuleCommand936); if (state.failed) return current;

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCommand"


    // $ANTLR start "ruleCommand"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:492:1: ruleCommand returns [EObject current=null] : ( ( (lv_nop_0_0= 'nop' ) ) | ( (lv_affectation_1_0= ruleaffectation ) ) | ( (lv_whileCommand_2_0= rulewhileCommand ) ) | ( (lv_forCommand_3_0= ruleforCommand ) ) | ( (lv_ifCommand_4_0= ruleifCommand ) ) | ( (lv_foreachCommand_5_0= ruleforeachCommand ) ) ) ;
    public final EObject ruleCommand() throws RecognitionException {
        EObject current = null;

        Token lv_nop_0_0=null;
        EObject lv_affectation_1_0 = null;

        EObject lv_whileCommand_2_0 = null;

        EObject lv_forCommand_3_0 = null;

        EObject lv_ifCommand_4_0 = null;

        EObject lv_foreachCommand_5_0 = null;


         enterRule(); 
            
        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:495:28: ( ( ( (lv_nop_0_0= 'nop' ) ) | ( (lv_affectation_1_0= ruleaffectation ) ) | ( (lv_whileCommand_2_0= rulewhileCommand ) ) | ( (lv_forCommand_3_0= ruleforCommand ) ) | ( (lv_ifCommand_4_0= ruleifCommand ) ) | ( (lv_foreachCommand_5_0= ruleforeachCommand ) ) ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:496:1: ( ( (lv_nop_0_0= 'nop' ) ) | ( (lv_affectation_1_0= ruleaffectation ) ) | ( (lv_whileCommand_2_0= rulewhileCommand ) ) | ( (lv_forCommand_3_0= ruleforCommand ) ) | ( (lv_ifCommand_4_0= ruleifCommand ) ) | ( (lv_foreachCommand_5_0= ruleforeachCommand ) ) )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:496:1: ( ( (lv_nop_0_0= 'nop' ) ) | ( (lv_affectation_1_0= ruleaffectation ) ) | ( (lv_whileCommand_2_0= rulewhileCommand ) ) | ( (lv_forCommand_3_0= ruleforCommand ) ) | ( (lv_ifCommand_4_0= ruleifCommand ) ) | ( (lv_foreachCommand_5_0= ruleforeachCommand ) ) )
            int alt5=6;
            switch ( input.LA(1) ) {
            case 20:
                {
                alt5=1;
                }
                break;
            case RULE_VARIABLE:
                {
                alt5=2;
                }
                break;
            case 22:
                {
                alt5=3;
                }
                break;
            case 25:
                {
                alt5=4;
                }
                break;
            case 26:
                {
                alt5=5;
                }
                break;
            case 30:
                {
                alt5=6;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }

            switch (alt5) {
                case 1 :
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:496:2: ( (lv_nop_0_0= 'nop' ) )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:496:2: ( (lv_nop_0_0= 'nop' ) )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:497:1: (lv_nop_0_0= 'nop' )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:497:1: (lv_nop_0_0= 'nop' )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:498:3: lv_nop_0_0= 'nop'
                    {
                    lv_nop_0_0=(Token)match(input,20,FOLLOW_20_in_ruleCommand979); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                              newLeafNode(lv_nop_0_0, grammarAccess.getCommandAccess().getNopNopKeyword_0_0());
                          
                    }
                    if ( state.backtracking==0 ) {

                      	        if (current==null) {
                      	            current = createModelElement(grammarAccess.getCommandRule());
                      	        }
                             		setWithLastConsumed(current, "nop", lv_nop_0_0, "nop");
                      	    
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:512:6: ( (lv_affectation_1_0= ruleaffectation ) )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:512:6: ( (lv_affectation_1_0= ruleaffectation ) )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:513:1: (lv_affectation_1_0= ruleaffectation )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:513:1: (lv_affectation_1_0= ruleaffectation )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:514:3: lv_affectation_1_0= ruleaffectation
                    {
                    if ( state.backtracking==0 ) {
                       
                      	        newCompositeNode(grammarAccess.getCommandAccess().getAffectationAffectationParserRuleCall_1_0()); 
                      	    
                    }
                    pushFollow(FOLLOW_ruleaffectation_in_ruleCommand1019);
                    lv_affectation_1_0=ruleaffectation();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      	        if (current==null) {
                      	            current = createModelElementForParent(grammarAccess.getCommandRule());
                      	        }
                             		add(
                             			current, 
                             			"affectation",
                              		lv_affectation_1_0, 
                              		"affectation");
                      	        afterParserOrEnumRuleCall();
                      	    
                    }

                    }


                    }


                    }
                    break;
                case 3 :
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:531:6: ( (lv_whileCommand_2_0= rulewhileCommand ) )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:531:6: ( (lv_whileCommand_2_0= rulewhileCommand ) )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:532:1: (lv_whileCommand_2_0= rulewhileCommand )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:532:1: (lv_whileCommand_2_0= rulewhileCommand )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:533:3: lv_whileCommand_2_0= rulewhileCommand
                    {
                    if ( state.backtracking==0 ) {
                       
                      	        newCompositeNode(grammarAccess.getCommandAccess().getWhileCommandWhileCommandParserRuleCall_2_0()); 
                      	    
                    }
                    pushFollow(FOLLOW_rulewhileCommand_in_ruleCommand1046);
                    lv_whileCommand_2_0=rulewhileCommand();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      	        if (current==null) {
                      	            current = createModelElementForParent(grammarAccess.getCommandRule());
                      	        }
                             		add(
                             			current, 
                             			"whileCommand",
                              		lv_whileCommand_2_0, 
                              		"whileCommand");
                      	        afterParserOrEnumRuleCall();
                      	    
                    }

                    }


                    }


                    }
                    break;
                case 4 :
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:550:6: ( (lv_forCommand_3_0= ruleforCommand ) )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:550:6: ( (lv_forCommand_3_0= ruleforCommand ) )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:551:1: (lv_forCommand_3_0= ruleforCommand )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:551:1: (lv_forCommand_3_0= ruleforCommand )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:552:3: lv_forCommand_3_0= ruleforCommand
                    {
                    if ( state.backtracking==0 ) {
                       
                      	        newCompositeNode(grammarAccess.getCommandAccess().getForCommandForCommandParserRuleCall_3_0()); 
                      	    
                    }
                    pushFollow(FOLLOW_ruleforCommand_in_ruleCommand1073);
                    lv_forCommand_3_0=ruleforCommand();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      	        if (current==null) {
                      	            current = createModelElementForParent(grammarAccess.getCommandRule());
                      	        }
                             		add(
                             			current, 
                             			"forCommand",
                              		lv_forCommand_3_0, 
                              		"forCommand");
                      	        afterParserOrEnumRuleCall();
                      	    
                    }

                    }


                    }


                    }
                    break;
                case 5 :
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:569:6: ( (lv_ifCommand_4_0= ruleifCommand ) )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:569:6: ( (lv_ifCommand_4_0= ruleifCommand ) )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:570:1: (lv_ifCommand_4_0= ruleifCommand )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:570:1: (lv_ifCommand_4_0= ruleifCommand )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:571:3: lv_ifCommand_4_0= ruleifCommand
                    {
                    if ( state.backtracking==0 ) {
                       
                      	        newCompositeNode(grammarAccess.getCommandAccess().getIfCommandIfCommandParserRuleCall_4_0()); 
                      	    
                    }
                    pushFollow(FOLLOW_ruleifCommand_in_ruleCommand1100);
                    lv_ifCommand_4_0=ruleifCommand();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      	        if (current==null) {
                      	            current = createModelElementForParent(grammarAccess.getCommandRule());
                      	        }
                             		add(
                             			current, 
                             			"ifCommand",
                              		lv_ifCommand_4_0, 
                              		"ifCommand");
                      	        afterParserOrEnumRuleCall();
                      	    
                    }

                    }


                    }


                    }
                    break;
                case 6 :
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:588:6: ( (lv_foreachCommand_5_0= ruleforeachCommand ) )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:588:6: ( (lv_foreachCommand_5_0= ruleforeachCommand ) )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:589:1: (lv_foreachCommand_5_0= ruleforeachCommand )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:589:1: (lv_foreachCommand_5_0= ruleforeachCommand )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:590:3: lv_foreachCommand_5_0= ruleforeachCommand
                    {
                    if ( state.backtracking==0 ) {
                       
                      	        newCompositeNode(grammarAccess.getCommandAccess().getForeachCommandForeachCommandParserRuleCall_5_0()); 
                      	    
                    }
                    pushFollow(FOLLOW_ruleforeachCommand_in_ruleCommand1127);
                    lv_foreachCommand_5_0=ruleforeachCommand();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      	        if (current==null) {
                      	            current = createModelElementForParent(grammarAccess.getCommandRule());
                      	        }
                             		add(
                             			current, 
                             			"foreachCommand",
                              		lv_foreachCommand_5_0, 
                              		"foreachCommand");
                      	        afterParserOrEnumRuleCall();
                      	    
                    }

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {
               leaveRule(); 
            }
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCommand"


    // $ANTLR start "entryRuleaffectation"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:614:1: entryRuleaffectation returns [EObject current=null] : iv_ruleaffectation= ruleaffectation EOF ;
    public final EObject entryRuleaffectation() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleaffectation = null;


        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:615:2: (iv_ruleaffectation= ruleaffectation EOF )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:616:2: iv_ruleaffectation= ruleaffectation EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getAffectationRule()); 
            }
            pushFollow(FOLLOW_ruleaffectation_in_entryRuleaffectation1163);
            iv_ruleaffectation=ruleaffectation();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleaffectation; 
            }
            match(input,EOF,FOLLOW_EOF_in_entryRuleaffectation1173); if (state.failed) return current;

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleaffectation"


    // $ANTLR start "ruleaffectation"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:623:1: ruleaffectation returns [EObject current=null] : ( ( (lv_vars_0_0= ruleVars ) ) otherlv_1= ':=' ( (lv_exprs_2_0= ruleExprs ) ) ) ;
    public final EObject ruleaffectation() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        EObject lv_vars_0_0 = null;

        EObject lv_exprs_2_0 = null;


         enterRule(); 
            
        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:626:28: ( ( ( (lv_vars_0_0= ruleVars ) ) otherlv_1= ':=' ( (lv_exprs_2_0= ruleExprs ) ) ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:627:1: ( ( (lv_vars_0_0= ruleVars ) ) otherlv_1= ':=' ( (lv_exprs_2_0= ruleExprs ) ) )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:627:1: ( ( (lv_vars_0_0= ruleVars ) ) otherlv_1= ':=' ( (lv_exprs_2_0= ruleExprs ) ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:627:2: ( (lv_vars_0_0= ruleVars ) ) otherlv_1= ':=' ( (lv_exprs_2_0= ruleExprs ) )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:627:2: ( (lv_vars_0_0= ruleVars ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:628:1: (lv_vars_0_0= ruleVars )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:628:1: (lv_vars_0_0= ruleVars )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:629:3: lv_vars_0_0= ruleVars
            {
            if ( state.backtracking==0 ) {
               
              	        newCompositeNode(grammarAccess.getAffectationAccess().getVarsVarsParserRuleCall_0_0()); 
              	    
            }
            pushFollow(FOLLOW_ruleVars_in_ruleaffectation1219);
            lv_vars_0_0=ruleVars();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              	        if (current==null) {
              	            current = createModelElementForParent(grammarAccess.getAffectationRule());
              	        }
                     		add(
                     			current, 
                     			"vars",
                      		lv_vars_0_0, 
                      		"Vars");
              	        afterParserOrEnumRuleCall();
              	    
            }

            }


            }

            otherlv_1=(Token)match(input,21,FOLLOW_21_in_ruleaffectation1231); if (state.failed) return current;
            if ( state.backtracking==0 ) {

                  	newLeafNode(otherlv_1, grammarAccess.getAffectationAccess().getColonEqualsSignKeyword_1());
                  
            }
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:649:1: ( (lv_exprs_2_0= ruleExprs ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:650:1: (lv_exprs_2_0= ruleExprs )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:650:1: (lv_exprs_2_0= ruleExprs )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:651:3: lv_exprs_2_0= ruleExprs
            {
            if ( state.backtracking==0 ) {
               
              	        newCompositeNode(grammarAccess.getAffectationAccess().getExprsExprsParserRuleCall_2_0()); 
              	    
            }
            pushFollow(FOLLOW_ruleExprs_in_ruleaffectation1252);
            lv_exprs_2_0=ruleExprs();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              	        if (current==null) {
              	            current = createModelElementForParent(grammarAccess.getAffectationRule());
              	        }
                     		add(
                     			current, 
                     			"exprs",
                      		lv_exprs_2_0, 
                      		"Exprs");
              	        afterParserOrEnumRuleCall();
              	    
            }

            }


            }


            }


            }

            if ( state.backtracking==0 ) {
               leaveRule(); 
            }
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleaffectation"


    // $ANTLR start "entryRulewhileCommand"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:675:1: entryRulewhileCommand returns [EObject current=null] : iv_rulewhileCommand= rulewhileCommand EOF ;
    public final EObject entryRulewhileCommand() throws RecognitionException {
        EObject current = null;

        EObject iv_rulewhileCommand = null;


        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:676:2: (iv_rulewhileCommand= rulewhileCommand EOF )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:677:2: iv_rulewhileCommand= rulewhileCommand EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getWhileCommandRule()); 
            }
            pushFollow(FOLLOW_rulewhileCommand_in_entryRulewhileCommand1288);
            iv_rulewhileCommand=rulewhileCommand();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulewhileCommand; 
            }
            match(input,EOF,FOLLOW_EOF_in_entryRulewhileCommand1298); if (state.failed) return current;

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulewhileCommand"


    // $ANTLR start "rulewhileCommand"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:684:1: rulewhileCommand returns [EObject current=null] : (otherlv_0= 'while' ( (lv_expr_1_0= ruleExpr ) ) otherlv_2= 'do' ( (lv_cmd_3_0= ruleCommands ) ) otherlv_4= 'od' ) ;
    public final EObject rulewhileCommand() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        EObject lv_expr_1_0 = null;

        EObject lv_cmd_3_0 = null;


         enterRule(); 
            
        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:687:28: ( (otherlv_0= 'while' ( (lv_expr_1_0= ruleExpr ) ) otherlv_2= 'do' ( (lv_cmd_3_0= ruleCommands ) ) otherlv_4= 'od' ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:688:1: (otherlv_0= 'while' ( (lv_expr_1_0= ruleExpr ) ) otherlv_2= 'do' ( (lv_cmd_3_0= ruleCommands ) ) otherlv_4= 'od' )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:688:1: (otherlv_0= 'while' ( (lv_expr_1_0= ruleExpr ) ) otherlv_2= 'do' ( (lv_cmd_3_0= ruleCommands ) ) otherlv_4= 'od' )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:688:3: otherlv_0= 'while' ( (lv_expr_1_0= ruleExpr ) ) otherlv_2= 'do' ( (lv_cmd_3_0= ruleCommands ) ) otherlv_4= 'od'
            {
            otherlv_0=(Token)match(input,22,FOLLOW_22_in_rulewhileCommand1335); if (state.failed) return current;
            if ( state.backtracking==0 ) {

                  	newLeafNode(otherlv_0, grammarAccess.getWhileCommandAccess().getWhileKeyword_0());
                  
            }
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:692:1: ( (lv_expr_1_0= ruleExpr ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:693:1: (lv_expr_1_0= ruleExpr )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:693:1: (lv_expr_1_0= ruleExpr )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:694:3: lv_expr_1_0= ruleExpr
            {
            if ( state.backtracking==0 ) {
               
              	        newCompositeNode(grammarAccess.getWhileCommandAccess().getExprExprParserRuleCall_1_0()); 
              	    
            }
            pushFollow(FOLLOW_ruleExpr_in_rulewhileCommand1356);
            lv_expr_1_0=ruleExpr();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              	        if (current==null) {
              	            current = createModelElementForParent(grammarAccess.getWhileCommandRule());
              	        }
                     		add(
                     			current, 
                     			"expr",
                      		lv_expr_1_0, 
                      		"Expr");
              	        afterParserOrEnumRuleCall();
              	    
            }

            }


            }

            otherlv_2=(Token)match(input,23,FOLLOW_23_in_rulewhileCommand1368); if (state.failed) return current;
            if ( state.backtracking==0 ) {

                  	newLeafNode(otherlv_2, grammarAccess.getWhileCommandAccess().getDoKeyword_2());
                  
            }
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:714:1: ( (lv_cmd_3_0= ruleCommands ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:715:1: (lv_cmd_3_0= ruleCommands )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:715:1: (lv_cmd_3_0= ruleCommands )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:716:3: lv_cmd_3_0= ruleCommands
            {
            if ( state.backtracking==0 ) {
               
              	        newCompositeNode(grammarAccess.getWhileCommandAccess().getCmdCommandsParserRuleCall_3_0()); 
              	    
            }
            pushFollow(FOLLOW_ruleCommands_in_rulewhileCommand1389);
            lv_cmd_3_0=ruleCommands();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              	        if (current==null) {
              	            current = createModelElementForParent(grammarAccess.getWhileCommandRule());
              	        }
                     		add(
                     			current, 
                     			"cmd",
                      		lv_cmd_3_0, 
                      		"Commands");
              	        afterParserOrEnumRuleCall();
              	    
            }

            }


            }

            otherlv_4=(Token)match(input,24,FOLLOW_24_in_rulewhileCommand1401); if (state.failed) return current;
            if ( state.backtracking==0 ) {

                  	newLeafNode(otherlv_4, grammarAccess.getWhileCommandAccess().getOdKeyword_4());
                  
            }

            }


            }

            if ( state.backtracking==0 ) {
               leaveRule(); 
            }
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "rulewhileCommand"


    // $ANTLR start "entryRuleforCommand"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:744:1: entryRuleforCommand returns [EObject current=null] : iv_ruleforCommand= ruleforCommand EOF ;
    public final EObject entryRuleforCommand() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleforCommand = null;


        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:745:2: (iv_ruleforCommand= ruleforCommand EOF )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:746:2: iv_ruleforCommand= ruleforCommand EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getForCommandRule()); 
            }
            pushFollow(FOLLOW_ruleforCommand_in_entryRuleforCommand1437);
            iv_ruleforCommand=ruleforCommand();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleforCommand; 
            }
            match(input,EOF,FOLLOW_EOF_in_entryRuleforCommand1447); if (state.failed) return current;

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleforCommand"


    // $ANTLR start "ruleforCommand"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:753:1: ruleforCommand returns [EObject current=null] : (otherlv_0= 'for' ( (lv_expr_1_0= ruleExpr ) ) otherlv_2= 'do' ( (lv_cmd_3_0= ruleCommands ) ) otherlv_4= 'od' ) ;
    public final EObject ruleforCommand() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        EObject lv_expr_1_0 = null;

        EObject lv_cmd_3_0 = null;


         enterRule(); 
            
        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:756:28: ( (otherlv_0= 'for' ( (lv_expr_1_0= ruleExpr ) ) otherlv_2= 'do' ( (lv_cmd_3_0= ruleCommands ) ) otherlv_4= 'od' ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:757:1: (otherlv_0= 'for' ( (lv_expr_1_0= ruleExpr ) ) otherlv_2= 'do' ( (lv_cmd_3_0= ruleCommands ) ) otherlv_4= 'od' )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:757:1: (otherlv_0= 'for' ( (lv_expr_1_0= ruleExpr ) ) otherlv_2= 'do' ( (lv_cmd_3_0= ruleCommands ) ) otherlv_4= 'od' )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:757:3: otherlv_0= 'for' ( (lv_expr_1_0= ruleExpr ) ) otherlv_2= 'do' ( (lv_cmd_3_0= ruleCommands ) ) otherlv_4= 'od'
            {
            otherlv_0=(Token)match(input,25,FOLLOW_25_in_ruleforCommand1484); if (state.failed) return current;
            if ( state.backtracking==0 ) {

                  	newLeafNode(otherlv_0, grammarAccess.getForCommandAccess().getForKeyword_0());
                  
            }
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:761:1: ( (lv_expr_1_0= ruleExpr ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:762:1: (lv_expr_1_0= ruleExpr )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:762:1: (lv_expr_1_0= ruleExpr )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:763:3: lv_expr_1_0= ruleExpr
            {
            if ( state.backtracking==0 ) {
               
              	        newCompositeNode(grammarAccess.getForCommandAccess().getExprExprParserRuleCall_1_0()); 
              	    
            }
            pushFollow(FOLLOW_ruleExpr_in_ruleforCommand1505);
            lv_expr_1_0=ruleExpr();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              	        if (current==null) {
              	            current = createModelElementForParent(grammarAccess.getForCommandRule());
              	        }
                     		add(
                     			current, 
                     			"expr",
                      		lv_expr_1_0, 
                      		"Expr");
              	        afterParserOrEnumRuleCall();
              	    
            }

            }


            }

            otherlv_2=(Token)match(input,23,FOLLOW_23_in_ruleforCommand1517); if (state.failed) return current;
            if ( state.backtracking==0 ) {

                  	newLeafNode(otherlv_2, grammarAccess.getForCommandAccess().getDoKeyword_2());
                  
            }
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:783:1: ( (lv_cmd_3_0= ruleCommands ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:784:1: (lv_cmd_3_0= ruleCommands )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:784:1: (lv_cmd_3_0= ruleCommands )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:785:3: lv_cmd_3_0= ruleCommands
            {
            if ( state.backtracking==0 ) {
               
              	        newCompositeNode(grammarAccess.getForCommandAccess().getCmdCommandsParserRuleCall_3_0()); 
              	    
            }
            pushFollow(FOLLOW_ruleCommands_in_ruleforCommand1538);
            lv_cmd_3_0=ruleCommands();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              	        if (current==null) {
              	            current = createModelElementForParent(grammarAccess.getForCommandRule());
              	        }
                     		add(
                     			current, 
                     			"cmd",
                      		lv_cmd_3_0, 
                      		"Commands");
              	        afterParserOrEnumRuleCall();
              	    
            }

            }


            }

            otherlv_4=(Token)match(input,24,FOLLOW_24_in_ruleforCommand1550); if (state.failed) return current;
            if ( state.backtracking==0 ) {

                  	newLeafNode(otherlv_4, grammarAccess.getForCommandAccess().getOdKeyword_4());
                  
            }

            }


            }

            if ( state.backtracking==0 ) {
               leaveRule(); 
            }
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleforCommand"


    // $ANTLR start "entryRuleifCommand"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:813:1: entryRuleifCommand returns [EObject current=null] : iv_ruleifCommand= ruleifCommand EOF ;
    public final EObject entryRuleifCommand() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleifCommand = null;


        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:814:2: (iv_ruleifCommand= ruleifCommand EOF )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:815:2: iv_ruleifCommand= ruleifCommand EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getIfCommandRule()); 
            }
            pushFollow(FOLLOW_ruleifCommand_in_entryRuleifCommand1586);
            iv_ruleifCommand=ruleifCommand();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleifCommand; 
            }
            match(input,EOF,FOLLOW_EOF_in_entryRuleifCommand1596); if (state.failed) return current;

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleifCommand"


    // $ANTLR start "ruleifCommand"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:822:1: ruleifCommand returns [EObject current=null] : (otherlv_0= 'if' ( (lv_expr_1_0= ruleExpr ) ) otherlv_2= 'then' ( (lv_cmd1_3_0= ruleCommands ) ) (otherlv_4= 'else' ( (lv_cmd2_5_0= ruleCommands ) ) )? otherlv_6= 'fi' ) ;
    public final EObject ruleifCommand() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        EObject lv_expr_1_0 = null;

        EObject lv_cmd1_3_0 = null;

        EObject lv_cmd2_5_0 = null;


         enterRule(); 
            
        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:825:28: ( (otherlv_0= 'if' ( (lv_expr_1_0= ruleExpr ) ) otherlv_2= 'then' ( (lv_cmd1_3_0= ruleCommands ) ) (otherlv_4= 'else' ( (lv_cmd2_5_0= ruleCommands ) ) )? otherlv_6= 'fi' ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:826:1: (otherlv_0= 'if' ( (lv_expr_1_0= ruleExpr ) ) otherlv_2= 'then' ( (lv_cmd1_3_0= ruleCommands ) ) (otherlv_4= 'else' ( (lv_cmd2_5_0= ruleCommands ) ) )? otherlv_6= 'fi' )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:826:1: (otherlv_0= 'if' ( (lv_expr_1_0= ruleExpr ) ) otherlv_2= 'then' ( (lv_cmd1_3_0= ruleCommands ) ) (otherlv_4= 'else' ( (lv_cmd2_5_0= ruleCommands ) ) )? otherlv_6= 'fi' )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:826:3: otherlv_0= 'if' ( (lv_expr_1_0= ruleExpr ) ) otherlv_2= 'then' ( (lv_cmd1_3_0= ruleCommands ) ) (otherlv_4= 'else' ( (lv_cmd2_5_0= ruleCommands ) ) )? otherlv_6= 'fi'
            {
            otherlv_0=(Token)match(input,26,FOLLOW_26_in_ruleifCommand1633); if (state.failed) return current;
            if ( state.backtracking==0 ) {

                  	newLeafNode(otherlv_0, grammarAccess.getIfCommandAccess().getIfKeyword_0());
                  
            }
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:830:1: ( (lv_expr_1_0= ruleExpr ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:831:1: (lv_expr_1_0= ruleExpr )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:831:1: (lv_expr_1_0= ruleExpr )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:832:3: lv_expr_1_0= ruleExpr
            {
            if ( state.backtracking==0 ) {
               
              	        newCompositeNode(grammarAccess.getIfCommandAccess().getExprExprParserRuleCall_1_0()); 
              	    
            }
            pushFollow(FOLLOW_ruleExpr_in_ruleifCommand1654);
            lv_expr_1_0=ruleExpr();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              	        if (current==null) {
              	            current = createModelElementForParent(grammarAccess.getIfCommandRule());
              	        }
                     		add(
                     			current, 
                     			"expr",
                      		lv_expr_1_0, 
                      		"Expr");
              	        afterParserOrEnumRuleCall();
              	    
            }

            }


            }

            otherlv_2=(Token)match(input,27,FOLLOW_27_in_ruleifCommand1666); if (state.failed) return current;
            if ( state.backtracking==0 ) {

                  	newLeafNode(otherlv_2, grammarAccess.getIfCommandAccess().getThenKeyword_2());
                  
            }
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:852:1: ( (lv_cmd1_3_0= ruleCommands ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:853:1: (lv_cmd1_3_0= ruleCommands )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:853:1: (lv_cmd1_3_0= ruleCommands )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:854:3: lv_cmd1_3_0= ruleCommands
            {
            if ( state.backtracking==0 ) {
               
              	        newCompositeNode(grammarAccess.getIfCommandAccess().getCmd1CommandsParserRuleCall_3_0()); 
              	    
            }
            pushFollow(FOLLOW_ruleCommands_in_ruleifCommand1687);
            lv_cmd1_3_0=ruleCommands();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              	        if (current==null) {
              	            current = createModelElementForParent(grammarAccess.getIfCommandRule());
              	        }
                     		add(
                     			current, 
                     			"cmd1",
                      		lv_cmd1_3_0, 
                      		"Commands");
              	        afterParserOrEnumRuleCall();
              	    
            }

            }


            }

            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:870:2: (otherlv_4= 'else' ( (lv_cmd2_5_0= ruleCommands ) ) )?
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==28) ) {
                alt6=1;
            }
            switch (alt6) {
                case 1 :
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:870:4: otherlv_4= 'else' ( (lv_cmd2_5_0= ruleCommands ) )
                    {
                    otherlv_4=(Token)match(input,28,FOLLOW_28_in_ruleifCommand1700); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                          	newLeafNode(otherlv_4, grammarAccess.getIfCommandAccess().getElseKeyword_4_0());
                          
                    }
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:874:1: ( (lv_cmd2_5_0= ruleCommands ) )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:875:1: (lv_cmd2_5_0= ruleCommands )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:875:1: (lv_cmd2_5_0= ruleCommands )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:876:3: lv_cmd2_5_0= ruleCommands
                    {
                    if ( state.backtracking==0 ) {
                       
                      	        newCompositeNode(grammarAccess.getIfCommandAccess().getCmd2CommandsParserRuleCall_4_1_0()); 
                      	    
                    }
                    pushFollow(FOLLOW_ruleCommands_in_ruleifCommand1721);
                    lv_cmd2_5_0=ruleCommands();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      	        if (current==null) {
                      	            current = createModelElementForParent(grammarAccess.getIfCommandRule());
                      	        }
                             		add(
                             			current, 
                             			"cmd2",
                              		lv_cmd2_5_0, 
                              		"Commands");
                      	        afterParserOrEnumRuleCall();
                      	    
                    }

                    }


                    }


                    }
                    break;

            }

            otherlv_6=(Token)match(input,29,FOLLOW_29_in_ruleifCommand1735); if (state.failed) return current;
            if ( state.backtracking==0 ) {

                  	newLeafNode(otherlv_6, grammarAccess.getIfCommandAccess().getFiKeyword_5());
                  
            }

            }


            }

            if ( state.backtracking==0 ) {
               leaveRule(); 
            }
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleifCommand"


    // $ANTLR start "entryRuleforeachCommand"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:904:1: entryRuleforeachCommand returns [EObject current=null] : iv_ruleforeachCommand= ruleforeachCommand EOF ;
    public final EObject entryRuleforeachCommand() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleforeachCommand = null;


        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:905:2: (iv_ruleforeachCommand= ruleforeachCommand EOF )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:906:2: iv_ruleforeachCommand= ruleforeachCommand EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getForeachCommandRule()); 
            }
            pushFollow(FOLLOW_ruleforeachCommand_in_entryRuleforeachCommand1771);
            iv_ruleforeachCommand=ruleforeachCommand();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleforeachCommand; 
            }
            match(input,EOF,FOLLOW_EOF_in_entryRuleforeachCommand1781); if (state.failed) return current;

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleforeachCommand"


    // $ANTLR start "ruleforeachCommand"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:913:1: ruleforeachCommand returns [EObject current=null] : (otherlv_0= 'foreach' ( (lv_expr1_1_0= ruleExpr ) ) otherlv_2= 'in' ( (lv_expr2_3_0= ruleExpr ) ) otherlv_4= 'do' ( (lv_cmd_5_0= ruleCommands ) ) otherlv_6= 'od' ) ;
    public final EObject ruleforeachCommand() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        EObject lv_expr1_1_0 = null;

        EObject lv_expr2_3_0 = null;

        EObject lv_cmd_5_0 = null;


         enterRule(); 
            
        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:916:28: ( (otherlv_0= 'foreach' ( (lv_expr1_1_0= ruleExpr ) ) otherlv_2= 'in' ( (lv_expr2_3_0= ruleExpr ) ) otherlv_4= 'do' ( (lv_cmd_5_0= ruleCommands ) ) otherlv_6= 'od' ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:917:1: (otherlv_0= 'foreach' ( (lv_expr1_1_0= ruleExpr ) ) otherlv_2= 'in' ( (lv_expr2_3_0= ruleExpr ) ) otherlv_4= 'do' ( (lv_cmd_5_0= ruleCommands ) ) otherlv_6= 'od' )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:917:1: (otherlv_0= 'foreach' ( (lv_expr1_1_0= ruleExpr ) ) otherlv_2= 'in' ( (lv_expr2_3_0= ruleExpr ) ) otherlv_4= 'do' ( (lv_cmd_5_0= ruleCommands ) ) otherlv_6= 'od' )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:917:3: otherlv_0= 'foreach' ( (lv_expr1_1_0= ruleExpr ) ) otherlv_2= 'in' ( (lv_expr2_3_0= ruleExpr ) ) otherlv_4= 'do' ( (lv_cmd_5_0= ruleCommands ) ) otherlv_6= 'od'
            {
            otherlv_0=(Token)match(input,30,FOLLOW_30_in_ruleforeachCommand1818); if (state.failed) return current;
            if ( state.backtracking==0 ) {

                  	newLeafNode(otherlv_0, grammarAccess.getForeachCommandAccess().getForeachKeyword_0());
                  
            }
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:921:1: ( (lv_expr1_1_0= ruleExpr ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:922:1: (lv_expr1_1_0= ruleExpr )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:922:1: (lv_expr1_1_0= ruleExpr )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:923:3: lv_expr1_1_0= ruleExpr
            {
            if ( state.backtracking==0 ) {
               
              	        newCompositeNode(grammarAccess.getForeachCommandAccess().getExpr1ExprParserRuleCall_1_0()); 
              	    
            }
            pushFollow(FOLLOW_ruleExpr_in_ruleforeachCommand1839);
            lv_expr1_1_0=ruleExpr();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              	        if (current==null) {
              	            current = createModelElementForParent(grammarAccess.getForeachCommandRule());
              	        }
                     		add(
                     			current, 
                     			"expr1",
                      		lv_expr1_1_0, 
                      		"Expr");
              	        afterParserOrEnumRuleCall();
              	    
            }

            }


            }

            otherlv_2=(Token)match(input,31,FOLLOW_31_in_ruleforeachCommand1851); if (state.failed) return current;
            if ( state.backtracking==0 ) {

                  	newLeafNode(otherlv_2, grammarAccess.getForeachCommandAccess().getInKeyword_2());
                  
            }
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:943:1: ( (lv_expr2_3_0= ruleExpr ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:944:1: (lv_expr2_3_0= ruleExpr )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:944:1: (lv_expr2_3_0= ruleExpr )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:945:3: lv_expr2_3_0= ruleExpr
            {
            if ( state.backtracking==0 ) {
               
              	        newCompositeNode(grammarAccess.getForeachCommandAccess().getExpr2ExprParserRuleCall_3_0()); 
              	    
            }
            pushFollow(FOLLOW_ruleExpr_in_ruleforeachCommand1872);
            lv_expr2_3_0=ruleExpr();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              	        if (current==null) {
              	            current = createModelElementForParent(grammarAccess.getForeachCommandRule());
              	        }
                     		add(
                     			current, 
                     			"expr2",
                      		lv_expr2_3_0, 
                      		"Expr");
              	        afterParserOrEnumRuleCall();
              	    
            }

            }


            }

            otherlv_4=(Token)match(input,23,FOLLOW_23_in_ruleforeachCommand1884); if (state.failed) return current;
            if ( state.backtracking==0 ) {

                  	newLeafNode(otherlv_4, grammarAccess.getForeachCommandAccess().getDoKeyword_4());
                  
            }
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:965:1: ( (lv_cmd_5_0= ruleCommands ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:966:1: (lv_cmd_5_0= ruleCommands )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:966:1: (lv_cmd_5_0= ruleCommands )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:967:3: lv_cmd_5_0= ruleCommands
            {
            if ( state.backtracking==0 ) {
               
              	        newCompositeNode(grammarAccess.getForeachCommandAccess().getCmdCommandsParserRuleCall_5_0()); 
              	    
            }
            pushFollow(FOLLOW_ruleCommands_in_ruleforeachCommand1905);
            lv_cmd_5_0=ruleCommands();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              	        if (current==null) {
              	            current = createModelElementForParent(grammarAccess.getForeachCommandRule());
              	        }
                     		add(
                     			current, 
                     			"cmd",
                      		lv_cmd_5_0, 
                      		"Commands");
              	        afterParserOrEnumRuleCall();
              	    
            }

            }


            }

            otherlv_6=(Token)match(input,24,FOLLOW_24_in_ruleforeachCommand1917); if (state.failed) return current;
            if ( state.backtracking==0 ) {

                  	newLeafNode(otherlv_6, grammarAccess.getForeachCommandAccess().getOdKeyword_6());
                  
            }

            }


            }

            if ( state.backtracking==0 ) {
               leaveRule(); 
            }
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleforeachCommand"


    // $ANTLR start "entryRuleVars"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:995:1: entryRuleVars returns [EObject current=null] : iv_ruleVars= ruleVars EOF ;
    public final EObject entryRuleVars() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleVars = null;


        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:996:2: (iv_ruleVars= ruleVars EOF )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:997:2: iv_ruleVars= ruleVars EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getVarsRule()); 
            }
            pushFollow(FOLLOW_ruleVars_in_entryRuleVars1953);
            iv_ruleVars=ruleVars();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleVars; 
            }
            match(input,EOF,FOLLOW_EOF_in_entryRuleVars1963); if (state.failed) return current;

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleVars"


    // $ANTLR start "ruleVars"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1004:1: ruleVars returns [EObject current=null] : ( ( ( (lv_name_0_0= RULE_VARIABLE ) ) otherlv_1= ',' ( (lv_vars_2_0= ruleVars ) ) ) | ( (lv_name_3_0= RULE_VARIABLE ) ) ) ;
    public final EObject ruleVars() throws RecognitionException {
        EObject current = null;

        Token lv_name_0_0=null;
        Token otherlv_1=null;
        Token lv_name_3_0=null;
        EObject lv_vars_2_0 = null;


         enterRule(); 
            
        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1007:28: ( ( ( ( (lv_name_0_0= RULE_VARIABLE ) ) otherlv_1= ',' ( (lv_vars_2_0= ruleVars ) ) ) | ( (lv_name_3_0= RULE_VARIABLE ) ) ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1008:1: ( ( ( (lv_name_0_0= RULE_VARIABLE ) ) otherlv_1= ',' ( (lv_vars_2_0= ruleVars ) ) ) | ( (lv_name_3_0= RULE_VARIABLE ) ) )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1008:1: ( ( ( (lv_name_0_0= RULE_VARIABLE ) ) otherlv_1= ',' ( (lv_vars_2_0= ruleVars ) ) ) | ( (lv_name_3_0= RULE_VARIABLE ) ) )
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==RULE_VARIABLE) ) {
                int LA7_1 = input.LA(2);

                if ( (LA7_1==18) ) {
                    alt7=1;
                }
                else if ( (LA7_1==EOF||LA7_1==21) ) {
                    alt7=2;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return current;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 7, 1, input);

                    throw nvae;
                }
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 7, 0, input);

                throw nvae;
            }
            switch (alt7) {
                case 1 :
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1008:2: ( ( (lv_name_0_0= RULE_VARIABLE ) ) otherlv_1= ',' ( (lv_vars_2_0= ruleVars ) ) )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1008:2: ( ( (lv_name_0_0= RULE_VARIABLE ) ) otherlv_1= ',' ( (lv_vars_2_0= ruleVars ) ) )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1008:3: ( (lv_name_0_0= RULE_VARIABLE ) ) otherlv_1= ',' ( (lv_vars_2_0= ruleVars ) )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1008:3: ( (lv_name_0_0= RULE_VARIABLE ) )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1009:1: (lv_name_0_0= RULE_VARIABLE )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1009:1: (lv_name_0_0= RULE_VARIABLE )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1010:3: lv_name_0_0= RULE_VARIABLE
                    {
                    lv_name_0_0=(Token)match(input,RULE_VARIABLE,FOLLOW_RULE_VARIABLE_in_ruleVars2006); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			newLeafNode(lv_name_0_0, grammarAccess.getVarsAccess().getNameVARIABLETerminalRuleCall_0_0_0()); 
                      		
                    }
                    if ( state.backtracking==0 ) {

                      	        if (current==null) {
                      	            current = createModelElement(grammarAccess.getVarsRule());
                      	        }
                             		setWithLastConsumed(
                             			current, 
                             			"name",
                              		lv_name_0_0, 
                              		"VARIABLE");
                      	    
                    }

                    }


                    }

                    otherlv_1=(Token)match(input,18,FOLLOW_18_in_ruleVars2023); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                          	newLeafNode(otherlv_1, grammarAccess.getVarsAccess().getCommaKeyword_0_1());
                          
                    }
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1030:1: ( (lv_vars_2_0= ruleVars ) )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1031:1: (lv_vars_2_0= ruleVars )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1031:1: (lv_vars_2_0= ruleVars )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1032:3: lv_vars_2_0= ruleVars
                    {
                    if ( state.backtracking==0 ) {
                       
                      	        newCompositeNode(grammarAccess.getVarsAccess().getVarsVarsParserRuleCall_0_2_0()); 
                      	    
                    }
                    pushFollow(FOLLOW_ruleVars_in_ruleVars2044);
                    lv_vars_2_0=ruleVars();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      	        if (current==null) {
                      	            current = createModelElementForParent(grammarAccess.getVarsRule());
                      	        }
                             		add(
                             			current, 
                             			"vars",
                              		lv_vars_2_0, 
                              		"Vars");
                      	        afterParserOrEnumRuleCall();
                      	    
                    }

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1049:6: ( (lv_name_3_0= RULE_VARIABLE ) )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1049:6: ( (lv_name_3_0= RULE_VARIABLE ) )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1050:1: (lv_name_3_0= RULE_VARIABLE )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1050:1: (lv_name_3_0= RULE_VARIABLE )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1051:3: lv_name_3_0= RULE_VARIABLE
                    {
                    lv_name_3_0=(Token)match(input,RULE_VARIABLE,FOLLOW_RULE_VARIABLE_in_ruleVars2068); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			newLeafNode(lv_name_3_0, grammarAccess.getVarsAccess().getNameVARIABLETerminalRuleCall_1_0()); 
                      		
                    }
                    if ( state.backtracking==0 ) {

                      	        if (current==null) {
                      	            current = createModelElement(grammarAccess.getVarsRule());
                      	        }
                             		setWithLastConsumed(
                             			current, 
                             			"name",
                              		lv_name_3_0, 
                              		"VARIABLE");
                      	    
                    }

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {
               leaveRule(); 
            }
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVars"


    // $ANTLR start "entryRuleExprs"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1075:1: entryRuleExprs returns [EObject current=null] : iv_ruleExprs= ruleExprs EOF ;
    public final EObject entryRuleExprs() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleExprs = null;


        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1076:2: (iv_ruleExprs= ruleExprs EOF )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1077:2: iv_ruleExprs= ruleExprs EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getExprsRule()); 
            }
            pushFollow(FOLLOW_ruleExprs_in_entryRuleExprs2109);
            iv_ruleExprs=ruleExprs();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleExprs; 
            }
            match(input,EOF,FOLLOW_EOF_in_entryRuleExprs2119); if (state.failed) return current;

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleExprs"


    // $ANTLR start "ruleExprs"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1084:1: ruleExprs returns [EObject current=null] : ( ( (lv_expr1_0_0= ruleExpr ) ) (otherlv_1= ',' ( (lv_expr_2_0= ruleExprs ) ) )? ) ;
    public final EObject ruleExprs() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        EObject lv_expr1_0_0 = null;

        EObject lv_expr_2_0 = null;


         enterRule(); 
            
        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1087:28: ( ( ( (lv_expr1_0_0= ruleExpr ) ) (otherlv_1= ',' ( (lv_expr_2_0= ruleExprs ) ) )? ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1088:1: ( ( (lv_expr1_0_0= ruleExpr ) ) (otherlv_1= ',' ( (lv_expr_2_0= ruleExprs ) ) )? )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1088:1: ( ( (lv_expr1_0_0= ruleExpr ) ) (otherlv_1= ',' ( (lv_expr_2_0= ruleExprs ) ) )? )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1088:2: ( (lv_expr1_0_0= ruleExpr ) ) (otherlv_1= ',' ( (lv_expr_2_0= ruleExprs ) ) )?
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1088:2: ( (lv_expr1_0_0= ruleExpr ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1089:1: (lv_expr1_0_0= ruleExpr )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1089:1: (lv_expr1_0_0= ruleExpr )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1090:3: lv_expr1_0_0= ruleExpr
            {
            if ( state.backtracking==0 ) {
               
              	        newCompositeNode(grammarAccess.getExprsAccess().getExpr1ExprParserRuleCall_0_0()); 
              	    
            }
            pushFollow(FOLLOW_ruleExpr_in_ruleExprs2165);
            lv_expr1_0_0=ruleExpr();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              	        if (current==null) {
              	            current = createModelElementForParent(grammarAccess.getExprsRule());
              	        }
                     		add(
                     			current, 
                     			"expr1",
                      		lv_expr1_0_0, 
                      		"Expr");
              	        afterParserOrEnumRuleCall();
              	    
            }

            }


            }

            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1106:2: (otherlv_1= ',' ( (lv_expr_2_0= ruleExprs ) ) )?
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==18) ) {
                alt8=1;
            }
            switch (alt8) {
                case 1 :
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1106:4: otherlv_1= ',' ( (lv_expr_2_0= ruleExprs ) )
                    {
                    otherlv_1=(Token)match(input,18,FOLLOW_18_in_ruleExprs2178); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                          	newLeafNode(otherlv_1, grammarAccess.getExprsAccess().getCommaKeyword_1_0());
                          
                    }
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1110:1: ( (lv_expr_2_0= ruleExprs ) )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1111:1: (lv_expr_2_0= ruleExprs )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1111:1: (lv_expr_2_0= ruleExprs )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1112:3: lv_expr_2_0= ruleExprs
                    {
                    if ( state.backtracking==0 ) {
                       
                      	        newCompositeNode(grammarAccess.getExprsAccess().getExprExprsParserRuleCall_1_1_0()); 
                      	    
                    }
                    pushFollow(FOLLOW_ruleExprs_in_ruleExprs2199);
                    lv_expr_2_0=ruleExprs();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      	        if (current==null) {
                      	            current = createModelElementForParent(grammarAccess.getExprsRule());
                      	        }
                             		add(
                             			current, 
                             			"expr",
                              		lv_expr_2_0, 
                              		"Exprs");
                      	        afterParserOrEnumRuleCall();
                      	    
                    }

                    }


                    }


                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {
               leaveRule(); 
            }
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleExprs"


    // $ANTLR start "entryRuleExpr"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1136:1: entryRuleExpr returns [EObject current=null] : iv_ruleExpr= ruleExpr EOF ;
    public final EObject entryRuleExpr() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleExpr = null;


        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1137:2: (iv_ruleExpr= ruleExpr EOF )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1138:2: iv_ruleExpr= ruleExpr EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getExprRule()); 
            }
            pushFollow(FOLLOW_ruleExpr_in_entryRuleExpr2237);
            iv_ruleExpr=ruleExpr();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleExpr; 
            }
            match(input,EOF,FOLLOW_EOF_in_entryRuleExpr2247); if (state.failed) return current;

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleExpr"


    // $ANTLR start "ruleExpr"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1145:1: ruleExpr returns [EObject current=null] : ( ( ( ( ruleExprSimple ) )=> (lv_exprSimple_0_0= ruleExprSimple ) ) | ( (lv_exprAnd_1_0= ruleExprAnd ) ) ) ;
    public final EObject ruleExpr() throws RecognitionException {
        EObject current = null;

        EObject lv_exprSimple_0_0 = null;

        EObject lv_exprAnd_1_0 = null;


         enterRule(); 
            
        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1148:28: ( ( ( ( ( ruleExprSimple ) )=> (lv_exprSimple_0_0= ruleExprSimple ) ) | ( (lv_exprAnd_1_0= ruleExprAnd ) ) ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1149:1: ( ( ( ( ruleExprSimple ) )=> (lv_exprSimple_0_0= ruleExprSimple ) ) | ( (lv_exprAnd_1_0= ruleExprAnd ) ) )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1149:1: ( ( ( ( ruleExprSimple ) )=> (lv_exprSimple_0_0= ruleExprSimple ) ) | ( (lv_exprAnd_1_0= ruleExprAnd ) ) )
            int alt9=2;
            switch ( input.LA(1) ) {
            case 32:
                {
                int LA9_1 = input.LA(2);

                if ( (synpred1_InternalWh()) ) {
                    alt9=1;
                }
                else if ( (true) ) {
                    alt9=2;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return current;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 9, 1, input);

                    throw nvae;
                }
                }
                break;
            case RULE_VARIABLE:
                {
                int LA9_2 = input.LA(2);

                if ( (synpred1_InternalWh()) ) {
                    alt9=1;
                }
                else if ( (true) ) {
                    alt9=2;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return current;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 9, 2, input);

                    throw nvae;
                }
                }
                break;
            case RULE_SYMBOL:
                {
                int LA9_3 = input.LA(2);

                if ( (synpred1_InternalWh()) ) {
                    alt9=1;
                }
                else if ( (true) ) {
                    alt9=2;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return current;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 9, 3, input);

                    throw nvae;
                }
                }
                break;
            case 33:
                {
                int LA9_4 = input.LA(2);

                if ( (synpred1_InternalWh()) ) {
                    alt9=1;
                }
                else if ( (true) ) {
                    alt9=2;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return current;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 9, 4, input);

                    throw nvae;
                }
                }
                break;
            case 41:
                {
                alt9=2;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 9, 0, input);

                throw nvae;
            }

            switch (alt9) {
                case 1 :
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1149:2: ( ( ( ruleExprSimple ) )=> (lv_exprSimple_0_0= ruleExprSimple ) )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1149:2: ( ( ( ruleExprSimple ) )=> (lv_exprSimple_0_0= ruleExprSimple ) )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1149:3: ( ( ruleExprSimple ) )=> (lv_exprSimple_0_0= ruleExprSimple )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1154:1: (lv_exprSimple_0_0= ruleExprSimple )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1155:3: lv_exprSimple_0_0= ruleExprSimple
                    {
                    if ( state.backtracking==0 ) {
                       
                      	        newCompositeNode(grammarAccess.getExprAccess().getExprSimpleExprSimpleParserRuleCall_0_0()); 
                      	    
                    }
                    pushFollow(FOLLOW_ruleExprSimple_in_ruleExpr2303);
                    lv_exprSimple_0_0=ruleExprSimple();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      	        if (current==null) {
                      	            current = createModelElementForParent(grammarAccess.getExprRule());
                      	        }
                             		add(
                             			current, 
                             			"exprSimple",
                              		lv_exprSimple_0_0, 
                              		"ExprSimple");
                      	        afterParserOrEnumRuleCall();
                      	    
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1172:6: ( (lv_exprAnd_1_0= ruleExprAnd ) )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1172:6: ( (lv_exprAnd_1_0= ruleExprAnd ) )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1173:1: (lv_exprAnd_1_0= ruleExprAnd )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1173:1: (lv_exprAnd_1_0= ruleExprAnd )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1174:3: lv_exprAnd_1_0= ruleExprAnd
                    {
                    if ( state.backtracking==0 ) {
                       
                      	        newCompositeNode(grammarAccess.getExprAccess().getExprAndExprAndParserRuleCall_1_0()); 
                      	    
                    }
                    pushFollow(FOLLOW_ruleExprAnd_in_ruleExpr2330);
                    lv_exprAnd_1_0=ruleExprAnd();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      	        if (current==null) {
                      	            current = createModelElementForParent(grammarAccess.getExprRule());
                      	        }
                             		add(
                             			current, 
                             			"exprAnd",
                              		lv_exprAnd_1_0, 
                              		"ExprAnd");
                      	        afterParserOrEnumRuleCall();
                      	    
                    }

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {
               leaveRule(); 
            }
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleExpr"


    // $ANTLR start "entryRuleExprSimple"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1198:1: entryRuleExprSimple returns [EObject current=null] : iv_ruleExprSimple= ruleExprSimple EOF ;
    public final EObject entryRuleExprSimple() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleExprSimple = null;


        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1199:2: (iv_ruleExprSimple= ruleExprSimple EOF )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1200:2: iv_ruleExprSimple= ruleExprSimple EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getExprSimpleRule()); 
            }
            pushFollow(FOLLOW_ruleExprSimple_in_entryRuleExprSimple2366);
            iv_ruleExprSimple=ruleExprSimple();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleExprSimple; 
            }
            match(input,EOF,FOLLOW_EOF_in_entryRuleExprSimple2376); if (state.failed) return current;

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleExprSimple"


    // $ANTLR start "ruleExprSimple"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1207:1: ruleExprSimple returns [EObject current=null] : ( ( (lv_nil_0_0= 'nil' ) ) | ( (lv_name1_1_0= RULE_VARIABLE ) ) | ( (lv_name2_2_0= RULE_SYMBOL ) ) | ( (lv_cons_3_0= rulecons ) ) | ( (lv_list_4_0= rulelist ) ) | ( (lv_hd_5_0= rulehd ) ) | ( (lv_tl_6_0= ruletl ) ) | ( (lv_symb_7_0= rulesymb ) ) ) ;
    public final EObject ruleExprSimple() throws RecognitionException {
        EObject current = null;

        Token lv_nil_0_0=null;
        Token lv_name1_1_0=null;
        Token lv_name2_2_0=null;
        EObject lv_cons_3_0 = null;

        EObject lv_list_4_0 = null;

        EObject lv_hd_5_0 = null;

        EObject lv_tl_6_0 = null;

        EObject lv_symb_7_0 = null;


         enterRule(); 
            
        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1210:28: ( ( ( (lv_nil_0_0= 'nil' ) ) | ( (lv_name1_1_0= RULE_VARIABLE ) ) | ( (lv_name2_2_0= RULE_SYMBOL ) ) | ( (lv_cons_3_0= rulecons ) ) | ( (lv_list_4_0= rulelist ) ) | ( (lv_hd_5_0= rulehd ) ) | ( (lv_tl_6_0= ruletl ) ) | ( (lv_symb_7_0= rulesymb ) ) ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1211:1: ( ( (lv_nil_0_0= 'nil' ) ) | ( (lv_name1_1_0= RULE_VARIABLE ) ) | ( (lv_name2_2_0= RULE_SYMBOL ) ) | ( (lv_cons_3_0= rulecons ) ) | ( (lv_list_4_0= rulelist ) ) | ( (lv_hd_5_0= rulehd ) ) | ( (lv_tl_6_0= ruletl ) ) | ( (lv_symb_7_0= rulesymb ) ) )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1211:1: ( ( (lv_nil_0_0= 'nil' ) ) | ( (lv_name1_1_0= RULE_VARIABLE ) ) | ( (lv_name2_2_0= RULE_SYMBOL ) ) | ( (lv_cons_3_0= rulecons ) ) | ( (lv_list_4_0= rulelist ) ) | ( (lv_hd_5_0= rulehd ) ) | ( (lv_tl_6_0= ruletl ) ) | ( (lv_symb_7_0= rulesymb ) ) )
            int alt10=8;
            alt10 = dfa10.predict(input);
            switch (alt10) {
                case 1 :
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1211:2: ( (lv_nil_0_0= 'nil' ) )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1211:2: ( (lv_nil_0_0= 'nil' ) )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1212:1: (lv_nil_0_0= 'nil' )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1212:1: (lv_nil_0_0= 'nil' )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1213:3: lv_nil_0_0= 'nil'
                    {
                    lv_nil_0_0=(Token)match(input,32,FOLLOW_32_in_ruleExprSimple2419); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                              newLeafNode(lv_nil_0_0, grammarAccess.getExprSimpleAccess().getNilNilKeyword_0_0());
                          
                    }
                    if ( state.backtracking==0 ) {

                      	        if (current==null) {
                      	            current = createModelElement(grammarAccess.getExprSimpleRule());
                      	        }
                             		setWithLastConsumed(current, "nil", lv_nil_0_0, "nil");
                      	    
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1227:6: ( (lv_name1_1_0= RULE_VARIABLE ) )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1227:6: ( (lv_name1_1_0= RULE_VARIABLE ) )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1228:1: (lv_name1_1_0= RULE_VARIABLE )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1228:1: (lv_name1_1_0= RULE_VARIABLE )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1229:3: lv_name1_1_0= RULE_VARIABLE
                    {
                    lv_name1_1_0=(Token)match(input,RULE_VARIABLE,FOLLOW_RULE_VARIABLE_in_ruleExprSimple2455); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			newLeafNode(lv_name1_1_0, grammarAccess.getExprSimpleAccess().getName1VARIABLETerminalRuleCall_1_0()); 
                      		
                    }
                    if ( state.backtracking==0 ) {

                      	        if (current==null) {
                      	            current = createModelElement(grammarAccess.getExprSimpleRule());
                      	        }
                             		setWithLastConsumed(
                             			current, 
                             			"name1",
                              		lv_name1_1_0, 
                              		"VARIABLE");
                      	    
                    }

                    }


                    }


                    }
                    break;
                case 3 :
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1246:6: ( (lv_name2_2_0= RULE_SYMBOL ) )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1246:6: ( (lv_name2_2_0= RULE_SYMBOL ) )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1247:1: (lv_name2_2_0= RULE_SYMBOL )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1247:1: (lv_name2_2_0= RULE_SYMBOL )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1248:3: lv_name2_2_0= RULE_SYMBOL
                    {
                    lv_name2_2_0=(Token)match(input,RULE_SYMBOL,FOLLOW_RULE_SYMBOL_in_ruleExprSimple2483); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			newLeafNode(lv_name2_2_0, grammarAccess.getExprSimpleAccess().getName2SYMBOLTerminalRuleCall_2_0()); 
                      		
                    }
                    if ( state.backtracking==0 ) {

                      	        if (current==null) {
                      	            current = createModelElement(grammarAccess.getExprSimpleRule());
                      	        }
                             		setWithLastConsumed(
                             			current, 
                             			"name2",
                              		lv_name2_2_0, 
                              		"SYMBOL");
                      	    
                    }

                    }


                    }


                    }
                    break;
                case 4 :
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1265:6: ( (lv_cons_3_0= rulecons ) )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1265:6: ( (lv_cons_3_0= rulecons ) )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1266:1: (lv_cons_3_0= rulecons )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1266:1: (lv_cons_3_0= rulecons )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1267:3: lv_cons_3_0= rulecons
                    {
                    if ( state.backtracking==0 ) {
                       
                      	        newCompositeNode(grammarAccess.getExprSimpleAccess().getConsConsParserRuleCall_3_0()); 
                      	    
                    }
                    pushFollow(FOLLOW_rulecons_in_ruleExprSimple2515);
                    lv_cons_3_0=rulecons();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      	        if (current==null) {
                      	            current = createModelElementForParent(grammarAccess.getExprSimpleRule());
                      	        }
                             		add(
                             			current, 
                             			"cons",
                              		lv_cons_3_0, 
                              		"cons");
                      	        afterParserOrEnumRuleCall();
                      	    
                    }

                    }


                    }


                    }
                    break;
                case 5 :
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1284:6: ( (lv_list_4_0= rulelist ) )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1284:6: ( (lv_list_4_0= rulelist ) )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1285:1: (lv_list_4_0= rulelist )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1285:1: (lv_list_4_0= rulelist )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1286:3: lv_list_4_0= rulelist
                    {
                    if ( state.backtracking==0 ) {
                       
                      	        newCompositeNode(grammarAccess.getExprSimpleAccess().getListListParserRuleCall_4_0()); 
                      	    
                    }
                    pushFollow(FOLLOW_rulelist_in_ruleExprSimple2542);
                    lv_list_4_0=rulelist();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      	        if (current==null) {
                      	            current = createModelElementForParent(grammarAccess.getExprSimpleRule());
                      	        }
                             		add(
                             			current, 
                             			"list",
                              		lv_list_4_0, 
                              		"list");
                      	        afterParserOrEnumRuleCall();
                      	    
                    }

                    }


                    }


                    }
                    break;
                case 6 :
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1303:6: ( (lv_hd_5_0= rulehd ) )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1303:6: ( (lv_hd_5_0= rulehd ) )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1304:1: (lv_hd_5_0= rulehd )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1304:1: (lv_hd_5_0= rulehd )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1305:3: lv_hd_5_0= rulehd
                    {
                    if ( state.backtracking==0 ) {
                       
                      	        newCompositeNode(grammarAccess.getExprSimpleAccess().getHdHdParserRuleCall_5_0()); 
                      	    
                    }
                    pushFollow(FOLLOW_rulehd_in_ruleExprSimple2569);
                    lv_hd_5_0=rulehd();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      	        if (current==null) {
                      	            current = createModelElementForParent(grammarAccess.getExprSimpleRule());
                      	        }
                             		add(
                             			current, 
                             			"hd",
                              		lv_hd_5_0, 
                              		"hd");
                      	        afterParserOrEnumRuleCall();
                      	    
                    }

                    }


                    }


                    }
                    break;
                case 7 :
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1322:6: ( (lv_tl_6_0= ruletl ) )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1322:6: ( (lv_tl_6_0= ruletl ) )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1323:1: (lv_tl_6_0= ruletl )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1323:1: (lv_tl_6_0= ruletl )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1324:3: lv_tl_6_0= ruletl
                    {
                    if ( state.backtracking==0 ) {
                       
                      	        newCompositeNode(grammarAccess.getExprSimpleAccess().getTlTlParserRuleCall_6_0()); 
                      	    
                    }
                    pushFollow(FOLLOW_ruletl_in_ruleExprSimple2596);
                    lv_tl_6_0=ruletl();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      	        if (current==null) {
                      	            current = createModelElementForParent(grammarAccess.getExprSimpleRule());
                      	        }
                             		add(
                             			current, 
                             			"tl",
                              		lv_tl_6_0, 
                              		"tl");
                      	        afterParserOrEnumRuleCall();
                      	    
                    }

                    }


                    }


                    }
                    break;
                case 8 :
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1341:6: ( (lv_symb_7_0= rulesymb ) )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1341:6: ( (lv_symb_7_0= rulesymb ) )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1342:1: (lv_symb_7_0= rulesymb )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1342:1: (lv_symb_7_0= rulesymb )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1343:3: lv_symb_7_0= rulesymb
                    {
                    if ( state.backtracking==0 ) {
                       
                      	        newCompositeNode(grammarAccess.getExprSimpleAccess().getSymbSymbParserRuleCall_7_0()); 
                      	    
                    }
                    pushFollow(FOLLOW_rulesymb_in_ruleExprSimple2623);
                    lv_symb_7_0=rulesymb();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      	        if (current==null) {
                      	            current = createModelElementForParent(grammarAccess.getExprSimpleRule());
                      	        }
                             		add(
                             			current, 
                             			"symb",
                              		lv_symb_7_0, 
                              		"symb");
                      	        afterParserOrEnumRuleCall();
                      	    
                    }

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {
               leaveRule(); 
            }
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleExprSimple"


    // $ANTLR start "entryRulecons"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1367:1: entryRulecons returns [EObject current=null] : iv_rulecons= rulecons EOF ;
    public final EObject entryRulecons() throws RecognitionException {
        EObject current = null;

        EObject iv_rulecons = null;


        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1368:2: (iv_rulecons= rulecons EOF )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1369:2: iv_rulecons= rulecons EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getConsRule()); 
            }
            pushFollow(FOLLOW_rulecons_in_entryRulecons2659);
            iv_rulecons=rulecons();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulecons; 
            }
            match(input,EOF,FOLLOW_EOF_in_entryRulecons2669); if (state.failed) return current;

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulecons"


    // $ANTLR start "rulecons"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1376:1: rulecons returns [EObject current=null] : (otherlv_0= '(' otherlv_1= 'cons' ( (lv_lexpr_2_0= ruleLexpr ) ) otherlv_3= ')' ) ;
    public final EObject rulecons() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        EObject lv_lexpr_2_0 = null;


         enterRule(); 
            
        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1379:28: ( (otherlv_0= '(' otherlv_1= 'cons' ( (lv_lexpr_2_0= ruleLexpr ) ) otherlv_3= ')' ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1380:1: (otherlv_0= '(' otherlv_1= 'cons' ( (lv_lexpr_2_0= ruleLexpr ) ) otherlv_3= ')' )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1380:1: (otherlv_0= '(' otherlv_1= 'cons' ( (lv_lexpr_2_0= ruleLexpr ) ) otherlv_3= ')' )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1380:3: otherlv_0= '(' otherlv_1= 'cons' ( (lv_lexpr_2_0= ruleLexpr ) ) otherlv_3= ')'
            {
            otherlv_0=(Token)match(input,33,FOLLOW_33_in_rulecons2706); if (state.failed) return current;
            if ( state.backtracking==0 ) {

                  	newLeafNode(otherlv_0, grammarAccess.getConsAccess().getLeftParenthesisKeyword_0());
                  
            }
            otherlv_1=(Token)match(input,34,FOLLOW_34_in_rulecons2718); if (state.failed) return current;
            if ( state.backtracking==0 ) {

                  	newLeafNode(otherlv_1, grammarAccess.getConsAccess().getConsKeyword_1());
                  
            }
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1388:1: ( (lv_lexpr_2_0= ruleLexpr ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1389:1: (lv_lexpr_2_0= ruleLexpr )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1389:1: (lv_lexpr_2_0= ruleLexpr )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1390:3: lv_lexpr_2_0= ruleLexpr
            {
            if ( state.backtracking==0 ) {
               
              	        newCompositeNode(grammarAccess.getConsAccess().getLexprLexprParserRuleCall_2_0()); 
              	    
            }
            pushFollow(FOLLOW_ruleLexpr_in_rulecons2739);
            lv_lexpr_2_0=ruleLexpr();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              	        if (current==null) {
              	            current = createModelElementForParent(grammarAccess.getConsRule());
              	        }
                     		add(
                     			current, 
                     			"lexpr",
                      		lv_lexpr_2_0, 
                      		"Lexpr");
              	        afterParserOrEnumRuleCall();
              	    
            }

            }


            }

            otherlv_3=(Token)match(input,35,FOLLOW_35_in_rulecons2751); if (state.failed) return current;
            if ( state.backtracking==0 ) {

                  	newLeafNode(otherlv_3, grammarAccess.getConsAccess().getRightParenthesisKeyword_3());
                  
            }

            }


            }

            if ( state.backtracking==0 ) {
               leaveRule(); 
            }
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "rulecons"


    // $ANTLR start "entryRulelist"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1418:1: entryRulelist returns [EObject current=null] : iv_rulelist= rulelist EOF ;
    public final EObject entryRulelist() throws RecognitionException {
        EObject current = null;

        EObject iv_rulelist = null;


        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1419:2: (iv_rulelist= rulelist EOF )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1420:2: iv_rulelist= rulelist EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getListRule()); 
            }
            pushFollow(FOLLOW_rulelist_in_entryRulelist2787);
            iv_rulelist=rulelist();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulelist; 
            }
            match(input,EOF,FOLLOW_EOF_in_entryRulelist2797); if (state.failed) return current;

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulelist"


    // $ANTLR start "rulelist"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1427:1: rulelist returns [EObject current=null] : (otherlv_0= '(' otherlv_1= 'list' ( (lv_lexpr_2_0= ruleLexpr ) ) otherlv_3= ')' ) ;
    public final EObject rulelist() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        EObject lv_lexpr_2_0 = null;


         enterRule(); 
            
        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1430:28: ( (otherlv_0= '(' otherlv_1= 'list' ( (lv_lexpr_2_0= ruleLexpr ) ) otherlv_3= ')' ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1431:1: (otherlv_0= '(' otherlv_1= 'list' ( (lv_lexpr_2_0= ruleLexpr ) ) otherlv_3= ')' )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1431:1: (otherlv_0= '(' otherlv_1= 'list' ( (lv_lexpr_2_0= ruleLexpr ) ) otherlv_3= ')' )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1431:3: otherlv_0= '(' otherlv_1= 'list' ( (lv_lexpr_2_0= ruleLexpr ) ) otherlv_3= ')'
            {
            otherlv_0=(Token)match(input,33,FOLLOW_33_in_rulelist2834); if (state.failed) return current;
            if ( state.backtracking==0 ) {

                  	newLeafNode(otherlv_0, grammarAccess.getListAccess().getLeftParenthesisKeyword_0());
                  
            }
            otherlv_1=(Token)match(input,36,FOLLOW_36_in_rulelist2846); if (state.failed) return current;
            if ( state.backtracking==0 ) {

                  	newLeafNode(otherlv_1, grammarAccess.getListAccess().getListKeyword_1());
                  
            }
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1439:1: ( (lv_lexpr_2_0= ruleLexpr ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1440:1: (lv_lexpr_2_0= ruleLexpr )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1440:1: (lv_lexpr_2_0= ruleLexpr )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1441:3: lv_lexpr_2_0= ruleLexpr
            {
            if ( state.backtracking==0 ) {
               
              	        newCompositeNode(grammarAccess.getListAccess().getLexprLexprParserRuleCall_2_0()); 
              	    
            }
            pushFollow(FOLLOW_ruleLexpr_in_rulelist2867);
            lv_lexpr_2_0=ruleLexpr();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              	        if (current==null) {
              	            current = createModelElementForParent(grammarAccess.getListRule());
              	        }
                     		add(
                     			current, 
                     			"lexpr",
                      		lv_lexpr_2_0, 
                      		"Lexpr");
              	        afterParserOrEnumRuleCall();
              	    
            }

            }


            }

            otherlv_3=(Token)match(input,35,FOLLOW_35_in_rulelist2879); if (state.failed) return current;
            if ( state.backtracking==0 ) {

                  	newLeafNode(otherlv_3, grammarAccess.getListAccess().getRightParenthesisKeyword_3());
                  
            }

            }


            }

            if ( state.backtracking==0 ) {
               leaveRule(); 
            }
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "rulelist"


    // $ANTLR start "entryRulehd"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1469:1: entryRulehd returns [EObject current=null] : iv_rulehd= rulehd EOF ;
    public final EObject entryRulehd() throws RecognitionException {
        EObject current = null;

        EObject iv_rulehd = null;


        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1470:2: (iv_rulehd= rulehd EOF )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1471:2: iv_rulehd= rulehd EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getHdRule()); 
            }
            pushFollow(FOLLOW_rulehd_in_entryRulehd2915);
            iv_rulehd=rulehd();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulehd; 
            }
            match(input,EOF,FOLLOW_EOF_in_entryRulehd2925); if (state.failed) return current;

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulehd"


    // $ANTLR start "rulehd"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1478:1: rulehd returns [EObject current=null] : (otherlv_0= '(' otherlv_1= 'hd' ( (lv_expr_2_0= ruleExpr ) ) otherlv_3= ')' ) ;
    public final EObject rulehd() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        EObject lv_expr_2_0 = null;


         enterRule(); 
            
        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1481:28: ( (otherlv_0= '(' otherlv_1= 'hd' ( (lv_expr_2_0= ruleExpr ) ) otherlv_3= ')' ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1482:1: (otherlv_0= '(' otherlv_1= 'hd' ( (lv_expr_2_0= ruleExpr ) ) otherlv_3= ')' )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1482:1: (otherlv_0= '(' otherlv_1= 'hd' ( (lv_expr_2_0= ruleExpr ) ) otherlv_3= ')' )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1482:3: otherlv_0= '(' otherlv_1= 'hd' ( (lv_expr_2_0= ruleExpr ) ) otherlv_3= ')'
            {
            otherlv_0=(Token)match(input,33,FOLLOW_33_in_rulehd2962); if (state.failed) return current;
            if ( state.backtracking==0 ) {

                  	newLeafNode(otherlv_0, grammarAccess.getHdAccess().getLeftParenthesisKeyword_0());
                  
            }
            otherlv_1=(Token)match(input,37,FOLLOW_37_in_rulehd2974); if (state.failed) return current;
            if ( state.backtracking==0 ) {

                  	newLeafNode(otherlv_1, grammarAccess.getHdAccess().getHdKeyword_1());
                  
            }
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1490:1: ( (lv_expr_2_0= ruleExpr ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1491:1: (lv_expr_2_0= ruleExpr )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1491:1: (lv_expr_2_0= ruleExpr )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1492:3: lv_expr_2_0= ruleExpr
            {
            if ( state.backtracking==0 ) {
               
              	        newCompositeNode(grammarAccess.getHdAccess().getExprExprParserRuleCall_2_0()); 
              	    
            }
            pushFollow(FOLLOW_ruleExpr_in_rulehd2995);
            lv_expr_2_0=ruleExpr();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              	        if (current==null) {
              	            current = createModelElementForParent(grammarAccess.getHdRule());
              	        }
                     		add(
                     			current, 
                     			"expr",
                      		lv_expr_2_0, 
                      		"Expr");
              	        afterParserOrEnumRuleCall();
              	    
            }

            }


            }

            otherlv_3=(Token)match(input,35,FOLLOW_35_in_rulehd3007); if (state.failed) return current;
            if ( state.backtracking==0 ) {

                  	newLeafNode(otherlv_3, grammarAccess.getHdAccess().getRightParenthesisKeyword_3());
                  
            }

            }


            }

            if ( state.backtracking==0 ) {
               leaveRule(); 
            }
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "rulehd"


    // $ANTLR start "entryRuletl"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1520:1: entryRuletl returns [EObject current=null] : iv_ruletl= ruletl EOF ;
    public final EObject entryRuletl() throws RecognitionException {
        EObject current = null;

        EObject iv_ruletl = null;


        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1521:2: (iv_ruletl= ruletl EOF )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1522:2: iv_ruletl= ruletl EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getTlRule()); 
            }
            pushFollow(FOLLOW_ruletl_in_entryRuletl3043);
            iv_ruletl=ruletl();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruletl; 
            }
            match(input,EOF,FOLLOW_EOF_in_entryRuletl3053); if (state.failed) return current;

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuletl"


    // $ANTLR start "ruletl"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1529:1: ruletl returns [EObject current=null] : (otherlv_0= '(' otherlv_1= 'tl' ( (lv_expr_2_0= ruleExpr ) ) otherlv_3= ')' ) ;
    public final EObject ruletl() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        EObject lv_expr_2_0 = null;


         enterRule(); 
            
        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1532:28: ( (otherlv_0= '(' otherlv_1= 'tl' ( (lv_expr_2_0= ruleExpr ) ) otherlv_3= ')' ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1533:1: (otherlv_0= '(' otherlv_1= 'tl' ( (lv_expr_2_0= ruleExpr ) ) otherlv_3= ')' )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1533:1: (otherlv_0= '(' otherlv_1= 'tl' ( (lv_expr_2_0= ruleExpr ) ) otherlv_3= ')' )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1533:3: otherlv_0= '(' otherlv_1= 'tl' ( (lv_expr_2_0= ruleExpr ) ) otherlv_3= ')'
            {
            otherlv_0=(Token)match(input,33,FOLLOW_33_in_ruletl3090); if (state.failed) return current;
            if ( state.backtracking==0 ) {

                  	newLeafNode(otherlv_0, grammarAccess.getTlAccess().getLeftParenthesisKeyword_0());
                  
            }
            otherlv_1=(Token)match(input,38,FOLLOW_38_in_ruletl3102); if (state.failed) return current;
            if ( state.backtracking==0 ) {

                  	newLeafNode(otherlv_1, grammarAccess.getTlAccess().getTlKeyword_1());
                  
            }
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1541:1: ( (lv_expr_2_0= ruleExpr ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1542:1: (lv_expr_2_0= ruleExpr )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1542:1: (lv_expr_2_0= ruleExpr )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1543:3: lv_expr_2_0= ruleExpr
            {
            if ( state.backtracking==0 ) {
               
              	        newCompositeNode(grammarAccess.getTlAccess().getExprExprParserRuleCall_2_0()); 
              	    
            }
            pushFollow(FOLLOW_ruleExpr_in_ruletl3123);
            lv_expr_2_0=ruleExpr();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              	        if (current==null) {
              	            current = createModelElementForParent(grammarAccess.getTlRule());
              	        }
                     		add(
                     			current, 
                     			"expr",
                      		lv_expr_2_0, 
                      		"Expr");
              	        afterParserOrEnumRuleCall();
              	    
            }

            }


            }

            otherlv_3=(Token)match(input,35,FOLLOW_35_in_ruletl3135); if (state.failed) return current;
            if ( state.backtracking==0 ) {

                  	newLeafNode(otherlv_3, grammarAccess.getTlAccess().getRightParenthesisKeyword_3());
                  
            }

            }


            }

            if ( state.backtracking==0 ) {
               leaveRule(); 
            }
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruletl"


    // $ANTLR start "entryRulesymb"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1571:1: entryRulesymb returns [EObject current=null] : iv_rulesymb= rulesymb EOF ;
    public final EObject entryRulesymb() throws RecognitionException {
        EObject current = null;

        EObject iv_rulesymb = null;


        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1572:2: (iv_rulesymb= rulesymb EOF )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1573:2: iv_rulesymb= rulesymb EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getSymbRule()); 
            }
            pushFollow(FOLLOW_rulesymb_in_entryRulesymb3171);
            iv_rulesymb=rulesymb();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulesymb; 
            }
            match(input,EOF,FOLLOW_EOF_in_entryRulesymb3181); if (state.failed) return current;

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulesymb"


    // $ANTLR start "rulesymb"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1580:1: rulesymb returns [EObject current=null] : (otherlv_0= '(' ( (lv_name_1_0= RULE_SYMBOL ) ) ( (lv_lexpr_2_0= ruleLexpr ) ) otherlv_3= ')' ) ;
    public final EObject rulesymb() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_3=null;
        EObject lv_lexpr_2_0 = null;


         enterRule(); 
            
        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1583:28: ( (otherlv_0= '(' ( (lv_name_1_0= RULE_SYMBOL ) ) ( (lv_lexpr_2_0= ruleLexpr ) ) otherlv_3= ')' ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1584:1: (otherlv_0= '(' ( (lv_name_1_0= RULE_SYMBOL ) ) ( (lv_lexpr_2_0= ruleLexpr ) ) otherlv_3= ')' )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1584:1: (otherlv_0= '(' ( (lv_name_1_0= RULE_SYMBOL ) ) ( (lv_lexpr_2_0= ruleLexpr ) ) otherlv_3= ')' )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1584:3: otherlv_0= '(' ( (lv_name_1_0= RULE_SYMBOL ) ) ( (lv_lexpr_2_0= ruleLexpr ) ) otherlv_3= ')'
            {
            otherlv_0=(Token)match(input,33,FOLLOW_33_in_rulesymb3218); if (state.failed) return current;
            if ( state.backtracking==0 ) {

                  	newLeafNode(otherlv_0, grammarAccess.getSymbAccess().getLeftParenthesisKeyword_0());
                  
            }
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1588:1: ( (lv_name_1_0= RULE_SYMBOL ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1589:1: (lv_name_1_0= RULE_SYMBOL )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1589:1: (lv_name_1_0= RULE_SYMBOL )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1590:3: lv_name_1_0= RULE_SYMBOL
            {
            lv_name_1_0=(Token)match(input,RULE_SYMBOL,FOLLOW_RULE_SYMBOL_in_rulesymb3235); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(lv_name_1_0, grammarAccess.getSymbAccess().getNameSYMBOLTerminalRuleCall_1_0()); 
              		
            }
            if ( state.backtracking==0 ) {

              	        if (current==null) {
              	            current = createModelElement(grammarAccess.getSymbRule());
              	        }
                     		setWithLastConsumed(
                     			current, 
                     			"name",
                      		lv_name_1_0, 
                      		"SYMBOL");
              	    
            }

            }


            }

            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1606:2: ( (lv_lexpr_2_0= ruleLexpr ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1607:1: (lv_lexpr_2_0= ruleLexpr )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1607:1: (lv_lexpr_2_0= ruleLexpr )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1608:3: lv_lexpr_2_0= ruleLexpr
            {
            if ( state.backtracking==0 ) {
               
              	        newCompositeNode(grammarAccess.getSymbAccess().getLexprLexprParserRuleCall_2_0()); 
              	    
            }
            pushFollow(FOLLOW_ruleLexpr_in_rulesymb3261);
            lv_lexpr_2_0=ruleLexpr();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              	        if (current==null) {
              	            current = createModelElementForParent(grammarAccess.getSymbRule());
              	        }
                     		add(
                     			current, 
                     			"lexpr",
                      		lv_lexpr_2_0, 
                      		"Lexpr");
              	        afterParserOrEnumRuleCall();
              	    
            }

            }


            }

            otherlv_3=(Token)match(input,35,FOLLOW_35_in_rulesymb3273); if (state.failed) return current;
            if ( state.backtracking==0 ) {

                  	newLeafNode(otherlv_3, grammarAccess.getSymbAccess().getRightParenthesisKeyword_3());
                  
            }

            }


            }

            if ( state.backtracking==0 ) {
               leaveRule(); 
            }
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "rulesymb"


    // $ANTLR start "entryRuleLexpr"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1636:1: entryRuleLexpr returns [EObject current=null] : iv_ruleLexpr= ruleLexpr EOF ;
    public final EObject entryRuleLexpr() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLexpr = null;


        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1637:2: (iv_ruleLexpr= ruleLexpr EOF )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1638:2: iv_ruleLexpr= ruleLexpr EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getLexprRule()); 
            }
            pushFollow(FOLLOW_ruleLexpr_in_entryRuleLexpr3309);
            iv_ruleLexpr=ruleLexpr();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleLexpr; 
            }
            match(input,EOF,FOLLOW_EOF_in_entryRuleLexpr3319); if (state.failed) return current;

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLexpr"


    // $ANTLR start "ruleLexpr"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1645:1: ruleLexpr returns [EObject current=null] : ( ( (lv_expr_0_0= ruleExpr ) ) ( (lv_lexpr_1_0= ruleLexpr ) )? ) ;
    public final EObject ruleLexpr() throws RecognitionException {
        EObject current = null;

        EObject lv_expr_0_0 = null;

        EObject lv_lexpr_1_0 = null;


         enterRule(); 
            
        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1648:28: ( ( ( (lv_expr_0_0= ruleExpr ) ) ( (lv_lexpr_1_0= ruleLexpr ) )? ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1649:1: ( ( (lv_expr_0_0= ruleExpr ) ) ( (lv_lexpr_1_0= ruleLexpr ) )? )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1649:1: ( ( (lv_expr_0_0= ruleExpr ) ) ( (lv_lexpr_1_0= ruleLexpr ) )? )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1649:2: ( (lv_expr_0_0= ruleExpr ) ) ( (lv_lexpr_1_0= ruleLexpr ) )?
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1649:2: ( (lv_expr_0_0= ruleExpr ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1650:1: (lv_expr_0_0= ruleExpr )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1650:1: (lv_expr_0_0= ruleExpr )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1651:3: lv_expr_0_0= ruleExpr
            {
            if ( state.backtracking==0 ) {
               
              	        newCompositeNode(grammarAccess.getLexprAccess().getExprExprParserRuleCall_0_0()); 
              	    
            }
            pushFollow(FOLLOW_ruleExpr_in_ruleLexpr3365);
            lv_expr_0_0=ruleExpr();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              	        if (current==null) {
              	            current = createModelElementForParent(grammarAccess.getLexprRule());
              	        }
                     		add(
                     			current, 
                     			"expr",
                      		lv_expr_0_0, 
                      		"Expr");
              	        afterParserOrEnumRuleCall();
              	    
            }

            }


            }

            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1667:2: ( (lv_lexpr_1_0= ruleLexpr ) )?
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( ((LA11_0>=RULE_SYMBOL && LA11_0<=RULE_VARIABLE)||(LA11_0>=32 && LA11_0<=33)||LA11_0==41) ) {
                alt11=1;
            }
            switch (alt11) {
                case 1 :
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1668:1: (lv_lexpr_1_0= ruleLexpr )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1668:1: (lv_lexpr_1_0= ruleLexpr )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1669:3: lv_lexpr_1_0= ruleLexpr
                    {
                    if ( state.backtracking==0 ) {
                       
                      	        newCompositeNode(grammarAccess.getLexprAccess().getLexprLexprParserRuleCall_1_0()); 
                      	    
                    }
                    pushFollow(FOLLOW_ruleLexpr_in_ruleLexpr3386);
                    lv_lexpr_1_0=ruleLexpr();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      	        if (current==null) {
                      	            current = createModelElementForParent(grammarAccess.getLexprRule());
                      	        }
                             		add(
                             			current, 
                             			"lexpr",
                              		lv_lexpr_1_0, 
                              		"Lexpr");
                      	        afterParserOrEnumRuleCall();
                      	    
                    }

                    }


                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {
               leaveRule(); 
            }
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLexpr"


    // $ANTLR start "entryRuleExprAnd"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1693:1: entryRuleExprAnd returns [EObject current=null] : iv_ruleExprAnd= ruleExprAnd EOF ;
    public final EObject entryRuleExprAnd() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleExprAnd = null;


        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1694:2: (iv_ruleExprAnd= ruleExprAnd EOF )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1695:2: iv_ruleExprAnd= ruleExprAnd EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getExprAndRule()); 
            }
            pushFollow(FOLLOW_ruleExprAnd_in_entryRuleExprAnd3423);
            iv_ruleExprAnd=ruleExprAnd();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleExprAnd; 
            }
            match(input,EOF,FOLLOW_EOF_in_entryRuleExprAnd3433); if (state.failed) return current;

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleExprAnd"


    // $ANTLR start "ruleExprAnd"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1702:1: ruleExprAnd returns [EObject current=null] : ( ( (lv_exprOr_0_0= ruleExprOr ) ) (otherlv_1= 'and' ( (lv_exprAnd_2_0= ruleExprAnd ) ) )? ) ;
    public final EObject ruleExprAnd() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        EObject lv_exprOr_0_0 = null;

        EObject lv_exprAnd_2_0 = null;


         enterRule(); 
            
        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1705:28: ( ( ( (lv_exprOr_0_0= ruleExprOr ) ) (otherlv_1= 'and' ( (lv_exprAnd_2_0= ruleExprAnd ) ) )? ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1706:1: ( ( (lv_exprOr_0_0= ruleExprOr ) ) (otherlv_1= 'and' ( (lv_exprAnd_2_0= ruleExprAnd ) ) )? )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1706:1: ( ( (lv_exprOr_0_0= ruleExprOr ) ) (otherlv_1= 'and' ( (lv_exprAnd_2_0= ruleExprAnd ) ) )? )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1706:2: ( (lv_exprOr_0_0= ruleExprOr ) ) (otherlv_1= 'and' ( (lv_exprAnd_2_0= ruleExprAnd ) ) )?
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1706:2: ( (lv_exprOr_0_0= ruleExprOr ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1707:1: (lv_exprOr_0_0= ruleExprOr )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1707:1: (lv_exprOr_0_0= ruleExprOr )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1708:3: lv_exprOr_0_0= ruleExprOr
            {
            if ( state.backtracking==0 ) {
               
              	        newCompositeNode(grammarAccess.getExprAndAccess().getExprOrExprOrParserRuleCall_0_0()); 
              	    
            }
            pushFollow(FOLLOW_ruleExprOr_in_ruleExprAnd3479);
            lv_exprOr_0_0=ruleExprOr();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              	        if (current==null) {
              	            current = createModelElementForParent(grammarAccess.getExprAndRule());
              	        }
                     		add(
                     			current, 
                     			"exprOr",
                      		lv_exprOr_0_0, 
                      		"ExprOr");
              	        afterParserOrEnumRuleCall();
              	    
            }

            }


            }

            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1724:2: (otherlv_1= 'and' ( (lv_exprAnd_2_0= ruleExprAnd ) ) )?
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==39) ) {
                alt12=1;
            }
            switch (alt12) {
                case 1 :
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1724:4: otherlv_1= 'and' ( (lv_exprAnd_2_0= ruleExprAnd ) )
                    {
                    otherlv_1=(Token)match(input,39,FOLLOW_39_in_ruleExprAnd3492); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                          	newLeafNode(otherlv_1, grammarAccess.getExprAndAccess().getAndKeyword_1_0());
                          
                    }
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1728:1: ( (lv_exprAnd_2_0= ruleExprAnd ) )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1729:1: (lv_exprAnd_2_0= ruleExprAnd )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1729:1: (lv_exprAnd_2_0= ruleExprAnd )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1730:3: lv_exprAnd_2_0= ruleExprAnd
                    {
                    if ( state.backtracking==0 ) {
                       
                      	        newCompositeNode(grammarAccess.getExprAndAccess().getExprAndExprAndParserRuleCall_1_1_0()); 
                      	    
                    }
                    pushFollow(FOLLOW_ruleExprAnd_in_ruleExprAnd3513);
                    lv_exprAnd_2_0=ruleExprAnd();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      	        if (current==null) {
                      	            current = createModelElementForParent(grammarAccess.getExprAndRule());
                      	        }
                             		add(
                             			current, 
                             			"exprAnd",
                              		lv_exprAnd_2_0, 
                              		"ExprAnd");
                      	        afterParserOrEnumRuleCall();
                      	    
                    }

                    }


                    }


                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {
               leaveRule(); 
            }
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleExprAnd"


    // $ANTLR start "entryRuleExprOr"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1754:1: entryRuleExprOr returns [EObject current=null] : iv_ruleExprOr= ruleExprOr EOF ;
    public final EObject entryRuleExprOr() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleExprOr = null;


        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1755:2: (iv_ruleExprOr= ruleExprOr EOF )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1756:2: iv_ruleExprOr= ruleExprOr EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getExprOrRule()); 
            }
            pushFollow(FOLLOW_ruleExprOr_in_entryRuleExprOr3551);
            iv_ruleExprOr=ruleExprOr();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleExprOr; 
            }
            match(input,EOF,FOLLOW_EOF_in_entryRuleExprOr3561); if (state.failed) return current;

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleExprOr"


    // $ANTLR start "ruleExprOr"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1763:1: ruleExprOr returns [EObject current=null] : ( ( (lv_exprNot_0_0= ruleExprNot ) ) (otherlv_1= 'or' ( (lv_exprOr_2_0= ruleExprOr ) ) )? ) ;
    public final EObject ruleExprOr() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        EObject lv_exprNot_0_0 = null;

        EObject lv_exprOr_2_0 = null;


         enterRule(); 
            
        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1766:28: ( ( ( (lv_exprNot_0_0= ruleExprNot ) ) (otherlv_1= 'or' ( (lv_exprOr_2_0= ruleExprOr ) ) )? ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1767:1: ( ( (lv_exprNot_0_0= ruleExprNot ) ) (otherlv_1= 'or' ( (lv_exprOr_2_0= ruleExprOr ) ) )? )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1767:1: ( ( (lv_exprNot_0_0= ruleExprNot ) ) (otherlv_1= 'or' ( (lv_exprOr_2_0= ruleExprOr ) ) )? )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1767:2: ( (lv_exprNot_0_0= ruleExprNot ) ) (otherlv_1= 'or' ( (lv_exprOr_2_0= ruleExprOr ) ) )?
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1767:2: ( (lv_exprNot_0_0= ruleExprNot ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1768:1: (lv_exprNot_0_0= ruleExprNot )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1768:1: (lv_exprNot_0_0= ruleExprNot )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1769:3: lv_exprNot_0_0= ruleExprNot
            {
            if ( state.backtracking==0 ) {
               
              	        newCompositeNode(grammarAccess.getExprOrAccess().getExprNotExprNotParserRuleCall_0_0()); 
              	    
            }
            pushFollow(FOLLOW_ruleExprNot_in_ruleExprOr3607);
            lv_exprNot_0_0=ruleExprNot();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              	        if (current==null) {
              	            current = createModelElementForParent(grammarAccess.getExprOrRule());
              	        }
                     		add(
                     			current, 
                     			"exprNot",
                      		lv_exprNot_0_0, 
                      		"ExprNot");
              	        afterParserOrEnumRuleCall();
              	    
            }

            }


            }

            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1785:2: (otherlv_1= 'or' ( (lv_exprOr_2_0= ruleExprOr ) ) )?
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==40) ) {
                alt13=1;
            }
            switch (alt13) {
                case 1 :
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1785:4: otherlv_1= 'or' ( (lv_exprOr_2_0= ruleExprOr ) )
                    {
                    otherlv_1=(Token)match(input,40,FOLLOW_40_in_ruleExprOr3620); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                          	newLeafNode(otherlv_1, grammarAccess.getExprOrAccess().getOrKeyword_1_0());
                          
                    }
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1789:1: ( (lv_exprOr_2_0= ruleExprOr ) )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1790:1: (lv_exprOr_2_0= ruleExprOr )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1790:1: (lv_exprOr_2_0= ruleExprOr )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1791:3: lv_exprOr_2_0= ruleExprOr
                    {
                    if ( state.backtracking==0 ) {
                       
                      	        newCompositeNode(grammarAccess.getExprOrAccess().getExprOrExprOrParserRuleCall_1_1_0()); 
                      	    
                    }
                    pushFollow(FOLLOW_ruleExprOr_in_ruleExprOr3641);
                    lv_exprOr_2_0=ruleExprOr();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      	        if (current==null) {
                      	            current = createModelElementForParent(grammarAccess.getExprOrRule());
                      	        }
                             		add(
                             			current, 
                             			"exprOr",
                              		lv_exprOr_2_0, 
                              		"ExprOr");
                      	        afterParserOrEnumRuleCall();
                      	    
                    }

                    }


                    }


                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {
               leaveRule(); 
            }
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleExprOr"


    // $ANTLR start "entryRuleExprNot"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1815:1: entryRuleExprNot returns [EObject current=null] : iv_ruleExprNot= ruleExprNot EOF ;
    public final EObject entryRuleExprNot() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleExprNot = null;


        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1816:2: (iv_ruleExprNot= ruleExprNot EOF )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1817:2: iv_ruleExprNot= ruleExprNot EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getExprNotRule()); 
            }
            pushFollow(FOLLOW_ruleExprNot_in_entryRuleExprNot3679);
            iv_ruleExprNot=ruleExprNot();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleExprNot; 
            }
            match(input,EOF,FOLLOW_EOF_in_entryRuleExprNot3689); if (state.failed) return current;

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleExprNot"


    // $ANTLR start "ruleExprNot"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1824:1: ruleExprNot returns [EObject current=null] : ( ( (lv_name_0_0= 'not' ) )? ( (lv_exprEq_1_0= ruleExprEq ) ) ) ;
    public final EObject ruleExprNot() throws RecognitionException {
        EObject current = null;

        Token lv_name_0_0=null;
        EObject lv_exprEq_1_0 = null;


         enterRule(); 
            
        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1827:28: ( ( ( (lv_name_0_0= 'not' ) )? ( (lv_exprEq_1_0= ruleExprEq ) ) ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1828:1: ( ( (lv_name_0_0= 'not' ) )? ( (lv_exprEq_1_0= ruleExprEq ) ) )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1828:1: ( ( (lv_name_0_0= 'not' ) )? ( (lv_exprEq_1_0= ruleExprEq ) ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1828:2: ( (lv_name_0_0= 'not' ) )? ( (lv_exprEq_1_0= ruleExprEq ) )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1828:2: ( (lv_name_0_0= 'not' ) )?
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==41) ) {
                alt14=1;
            }
            switch (alt14) {
                case 1 :
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1829:1: (lv_name_0_0= 'not' )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1829:1: (lv_name_0_0= 'not' )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1830:3: lv_name_0_0= 'not'
                    {
                    lv_name_0_0=(Token)match(input,41,FOLLOW_41_in_ruleExprNot3732); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                              newLeafNode(lv_name_0_0, grammarAccess.getExprNotAccess().getNameNotKeyword_0_0());
                          
                    }
                    if ( state.backtracking==0 ) {

                      	        if (current==null) {
                      	            current = createModelElement(grammarAccess.getExprNotRule());
                      	        }
                             		setWithLastConsumed(current, "name", lv_name_0_0, "not");
                      	    
                    }

                    }


                    }
                    break;

            }

            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1843:3: ( (lv_exprEq_1_0= ruleExprEq ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1844:1: (lv_exprEq_1_0= ruleExprEq )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1844:1: (lv_exprEq_1_0= ruleExprEq )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1845:3: lv_exprEq_1_0= ruleExprEq
            {
            if ( state.backtracking==0 ) {
               
              	        newCompositeNode(grammarAccess.getExprNotAccess().getExprEqExprEqParserRuleCall_1_0()); 
              	    
            }
            pushFollow(FOLLOW_ruleExprEq_in_ruleExprNot3767);
            lv_exprEq_1_0=ruleExprEq();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              	        if (current==null) {
              	            current = createModelElementForParent(grammarAccess.getExprNotRule());
              	        }
                     		add(
                     			current, 
                     			"exprEq",
                      		lv_exprEq_1_0, 
                      		"ExprEq");
              	        afterParserOrEnumRuleCall();
              	    
            }

            }


            }


            }


            }

            if ( state.backtracking==0 ) {
               leaveRule(); 
            }
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleExprNot"


    // $ANTLR start "entryRuleExprEq"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1869:1: entryRuleExprEq returns [EObject current=null] : iv_ruleExprEq= ruleExprEq EOF ;
    public final EObject entryRuleExprEq() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleExprEq = null;


        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1870:2: (iv_ruleExprEq= ruleExprEq EOF )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1871:2: iv_ruleExprEq= ruleExprEq EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getExprEqRule()); 
            }
            pushFollow(FOLLOW_ruleExprEq_in_entryRuleExprEq3803);
            iv_ruleExprEq=ruleExprEq();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleExprEq; 
            }
            match(input,EOF,FOLLOW_EOF_in_entryRuleExprEq3813); if (state.failed) return current;

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleExprEq"


    // $ANTLR start "ruleExprEq"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1878:1: ruleExprEq returns [EObject current=null] : ( ( ( ( ruleExprEgal ) )=> (lv_exprEgal_0_0= ruleExprEgal ) ) | ( (lv_exprParent_1_0= ruleExprParent ) ) ) ;
    public final EObject ruleExprEq() throws RecognitionException {
        EObject current = null;

        EObject lv_exprEgal_0_0 = null;

        EObject lv_exprParent_1_0 = null;


         enterRule(); 
            
        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1881:28: ( ( ( ( ( ruleExprEgal ) )=> (lv_exprEgal_0_0= ruleExprEgal ) ) | ( (lv_exprParent_1_0= ruleExprParent ) ) ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1882:1: ( ( ( ( ruleExprEgal ) )=> (lv_exprEgal_0_0= ruleExprEgal ) ) | ( (lv_exprParent_1_0= ruleExprParent ) ) )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1882:1: ( ( ( ( ruleExprEgal ) )=> (lv_exprEgal_0_0= ruleExprEgal ) ) | ( (lv_exprParent_1_0= ruleExprParent ) ) )
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( (LA15_0==32) && (synpred2_InternalWh())) {
                alt15=1;
            }
            else if ( (LA15_0==RULE_VARIABLE) && (synpred2_InternalWh())) {
                alt15=1;
            }
            else if ( (LA15_0==RULE_SYMBOL) && (synpred2_InternalWh())) {
                alt15=1;
            }
            else if ( (LA15_0==33) ) {
                int LA15_4 = input.LA(2);

                if ( (synpred2_InternalWh()) ) {
                    alt15=1;
                }
                else if ( (true) ) {
                    alt15=2;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return current;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 15, 4, input);

                    throw nvae;
                }
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 15, 0, input);

                throw nvae;
            }
            switch (alt15) {
                case 1 :
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1882:2: ( ( ( ruleExprEgal ) )=> (lv_exprEgal_0_0= ruleExprEgal ) )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1882:2: ( ( ( ruleExprEgal ) )=> (lv_exprEgal_0_0= ruleExprEgal ) )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1882:3: ( ( ruleExprEgal ) )=> (lv_exprEgal_0_0= ruleExprEgal )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1887:1: (lv_exprEgal_0_0= ruleExprEgal )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1888:3: lv_exprEgal_0_0= ruleExprEgal
                    {
                    if ( state.backtracking==0 ) {
                       
                      	        newCompositeNode(grammarAccess.getExprEqAccess().getExprEgalExprEgalParserRuleCall_0_0()); 
                      	    
                    }
                    pushFollow(FOLLOW_ruleExprEgal_in_ruleExprEq3869);
                    lv_exprEgal_0_0=ruleExprEgal();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      	        if (current==null) {
                      	            current = createModelElementForParent(grammarAccess.getExprEqRule());
                      	        }
                             		add(
                             			current, 
                             			"exprEgal",
                              		lv_exprEgal_0_0, 
                              		"ExprEgal");
                      	        afterParserOrEnumRuleCall();
                      	    
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1905:6: ( (lv_exprParent_1_0= ruleExprParent ) )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1905:6: ( (lv_exprParent_1_0= ruleExprParent ) )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1906:1: (lv_exprParent_1_0= ruleExprParent )
                    {
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1906:1: (lv_exprParent_1_0= ruleExprParent )
                    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1907:3: lv_exprParent_1_0= ruleExprParent
                    {
                    if ( state.backtracking==0 ) {
                       
                      	        newCompositeNode(grammarAccess.getExprEqAccess().getExprParentExprParentParserRuleCall_1_0()); 
                      	    
                    }
                    pushFollow(FOLLOW_ruleExprParent_in_ruleExprEq3896);
                    lv_exprParent_1_0=ruleExprParent();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      	        if (current==null) {
                      	            current = createModelElementForParent(grammarAccess.getExprEqRule());
                      	        }
                             		add(
                             			current, 
                             			"exprParent",
                              		lv_exprParent_1_0, 
                              		"ExprParent");
                      	        afterParserOrEnumRuleCall();
                      	    
                    }

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {
               leaveRule(); 
            }
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleExprEq"


    // $ANTLR start "entryRuleExprEgal"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1931:1: entryRuleExprEgal returns [EObject current=null] : iv_ruleExprEgal= ruleExprEgal EOF ;
    public final EObject entryRuleExprEgal() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleExprEgal = null;


        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1932:2: (iv_ruleExprEgal= ruleExprEgal EOF )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1933:2: iv_ruleExprEgal= ruleExprEgal EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getExprEgalRule()); 
            }
            pushFollow(FOLLOW_ruleExprEgal_in_entryRuleExprEgal3932);
            iv_ruleExprEgal=ruleExprEgal();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleExprEgal; 
            }
            match(input,EOF,FOLLOW_EOF_in_entryRuleExprEgal3942); if (state.failed) return current;

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleExprEgal"


    // $ANTLR start "ruleExprEgal"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1940:1: ruleExprEgal returns [EObject current=null] : ( ( (lv_exprSimple1_0_0= ruleExprSimple ) ) otherlv_1= '=?' ( (lv_exprSimple2_2_0= ruleExprSimple ) ) ) ;
    public final EObject ruleExprEgal() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        EObject lv_exprSimple1_0_0 = null;

        EObject lv_exprSimple2_2_0 = null;


         enterRule(); 
            
        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1943:28: ( ( ( (lv_exprSimple1_0_0= ruleExprSimple ) ) otherlv_1= '=?' ( (lv_exprSimple2_2_0= ruleExprSimple ) ) ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1944:1: ( ( (lv_exprSimple1_0_0= ruleExprSimple ) ) otherlv_1= '=?' ( (lv_exprSimple2_2_0= ruleExprSimple ) ) )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1944:1: ( ( (lv_exprSimple1_0_0= ruleExprSimple ) ) otherlv_1= '=?' ( (lv_exprSimple2_2_0= ruleExprSimple ) ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1944:2: ( (lv_exprSimple1_0_0= ruleExprSimple ) ) otherlv_1= '=?' ( (lv_exprSimple2_2_0= ruleExprSimple ) )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1944:2: ( (lv_exprSimple1_0_0= ruleExprSimple ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1945:1: (lv_exprSimple1_0_0= ruleExprSimple )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1945:1: (lv_exprSimple1_0_0= ruleExprSimple )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1946:3: lv_exprSimple1_0_0= ruleExprSimple
            {
            if ( state.backtracking==0 ) {
               
              	        newCompositeNode(grammarAccess.getExprEgalAccess().getExprSimple1ExprSimpleParserRuleCall_0_0()); 
              	    
            }
            pushFollow(FOLLOW_ruleExprSimple_in_ruleExprEgal3988);
            lv_exprSimple1_0_0=ruleExprSimple();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              	        if (current==null) {
              	            current = createModelElementForParent(grammarAccess.getExprEgalRule());
              	        }
                     		add(
                     			current, 
                     			"exprSimple1",
                      		lv_exprSimple1_0_0, 
                      		"ExprSimple");
              	        afterParserOrEnumRuleCall();
              	    
            }

            }


            }

            otherlv_1=(Token)match(input,42,FOLLOW_42_in_ruleExprEgal4000); if (state.failed) return current;
            if ( state.backtracking==0 ) {

                  	newLeafNode(otherlv_1, grammarAccess.getExprEgalAccess().getEqualsSignQuestionMarkKeyword_1());
                  
            }
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1966:1: ( (lv_exprSimple2_2_0= ruleExprSimple ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1967:1: (lv_exprSimple2_2_0= ruleExprSimple )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1967:1: (lv_exprSimple2_2_0= ruleExprSimple )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1968:3: lv_exprSimple2_2_0= ruleExprSimple
            {
            if ( state.backtracking==0 ) {
               
              	        newCompositeNode(grammarAccess.getExprEgalAccess().getExprSimple2ExprSimpleParserRuleCall_2_0()); 
              	    
            }
            pushFollow(FOLLOW_ruleExprSimple_in_ruleExprEgal4021);
            lv_exprSimple2_2_0=ruleExprSimple();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              	        if (current==null) {
              	            current = createModelElementForParent(grammarAccess.getExprEgalRule());
              	        }
                     		add(
                     			current, 
                     			"exprSimple2",
                      		lv_exprSimple2_2_0, 
                      		"ExprSimple");
              	        afterParserOrEnumRuleCall();
              	    
            }

            }


            }


            }


            }

            if ( state.backtracking==0 ) {
               leaveRule(); 
            }
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleExprEgal"


    // $ANTLR start "entryRuleExprParent"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1992:1: entryRuleExprParent returns [EObject current=null] : iv_ruleExprParent= ruleExprParent EOF ;
    public final EObject entryRuleExprParent() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleExprParent = null;


        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1993:2: (iv_ruleExprParent= ruleExprParent EOF )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1994:2: iv_ruleExprParent= ruleExprParent EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getExprParentRule()); 
            }
            pushFollow(FOLLOW_ruleExprParent_in_entryRuleExprParent4057);
            iv_ruleExprParent=ruleExprParent();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleExprParent; 
            }
            match(input,EOF,FOLLOW_EOF_in_entryRuleExprParent4067); if (state.failed) return current;

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleExprParent"


    // $ANTLR start "ruleExprParent"
    // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:2001:1: ruleExprParent returns [EObject current=null] : (otherlv_0= '(' ( (lv_expr_1_0= ruleExpr ) ) otherlv_2= ')' ) ;
    public final EObject ruleExprParent() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        EObject lv_expr_1_0 = null;


         enterRule(); 
            
        try {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:2004:28: ( (otherlv_0= '(' ( (lv_expr_1_0= ruleExpr ) ) otherlv_2= ')' ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:2005:1: (otherlv_0= '(' ( (lv_expr_1_0= ruleExpr ) ) otherlv_2= ')' )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:2005:1: (otherlv_0= '(' ( (lv_expr_1_0= ruleExpr ) ) otherlv_2= ')' )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:2005:3: otherlv_0= '(' ( (lv_expr_1_0= ruleExpr ) ) otherlv_2= ')'
            {
            otherlv_0=(Token)match(input,33,FOLLOW_33_in_ruleExprParent4104); if (state.failed) return current;
            if ( state.backtracking==0 ) {

                  	newLeafNode(otherlv_0, grammarAccess.getExprParentAccess().getLeftParenthesisKeyword_0());
                  
            }
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:2009:1: ( (lv_expr_1_0= ruleExpr ) )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:2010:1: (lv_expr_1_0= ruleExpr )
            {
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:2010:1: (lv_expr_1_0= ruleExpr )
            // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:2011:3: lv_expr_1_0= ruleExpr
            {
            if ( state.backtracking==0 ) {
               
              	        newCompositeNode(grammarAccess.getExprParentAccess().getExprExprParserRuleCall_1_0()); 
              	    
            }
            pushFollow(FOLLOW_ruleExpr_in_ruleExprParent4125);
            lv_expr_1_0=ruleExpr();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              	        if (current==null) {
              	            current = createModelElementForParent(grammarAccess.getExprParentRule());
              	        }
                     		add(
                     			current, 
                     			"expr",
                      		lv_expr_1_0, 
                      		"Expr");
              	        afterParserOrEnumRuleCall();
              	    
            }

            }


            }

            otherlv_2=(Token)match(input,35,FOLLOW_35_in_ruleExprParent4137); if (state.failed) return current;
            if ( state.backtracking==0 ) {

                  	newLeafNode(otherlv_2, grammarAccess.getExprParentAccess().getRightParenthesisKeyword_2());
                  
            }

            }


            }

            if ( state.backtracking==0 ) {
               leaveRule(); 
            }
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleExprParent"

    // $ANTLR start synpred1_InternalWh
    public final void synpred1_InternalWh_fragment() throws RecognitionException {   
        // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1149:3: ( ( ruleExprSimple ) )
        // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1150:1: ( ruleExprSimple )
        {
        // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1150:1: ( ruleExprSimple )
        // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1151:1: ruleExprSimple
        {
        pushFollow(FOLLOW_ruleExprSimple_in_synpred1_InternalWh2286);
        ruleExprSimple();

        state._fsp--;
        if (state.failed) return ;

        }


        }
    }
    // $ANTLR end synpred1_InternalWh

    // $ANTLR start synpred2_InternalWh
    public final void synpred2_InternalWh_fragment() throws RecognitionException {   
        // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1882:3: ( ( ruleExprEgal ) )
        // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1883:1: ( ruleExprEgal )
        {
        // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1883:1: ( ruleExprEgal )
        // ../me.qfdk.esir.wh/src-gen/me/qfdk/esir/wh/parser/antlr/internal/InternalWh.g:1884:1: ruleExprEgal
        {
        pushFollow(FOLLOW_ruleExprEgal_in_synpred2_InternalWh3852);
        ruleExprEgal();

        state._fsp--;
        if (state.failed) return ;

        }


        }
    }
    // $ANTLR end synpred2_InternalWh

    // Delegated rules

    public final boolean synpred1_InternalWh() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred1_InternalWh_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred2_InternalWh() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred2_InternalWh_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }


    protected DFA10 dfa10 = new DFA10(this);
    static final String DFA10_eotS =
        "\12\uffff";
    static final String DFA10_eofS =
        "\12\uffff";
    static final String DFA10_minS =
        "\1\4\3\uffff\1\4\5\uffff";
    static final String DFA10_maxS =
        "\1\41\3\uffff\1\46\5\uffff";
    static final String DFA10_acceptS =
        "\1\uffff\1\1\1\2\1\3\1\uffff\1\6\1\5\1\4\1\7\1\10";
    static final String DFA10_specialS =
        "\12\uffff}>";
    static final String[] DFA10_transitionS = {
            "\1\3\1\2\32\uffff\1\1\1\4",
            "",
            "",
            "",
            "\1\11\35\uffff\1\7\1\uffff\1\6\1\5\1\10",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA10_eot = DFA.unpackEncodedString(DFA10_eotS);
    static final short[] DFA10_eof = DFA.unpackEncodedString(DFA10_eofS);
    static final char[] DFA10_min = DFA.unpackEncodedStringToUnsignedChars(DFA10_minS);
    static final char[] DFA10_max = DFA.unpackEncodedStringToUnsignedChars(DFA10_maxS);
    static final short[] DFA10_accept = DFA.unpackEncodedString(DFA10_acceptS);
    static final short[] DFA10_special = DFA.unpackEncodedString(DFA10_specialS);
    static final short[][] DFA10_transition;

    static {
        int numStates = DFA10_transitionS.length;
        DFA10_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA10_transition[i] = DFA.unpackEncodedString(DFA10_transitionS[i]);
        }
    }

    class DFA10 extends DFA {

        public DFA10(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 10;
            this.eot = DFA10_eot;
            this.eof = DFA10_eof;
            this.min = DFA10_min;
            this.max = DFA10_max;
            this.accept = DFA10_accept;
            this.special = DFA10_special;
            this.transition = DFA10_transition;
        }
        public String getDescription() {
            return "1211:1: ( ( (lv_nil_0_0= 'nil' ) ) | ( (lv_name1_1_0= RULE_VARIABLE ) ) | ( (lv_name2_2_0= RULE_SYMBOL ) ) | ( (lv_cons_3_0= rulecons ) ) | ( (lv_list_4_0= rulelist ) ) | ( (lv_hd_5_0= rulehd ) ) | ( (lv_tl_6_0= ruletl ) ) | ( (lv_symb_7_0= rulesymb ) ) )";
        }
    }
 

    public static final BitSet FOLLOW_rulewh_in_entryRulewh75 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRulewh85 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFunction_in_rulewh130 = new BitSet(new long[]{0x0000000000002002L});
    public static final BitSet FOLLOW_ruleFunction_in_entryRuleFunction166 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleFunction176 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_13_in_ruleFunction213 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_SYMBOL_in_ruleFunction230 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_14_in_ruleFunction247 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_ruleDefinition_in_ruleFunction268 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleDefinition_in_entryRuleDefinition304 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleDefinition314 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_15_in_ruleDefinition351 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_ruleInput_in_ruleDefinition372 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_16_in_ruleDefinition384 = new BitSet(new long[]{0x0000000046500020L});
    public static final BitSet FOLLOW_ruleCommands_in_ruleDefinition405 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_16_in_ruleDefinition417 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_17_in_ruleDefinition429 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_ruleOutput_in_ruleDefinition450 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleInput_in_entryRuleInput486 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleInput496 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_VARIABLE_in_ruleInput539 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_18_in_ruleInput556 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_ruleInput_in_ruleInput577 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_VARIABLE_in_ruleInput601 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleOutput_in_entryRuleOutput642 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleOutput652 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_VARIABLE_in_ruleOutput695 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_18_in_ruleOutput712 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_ruleOutput_in_ruleOutput733 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_VARIABLE_in_ruleOutput757 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleCommands_in_entryRuleCommands798 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleCommands808 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleCommand_in_ruleCommands854 = new BitSet(new long[]{0x0000000000080002L});
    public static final BitSet FOLLOW_19_in_ruleCommands867 = new BitSet(new long[]{0x0000000046500020L});
    public static final BitSet FOLLOW_ruleCommands_in_ruleCommands888 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleCommand_in_entryRuleCommand926 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleCommand936 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_20_in_ruleCommand979 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleaffectation_in_ruleCommand1019 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rulewhileCommand_in_ruleCommand1046 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleforCommand_in_ruleCommand1073 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleifCommand_in_ruleCommand1100 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleforeachCommand_in_ruleCommand1127 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleaffectation_in_entryRuleaffectation1163 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleaffectation1173 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleVars_in_ruleaffectation1219 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_21_in_ruleaffectation1231 = new BitSet(new long[]{0x0000020300000030L});
    public static final BitSet FOLLOW_ruleExprs_in_ruleaffectation1252 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rulewhileCommand_in_entryRulewhileCommand1288 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRulewhileCommand1298 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_22_in_rulewhileCommand1335 = new BitSet(new long[]{0x0000020300000030L});
    public static final BitSet FOLLOW_ruleExpr_in_rulewhileCommand1356 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_23_in_rulewhileCommand1368 = new BitSet(new long[]{0x0000000046500020L});
    public static final BitSet FOLLOW_ruleCommands_in_rulewhileCommand1389 = new BitSet(new long[]{0x0000000001000000L});
    public static final BitSet FOLLOW_24_in_rulewhileCommand1401 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleforCommand_in_entryRuleforCommand1437 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleforCommand1447 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_25_in_ruleforCommand1484 = new BitSet(new long[]{0x0000020300000030L});
    public static final BitSet FOLLOW_ruleExpr_in_ruleforCommand1505 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_23_in_ruleforCommand1517 = new BitSet(new long[]{0x0000000046500020L});
    public static final BitSet FOLLOW_ruleCommands_in_ruleforCommand1538 = new BitSet(new long[]{0x0000000001000000L});
    public static final BitSet FOLLOW_24_in_ruleforCommand1550 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleifCommand_in_entryRuleifCommand1586 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleifCommand1596 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_26_in_ruleifCommand1633 = new BitSet(new long[]{0x0000020300000030L});
    public static final BitSet FOLLOW_ruleExpr_in_ruleifCommand1654 = new BitSet(new long[]{0x0000000008000000L});
    public static final BitSet FOLLOW_27_in_ruleifCommand1666 = new BitSet(new long[]{0x0000000046500020L});
    public static final BitSet FOLLOW_ruleCommands_in_ruleifCommand1687 = new BitSet(new long[]{0x0000000030000000L});
    public static final BitSet FOLLOW_28_in_ruleifCommand1700 = new BitSet(new long[]{0x0000000046500020L});
    public static final BitSet FOLLOW_ruleCommands_in_ruleifCommand1721 = new BitSet(new long[]{0x0000000020000000L});
    public static final BitSet FOLLOW_29_in_ruleifCommand1735 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleforeachCommand_in_entryRuleforeachCommand1771 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleforeachCommand1781 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_30_in_ruleforeachCommand1818 = new BitSet(new long[]{0x0000020300000030L});
    public static final BitSet FOLLOW_ruleExpr_in_ruleforeachCommand1839 = new BitSet(new long[]{0x0000000080000000L});
    public static final BitSet FOLLOW_31_in_ruleforeachCommand1851 = new BitSet(new long[]{0x0000020300000030L});
    public static final BitSet FOLLOW_ruleExpr_in_ruleforeachCommand1872 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_23_in_ruleforeachCommand1884 = new BitSet(new long[]{0x0000000046500020L});
    public static final BitSet FOLLOW_ruleCommands_in_ruleforeachCommand1905 = new BitSet(new long[]{0x0000000001000000L});
    public static final BitSet FOLLOW_24_in_ruleforeachCommand1917 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleVars_in_entryRuleVars1953 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleVars1963 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_VARIABLE_in_ruleVars2006 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_18_in_ruleVars2023 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_ruleVars_in_ruleVars2044 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_VARIABLE_in_ruleVars2068 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleExprs_in_entryRuleExprs2109 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleExprs2119 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleExpr_in_ruleExprs2165 = new BitSet(new long[]{0x0000000000040002L});
    public static final BitSet FOLLOW_18_in_ruleExprs2178 = new BitSet(new long[]{0x0000020300000030L});
    public static final BitSet FOLLOW_ruleExprs_in_ruleExprs2199 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleExpr_in_entryRuleExpr2237 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleExpr2247 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleExprSimple_in_ruleExpr2303 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleExprAnd_in_ruleExpr2330 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleExprSimple_in_entryRuleExprSimple2366 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleExprSimple2376 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_32_in_ruleExprSimple2419 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_VARIABLE_in_ruleExprSimple2455 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_SYMBOL_in_ruleExprSimple2483 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rulecons_in_ruleExprSimple2515 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rulelist_in_ruleExprSimple2542 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rulehd_in_ruleExprSimple2569 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruletl_in_ruleExprSimple2596 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rulesymb_in_ruleExprSimple2623 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rulecons_in_entryRulecons2659 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRulecons2669 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_33_in_rulecons2706 = new BitSet(new long[]{0x0000000400000000L});
    public static final BitSet FOLLOW_34_in_rulecons2718 = new BitSet(new long[]{0x0000020300000030L});
    public static final BitSet FOLLOW_ruleLexpr_in_rulecons2739 = new BitSet(new long[]{0x0000000800000000L});
    public static final BitSet FOLLOW_35_in_rulecons2751 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rulelist_in_entryRulelist2787 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRulelist2797 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_33_in_rulelist2834 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_36_in_rulelist2846 = new BitSet(new long[]{0x0000020300000030L});
    public static final BitSet FOLLOW_ruleLexpr_in_rulelist2867 = new BitSet(new long[]{0x0000000800000000L});
    public static final BitSet FOLLOW_35_in_rulelist2879 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rulehd_in_entryRulehd2915 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRulehd2925 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_33_in_rulehd2962 = new BitSet(new long[]{0x0000002000000000L});
    public static final BitSet FOLLOW_37_in_rulehd2974 = new BitSet(new long[]{0x0000020300000030L});
    public static final BitSet FOLLOW_ruleExpr_in_rulehd2995 = new BitSet(new long[]{0x0000000800000000L});
    public static final BitSet FOLLOW_35_in_rulehd3007 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruletl_in_entryRuletl3043 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuletl3053 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_33_in_ruletl3090 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_38_in_ruletl3102 = new BitSet(new long[]{0x0000020300000030L});
    public static final BitSet FOLLOW_ruleExpr_in_ruletl3123 = new BitSet(new long[]{0x0000000800000000L});
    public static final BitSet FOLLOW_35_in_ruletl3135 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rulesymb_in_entryRulesymb3171 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRulesymb3181 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_33_in_rulesymb3218 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_SYMBOL_in_rulesymb3235 = new BitSet(new long[]{0x0000020300000030L});
    public static final BitSet FOLLOW_ruleLexpr_in_rulesymb3261 = new BitSet(new long[]{0x0000000800000000L});
    public static final BitSet FOLLOW_35_in_rulesymb3273 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleLexpr_in_entryRuleLexpr3309 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleLexpr3319 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleExpr_in_ruleLexpr3365 = new BitSet(new long[]{0x0000020300000032L});
    public static final BitSet FOLLOW_ruleLexpr_in_ruleLexpr3386 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleExprAnd_in_entryRuleExprAnd3423 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleExprAnd3433 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleExprOr_in_ruleExprAnd3479 = new BitSet(new long[]{0x0000008000000002L});
    public static final BitSet FOLLOW_39_in_ruleExprAnd3492 = new BitSet(new long[]{0x0000020300000030L});
    public static final BitSet FOLLOW_ruleExprAnd_in_ruleExprAnd3513 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleExprOr_in_entryRuleExprOr3551 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleExprOr3561 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleExprNot_in_ruleExprOr3607 = new BitSet(new long[]{0x0000010000000002L});
    public static final BitSet FOLLOW_40_in_ruleExprOr3620 = new BitSet(new long[]{0x0000020300000030L});
    public static final BitSet FOLLOW_ruleExprOr_in_ruleExprOr3641 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleExprNot_in_entryRuleExprNot3679 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleExprNot3689 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_41_in_ruleExprNot3732 = new BitSet(new long[]{0x0000020300000030L});
    public static final BitSet FOLLOW_ruleExprEq_in_ruleExprNot3767 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleExprEq_in_entryRuleExprEq3803 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleExprEq3813 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleExprEgal_in_ruleExprEq3869 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleExprParent_in_ruleExprEq3896 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleExprEgal_in_entryRuleExprEgal3932 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleExprEgal3942 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleExprSimple_in_ruleExprEgal3988 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_42_in_ruleExprEgal4000 = new BitSet(new long[]{0x0000000300000030L});
    public static final BitSet FOLLOW_ruleExprSimple_in_ruleExprEgal4021 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleExprParent_in_entryRuleExprParent4057 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleExprParent4067 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_33_in_ruleExprParent4104 = new BitSet(new long[]{0x0000020300000030L});
    public static final BitSet FOLLOW_ruleExpr_in_ruleExprParent4125 = new BitSet(new long[]{0x0000000800000000L});
    public static final BitSet FOLLOW_35_in_ruleExprParent4137 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleExprSimple_in_synpred1_InternalWh2286 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleExprEgal_in_synpred2_InternalWh3852 = new BitSet(new long[]{0x0000000000000002L});

}