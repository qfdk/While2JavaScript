/**
 */
package me.qfdk.esir.wh.wh;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Definition</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link me.qfdk.esir.wh.wh.Definition#getEntree <em>Entree</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.Definition#getCmd <em>Cmd</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.Definition#getSortie <em>Sortie</em>}</li>
 * </ul>
 *
 * @see me.qfdk.esir.wh.wh.WhPackage#getDefinition()
 * @model
 * @generated
 */
public interface Definition extends EObject
{
  /**
   * Returns the value of the '<em><b>Entree</b></em>' containment reference list.
   * The list contents are of type {@link me.qfdk.esir.wh.wh.Input}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Entree</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Entree</em>' containment reference list.
   * @see me.qfdk.esir.wh.wh.WhPackage#getDefinition_Entree()
   * @model containment="true"
   * @generated
   */
  EList<Input> getEntree();

  /**
   * Returns the value of the '<em><b>Cmd</b></em>' containment reference list.
   * The list contents are of type {@link me.qfdk.esir.wh.wh.Commands}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Cmd</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Cmd</em>' containment reference list.
   * @see me.qfdk.esir.wh.wh.WhPackage#getDefinition_Cmd()
   * @model containment="true"
   * @generated
   */
  EList<Commands> getCmd();

  /**
   * Returns the value of the '<em><b>Sortie</b></em>' containment reference list.
   * The list contents are of type {@link me.qfdk.esir.wh.wh.Output}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Sortie</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Sortie</em>' containment reference list.
   * @see me.qfdk.esir.wh.wh.WhPackage#getDefinition_Sortie()
   * @model containment="true"
   * @generated
   */
  EList<Output> getSortie();

} // Definition
