/**
 */
package me.qfdk.esir.wh.wh;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>affectation</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link me.qfdk.esir.wh.wh.affectation#getVars <em>Vars</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.affectation#getExprs <em>Exprs</em>}</li>
 * </ul>
 *
 * @see me.qfdk.esir.wh.wh.WhPackage#getaffectation()
 * @model
 * @generated
 */
public interface affectation extends EObject
{
  /**
   * Returns the value of the '<em><b>Vars</b></em>' containment reference list.
   * The list contents are of type {@link me.qfdk.esir.wh.wh.Vars}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Vars</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Vars</em>' containment reference list.
   * @see me.qfdk.esir.wh.wh.WhPackage#getaffectation_Vars()
   * @model containment="true"
   * @generated
   */
  EList<Vars> getVars();

  /**
   * Returns the value of the '<em><b>Exprs</b></em>' containment reference list.
   * The list contents are of type {@link me.qfdk.esir.wh.wh.Exprs}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Exprs</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Exprs</em>' containment reference list.
   * @see me.qfdk.esir.wh.wh.WhPackage#getaffectation_Exprs()
   * @model containment="true"
   * @generated
   */
  EList<Exprs> getExprs();

} // affectation
