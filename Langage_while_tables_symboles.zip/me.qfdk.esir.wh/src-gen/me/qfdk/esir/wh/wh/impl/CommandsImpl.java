/**
 */
package me.qfdk.esir.wh.wh.impl;

import java.util.Collection;

import me.qfdk.esir.wh.wh.Command;
import me.qfdk.esir.wh.wh.Commands;
import me.qfdk.esir.wh.wh.WhPackage;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Commands</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link me.qfdk.esir.wh.wh.impl.CommandsImpl#getCmd1 <em>Cmd1</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.impl.CommandsImpl#getCmd <em>Cmd</em>}</li>
 * </ul>
 *
 * @generated
 */
public class CommandsImpl extends MinimalEObjectImpl.Container implements Commands
{
  /**
   * The cached value of the '{@link #getCmd1() <em>Cmd1</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getCmd1()
   * @generated
   * @ordered
   */
  protected EList<Command> cmd1;

  /**
   * The cached value of the '{@link #getCmd() <em>Cmd</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getCmd()
   * @generated
   * @ordered
   */
  protected EList<Commands> cmd;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected CommandsImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return WhPackage.Literals.COMMANDS;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Command> getCmd1()
  {
    if (cmd1 == null)
    {
      cmd1 = new EObjectContainmentEList<Command>(Command.class, this, WhPackage.COMMANDS__CMD1);
    }
    return cmd1;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Commands> getCmd()
  {
    if (cmd == null)
    {
      cmd = new EObjectContainmentEList<Commands>(Commands.class, this, WhPackage.COMMANDS__CMD);
    }
    return cmd;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case WhPackage.COMMANDS__CMD1:
        return ((InternalEList<?>)getCmd1()).basicRemove(otherEnd, msgs);
      case WhPackage.COMMANDS__CMD:
        return ((InternalEList<?>)getCmd()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case WhPackage.COMMANDS__CMD1:
        return getCmd1();
      case WhPackage.COMMANDS__CMD:
        return getCmd();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case WhPackage.COMMANDS__CMD1:
        getCmd1().clear();
        getCmd1().addAll((Collection<? extends Command>)newValue);
        return;
      case WhPackage.COMMANDS__CMD:
        getCmd().clear();
        getCmd().addAll((Collection<? extends Commands>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case WhPackage.COMMANDS__CMD1:
        getCmd1().clear();
        return;
      case WhPackage.COMMANDS__CMD:
        getCmd().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case WhPackage.COMMANDS__CMD1:
        return cmd1 != null && !cmd1.isEmpty();
      case WhPackage.COMMANDS__CMD:
        return cmd != null && !cmd.isEmpty();
    }
    return super.eIsSet(featureID);
  }

} //CommandsImpl
