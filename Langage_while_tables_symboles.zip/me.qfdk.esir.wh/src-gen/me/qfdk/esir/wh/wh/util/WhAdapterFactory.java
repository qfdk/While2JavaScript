/**
 */
package me.qfdk.esir.wh.wh.util;

import me.qfdk.esir.wh.wh.*;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see me.qfdk.esir.wh.wh.WhPackage
 * @generated
 */
public class WhAdapterFactory extends AdapterFactoryImpl
{
  /**
   * The cached model package.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected static WhPackage modelPackage;

  /**
   * Creates an instance of the adapter factory.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public WhAdapterFactory()
  {
    if (modelPackage == null)
    {
      modelPackage = WhPackage.eINSTANCE;
    }
  }

  /**
   * Returns whether this factory is applicable for the type of the object.
   * <!-- begin-user-doc -->
   * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
   * <!-- end-user-doc -->
   * @return whether this factory is applicable for the type of the object.
   * @generated
   */
  @Override
  public boolean isFactoryForType(Object object)
  {
    if (object == modelPackage)
    {
      return true;
    }
    if (object instanceof EObject)
    {
      return ((EObject)object).eClass().getEPackage() == modelPackage;
    }
    return false;
  }

  /**
   * The switch that delegates to the <code>createXXX</code> methods.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected WhSwitch<Adapter> modelSwitch =
    new WhSwitch<Adapter>()
    {
      @Override
      public Adapter casewh(wh object)
      {
        return createwhAdapter();
      }
      @Override
      public Adapter caseFunction(Function object)
      {
        return createFunctionAdapter();
      }
      @Override
      public Adapter caseDefinition(Definition object)
      {
        return createDefinitionAdapter();
      }
      @Override
      public Adapter caseInput(Input object)
      {
        return createInputAdapter();
      }
      @Override
      public Adapter caseOutput(Output object)
      {
        return createOutputAdapter();
      }
      @Override
      public Adapter caseCommands(Commands object)
      {
        return createCommandsAdapter();
      }
      @Override
      public Adapter caseCommand(Command object)
      {
        return createCommandAdapter();
      }
      @Override
      public Adapter caseaffectation(affectation object)
      {
        return createaffectationAdapter();
      }
      @Override
      public Adapter casewhileCommand(whileCommand object)
      {
        return createwhileCommandAdapter();
      }
      @Override
      public Adapter caseforCommand(forCommand object)
      {
        return createforCommandAdapter();
      }
      @Override
      public Adapter caseifCommand(ifCommand object)
      {
        return createifCommandAdapter();
      }
      @Override
      public Adapter caseforeachCommand(foreachCommand object)
      {
        return createforeachCommandAdapter();
      }
      @Override
      public Adapter caseVars(Vars object)
      {
        return createVarsAdapter();
      }
      @Override
      public Adapter caseExprs(Exprs object)
      {
        return createExprsAdapter();
      }
      @Override
      public Adapter caseExpr(Expr object)
      {
        return createExprAdapter();
      }
      @Override
      public Adapter caseExprSimple(ExprSimple object)
      {
        return createExprSimpleAdapter();
      }
      @Override
      public Adapter casecons(cons object)
      {
        return createconsAdapter();
      }
      @Override
      public Adapter caselist(list object)
      {
        return createlistAdapter();
      }
      @Override
      public Adapter casehd(hd object)
      {
        return createhdAdapter();
      }
      @Override
      public Adapter casetl(tl object)
      {
        return createtlAdapter();
      }
      @Override
      public Adapter casesymb(symb object)
      {
        return createsymbAdapter();
      }
      @Override
      public Adapter caseLexpr(Lexpr object)
      {
        return createLexprAdapter();
      }
      @Override
      public Adapter caseExprAnd(ExprAnd object)
      {
        return createExprAndAdapter();
      }
      @Override
      public Adapter caseExprOr(ExprOr object)
      {
        return createExprOrAdapter();
      }
      @Override
      public Adapter caseExprNot(ExprNot object)
      {
        return createExprNotAdapter();
      }
      @Override
      public Adapter caseExprEq(ExprEq object)
      {
        return createExprEqAdapter();
      }
      @Override
      public Adapter caseExprEgal(ExprEgal object)
      {
        return createExprEgalAdapter();
      }
      @Override
      public Adapter caseExprParent(ExprParent object)
      {
        return createExprParentAdapter();
      }
      @Override
      public Adapter defaultCase(EObject object)
      {
        return createEObjectAdapter();
      }
    };

  /**
   * Creates an adapter for the <code>target</code>.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param target the object to adapt.
   * @return the adapter for the <code>target</code>.
   * @generated
   */
  @Override
  public Adapter createAdapter(Notifier target)
  {
    return modelSwitch.doSwitch((EObject)target);
  }


  /**
   * Creates a new adapter for an object of class '{@link me.qfdk.esir.wh.wh.wh <em>wh</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see me.qfdk.esir.wh.wh.wh
   * @generated
   */
  public Adapter createwhAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link me.qfdk.esir.wh.wh.Function <em>Function</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see me.qfdk.esir.wh.wh.Function
   * @generated
   */
  public Adapter createFunctionAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link me.qfdk.esir.wh.wh.Definition <em>Definition</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see me.qfdk.esir.wh.wh.Definition
   * @generated
   */
  public Adapter createDefinitionAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link me.qfdk.esir.wh.wh.Input <em>Input</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see me.qfdk.esir.wh.wh.Input
   * @generated
   */
  public Adapter createInputAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link me.qfdk.esir.wh.wh.Output <em>Output</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see me.qfdk.esir.wh.wh.Output
   * @generated
   */
  public Adapter createOutputAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link me.qfdk.esir.wh.wh.Commands <em>Commands</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see me.qfdk.esir.wh.wh.Commands
   * @generated
   */
  public Adapter createCommandsAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link me.qfdk.esir.wh.wh.Command <em>Command</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see me.qfdk.esir.wh.wh.Command
   * @generated
   */
  public Adapter createCommandAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link me.qfdk.esir.wh.wh.affectation <em>affectation</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see me.qfdk.esir.wh.wh.affectation
   * @generated
   */
  public Adapter createaffectationAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link me.qfdk.esir.wh.wh.whileCommand <em>while Command</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see me.qfdk.esir.wh.wh.whileCommand
   * @generated
   */
  public Adapter createwhileCommandAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link me.qfdk.esir.wh.wh.forCommand <em>for Command</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see me.qfdk.esir.wh.wh.forCommand
   * @generated
   */
  public Adapter createforCommandAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link me.qfdk.esir.wh.wh.ifCommand <em>if Command</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see me.qfdk.esir.wh.wh.ifCommand
   * @generated
   */
  public Adapter createifCommandAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link me.qfdk.esir.wh.wh.foreachCommand <em>foreach Command</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see me.qfdk.esir.wh.wh.foreachCommand
   * @generated
   */
  public Adapter createforeachCommandAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link me.qfdk.esir.wh.wh.Vars <em>Vars</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see me.qfdk.esir.wh.wh.Vars
   * @generated
   */
  public Adapter createVarsAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link me.qfdk.esir.wh.wh.Exprs <em>Exprs</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see me.qfdk.esir.wh.wh.Exprs
   * @generated
   */
  public Adapter createExprsAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link me.qfdk.esir.wh.wh.Expr <em>Expr</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see me.qfdk.esir.wh.wh.Expr
   * @generated
   */
  public Adapter createExprAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link me.qfdk.esir.wh.wh.ExprSimple <em>Expr Simple</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see me.qfdk.esir.wh.wh.ExprSimple
   * @generated
   */
  public Adapter createExprSimpleAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link me.qfdk.esir.wh.wh.cons <em>cons</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see me.qfdk.esir.wh.wh.cons
   * @generated
   */
  public Adapter createconsAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link me.qfdk.esir.wh.wh.list <em>list</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see me.qfdk.esir.wh.wh.list
   * @generated
   */
  public Adapter createlistAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link me.qfdk.esir.wh.wh.hd <em>hd</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see me.qfdk.esir.wh.wh.hd
   * @generated
   */
  public Adapter createhdAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link me.qfdk.esir.wh.wh.tl <em>tl</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see me.qfdk.esir.wh.wh.tl
   * @generated
   */
  public Adapter createtlAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link me.qfdk.esir.wh.wh.symb <em>symb</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see me.qfdk.esir.wh.wh.symb
   * @generated
   */
  public Adapter createsymbAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link me.qfdk.esir.wh.wh.Lexpr <em>Lexpr</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see me.qfdk.esir.wh.wh.Lexpr
   * @generated
   */
  public Adapter createLexprAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link me.qfdk.esir.wh.wh.ExprAnd <em>Expr And</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see me.qfdk.esir.wh.wh.ExprAnd
   * @generated
   */
  public Adapter createExprAndAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link me.qfdk.esir.wh.wh.ExprOr <em>Expr Or</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see me.qfdk.esir.wh.wh.ExprOr
   * @generated
   */
  public Adapter createExprOrAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link me.qfdk.esir.wh.wh.ExprNot <em>Expr Not</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see me.qfdk.esir.wh.wh.ExprNot
   * @generated
   */
  public Adapter createExprNotAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link me.qfdk.esir.wh.wh.ExprEq <em>Expr Eq</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see me.qfdk.esir.wh.wh.ExprEq
   * @generated
   */
  public Adapter createExprEqAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link me.qfdk.esir.wh.wh.ExprEgal <em>Expr Egal</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see me.qfdk.esir.wh.wh.ExprEgal
   * @generated
   */
  public Adapter createExprEgalAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link me.qfdk.esir.wh.wh.ExprParent <em>Expr Parent</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see me.qfdk.esir.wh.wh.ExprParent
   * @generated
   */
  public Adapter createExprParentAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for the default case.
   * <!-- begin-user-doc -->
   * This default implementation returns null.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @generated
   */
  public Adapter createEObjectAdapter()
  {
    return null;
  }

} //WhAdapterFactory
