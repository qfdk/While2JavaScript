/**
 */
package me.qfdk.esir.wh.wh.impl;

import me.qfdk.esir.wh.wh.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class WhFactoryImpl extends EFactoryImpl implements WhFactory
{
  /**
   * Creates the default factory implementation.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static WhFactory init()
  {
    try
    {
      WhFactory theWhFactory = (WhFactory)EPackage.Registry.INSTANCE.getEFactory(WhPackage.eNS_URI);
      if (theWhFactory != null)
      {
        return theWhFactory;
      }
    }
    catch (Exception exception)
    {
      EcorePlugin.INSTANCE.log(exception);
    }
    return new WhFactoryImpl();
  }

  /**
   * Creates an instance of the factory.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public WhFactoryImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public EObject create(EClass eClass)
  {
    switch (eClass.getClassifierID())
    {
      case WhPackage.WH: return createwh();
      case WhPackage.FUNCTION: return createFunction();
      case WhPackage.DEFINITION: return createDefinition();
      case WhPackage.INPUT: return createInput();
      case WhPackage.OUTPUT: return createOutput();
      case WhPackage.COMMANDS: return createCommands();
      case WhPackage.COMMAND: return createCommand();
      case WhPackage.AFFECTATION: return createaffectation();
      case WhPackage.WHILE_COMMAND: return createwhileCommand();
      case WhPackage.FOR_COMMAND: return createforCommand();
      case WhPackage.IF_COMMAND: return createifCommand();
      case WhPackage.FOREACH_COMMAND: return createforeachCommand();
      case WhPackage.VARS: return createVars();
      case WhPackage.EXPRS: return createExprs();
      case WhPackage.EXPR: return createExpr();
      case WhPackage.EXPR_SIMPLE: return createExprSimple();
      case WhPackage.CONS: return createcons();
      case WhPackage.LIST: return createlist();
      case WhPackage.HD: return createhd();
      case WhPackage.TL: return createtl();
      case WhPackage.SYMB: return createsymb();
      case WhPackage.LEXPR: return createLexpr();
      case WhPackage.EXPR_AND: return createExprAnd();
      case WhPackage.EXPR_OR: return createExprOr();
      case WhPackage.EXPR_NOT: return createExprNot();
      case WhPackage.EXPR_EQ: return createExprEq();
      case WhPackage.EXPR_EGAL: return createExprEgal();
      case WhPackage.EXPR_PARENT: return createExprParent();
      default:
        throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
    }
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public wh createwh()
  {
    whImpl wh = new whImpl();
    return wh;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Function createFunction()
  {
    FunctionImpl function = new FunctionImpl();
    return function;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Definition createDefinition()
  {
    DefinitionImpl definition = new DefinitionImpl();
    return definition;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Input createInput()
  {
    InputImpl input = new InputImpl();
    return input;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Output createOutput()
  {
    OutputImpl output = new OutputImpl();
    return output;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Commands createCommands()
  {
    CommandsImpl commands = new CommandsImpl();
    return commands;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Command createCommand()
  {
    CommandImpl command = new CommandImpl();
    return command;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public affectation createaffectation()
  {
    affectationImpl affectation = new affectationImpl();
    return affectation;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public whileCommand createwhileCommand()
  {
    whileCommandImpl whileCommand = new whileCommandImpl();
    return whileCommand;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public forCommand createforCommand()
  {
    forCommandImpl forCommand = new forCommandImpl();
    return forCommand;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ifCommand createifCommand()
  {
    ifCommandImpl ifCommand = new ifCommandImpl();
    return ifCommand;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public foreachCommand createforeachCommand()
  {
    foreachCommandImpl foreachCommand = new foreachCommandImpl();
    return foreachCommand;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Vars createVars()
  {
    VarsImpl vars = new VarsImpl();
    return vars;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Exprs createExprs()
  {
    ExprsImpl exprs = new ExprsImpl();
    return exprs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Expr createExpr()
  {
    ExprImpl expr = new ExprImpl();
    return expr;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ExprSimple createExprSimple()
  {
    ExprSimpleImpl exprSimple = new ExprSimpleImpl();
    return exprSimple;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public cons createcons()
  {
    consImpl cons = new consImpl();
    return cons;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public list createlist()
  {
    listImpl list = new listImpl();
    return list;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public hd createhd()
  {
    hdImpl hd = new hdImpl();
    return hd;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public tl createtl()
  {
    tlImpl tl = new tlImpl();
    return tl;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public symb createsymb()
  {
    symbImpl symb = new symbImpl();
    return symb;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Lexpr createLexpr()
  {
    LexprImpl lexpr = new LexprImpl();
    return lexpr;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ExprAnd createExprAnd()
  {
    ExprAndImpl exprAnd = new ExprAndImpl();
    return exprAnd;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ExprOr createExprOr()
  {
    ExprOrImpl exprOr = new ExprOrImpl();
    return exprOr;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ExprNot createExprNot()
  {
    ExprNotImpl exprNot = new ExprNotImpl();
    return exprNot;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ExprEq createExprEq()
  {
    ExprEqImpl exprEq = new ExprEqImpl();
    return exprEq;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ExprEgal createExprEgal()
  {
    ExprEgalImpl exprEgal = new ExprEgalImpl();
    return exprEgal;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ExprParent createExprParent()
  {
    ExprParentImpl exprParent = new ExprParentImpl();
    return exprParent;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public WhPackage getWhPackage()
  {
    return (WhPackage)getEPackage();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @deprecated
   * @generated
   */
  @Deprecated
  public static WhPackage getPackage()
  {
    return WhPackage.eINSTANCE;
  }

} //WhFactoryImpl
