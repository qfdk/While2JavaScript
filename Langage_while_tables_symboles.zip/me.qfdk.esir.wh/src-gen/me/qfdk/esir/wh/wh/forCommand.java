/**
 */
package me.qfdk.esir.wh.wh;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>for Command</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link me.qfdk.esir.wh.wh.forCommand#getExpr <em>Expr</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.forCommand#getCmd <em>Cmd</em>}</li>
 * </ul>
 *
 * @see me.qfdk.esir.wh.wh.WhPackage#getforCommand()
 * @model
 * @generated
 */
public interface forCommand extends EObject
{
  /**
   * Returns the value of the '<em><b>Expr</b></em>' containment reference list.
   * The list contents are of type {@link me.qfdk.esir.wh.wh.Expr}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Expr</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Expr</em>' containment reference list.
   * @see me.qfdk.esir.wh.wh.WhPackage#getforCommand_Expr()
   * @model containment="true"
   * @generated
   */
  EList<Expr> getExpr();

  /**
   * Returns the value of the '<em><b>Cmd</b></em>' containment reference list.
   * The list contents are of type {@link me.qfdk.esir.wh.wh.Commands}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Cmd</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Cmd</em>' containment reference list.
   * @see me.qfdk.esir.wh.wh.WhPackage#getforCommand_Cmd()
   * @model containment="true"
   * @generated
   */
  EList<Commands> getCmd();

} // forCommand
