/**
 */
package me.qfdk.esir.wh.wh.impl;

import java.util.Collection;

import me.qfdk.esir.wh.wh.Commands;
import me.qfdk.esir.wh.wh.Expr;
import me.qfdk.esir.wh.wh.WhPackage;
import me.qfdk.esir.wh.wh.forCommand;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>for Command</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link me.qfdk.esir.wh.wh.impl.forCommandImpl#getExpr <em>Expr</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.impl.forCommandImpl#getCmd <em>Cmd</em>}</li>
 * </ul>
 *
 * @generated
 */
public class forCommandImpl extends MinimalEObjectImpl.Container implements forCommand
{
  /**
   * The cached value of the '{@link #getExpr() <em>Expr</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getExpr()
   * @generated
   * @ordered
   */
  protected EList<Expr> expr;

  /**
   * The cached value of the '{@link #getCmd() <em>Cmd</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getCmd()
   * @generated
   * @ordered
   */
  protected EList<Commands> cmd;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected forCommandImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return WhPackage.Literals.FOR_COMMAND;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Expr> getExpr()
  {
    if (expr == null)
    {
      expr = new EObjectContainmentEList<Expr>(Expr.class, this, WhPackage.FOR_COMMAND__EXPR);
    }
    return expr;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Commands> getCmd()
  {
    if (cmd == null)
    {
      cmd = new EObjectContainmentEList<Commands>(Commands.class, this, WhPackage.FOR_COMMAND__CMD);
    }
    return cmd;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case WhPackage.FOR_COMMAND__EXPR:
        return ((InternalEList<?>)getExpr()).basicRemove(otherEnd, msgs);
      case WhPackage.FOR_COMMAND__CMD:
        return ((InternalEList<?>)getCmd()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case WhPackage.FOR_COMMAND__EXPR:
        return getExpr();
      case WhPackage.FOR_COMMAND__CMD:
        return getCmd();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case WhPackage.FOR_COMMAND__EXPR:
        getExpr().clear();
        getExpr().addAll((Collection<? extends Expr>)newValue);
        return;
      case WhPackage.FOR_COMMAND__CMD:
        getCmd().clear();
        getCmd().addAll((Collection<? extends Commands>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case WhPackage.FOR_COMMAND__EXPR:
        getExpr().clear();
        return;
      case WhPackage.FOR_COMMAND__CMD:
        getCmd().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case WhPackage.FOR_COMMAND__EXPR:
        return expr != null && !expr.isEmpty();
      case WhPackage.FOR_COMMAND__CMD:
        return cmd != null && !cmd.isEmpty();
    }
    return super.eIsSet(featureID);
  }

} //forCommandImpl
