/**
 */
package me.qfdk.esir.wh.wh.impl;

import java.util.Collection;

import me.qfdk.esir.wh.wh.ExprSimple;
import me.qfdk.esir.wh.wh.WhPackage;
import me.qfdk.esir.wh.wh.cons;
import me.qfdk.esir.wh.wh.hd;
import me.qfdk.esir.wh.wh.list;
import me.qfdk.esir.wh.wh.symb;
import me.qfdk.esir.wh.wh.tl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Expr Simple</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link me.qfdk.esir.wh.wh.impl.ExprSimpleImpl#getNil <em>Nil</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.impl.ExprSimpleImpl#getName1 <em>Name1</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.impl.ExprSimpleImpl#getName2 <em>Name2</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.impl.ExprSimpleImpl#getCons <em>Cons</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.impl.ExprSimpleImpl#getList <em>List</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.impl.ExprSimpleImpl#getHd <em>Hd</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.impl.ExprSimpleImpl#getTl <em>Tl</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.impl.ExprSimpleImpl#getSymb <em>Symb</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ExprSimpleImpl extends MinimalEObjectImpl.Container implements ExprSimple
{
  /**
   * The default value of the '{@link #getNil() <em>Nil</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getNil()
   * @generated
   * @ordered
   */
  protected static final String NIL_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getNil() <em>Nil</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getNil()
   * @generated
   * @ordered
   */
  protected String nil = NIL_EDEFAULT;

  /**
   * The default value of the '{@link #getName1() <em>Name1</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName1()
   * @generated
   * @ordered
   */
  protected static final String NAME1_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getName1() <em>Name1</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName1()
   * @generated
   * @ordered
   */
  protected String name1 = NAME1_EDEFAULT;

  /**
   * The default value of the '{@link #getName2() <em>Name2</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName2()
   * @generated
   * @ordered
   */
  protected static final String NAME2_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getName2() <em>Name2</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName2()
   * @generated
   * @ordered
   */
  protected String name2 = NAME2_EDEFAULT;

  /**
   * The cached value of the '{@link #getCons() <em>Cons</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getCons()
   * @generated
   * @ordered
   */
  protected EList<cons> cons;

  /**
   * The cached value of the '{@link #getList() <em>List</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getList()
   * @generated
   * @ordered
   */
  protected EList<list> list;

  /**
   * The cached value of the '{@link #getHd() <em>Hd</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getHd()
   * @generated
   * @ordered
   */
  protected EList<hd> hd;

  /**
   * The cached value of the '{@link #getTl() <em>Tl</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTl()
   * @generated
   * @ordered
   */
  protected EList<tl> tl;

  /**
   * The cached value of the '{@link #getSymb() <em>Symb</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getSymb()
   * @generated
   * @ordered
   */
  protected EList<symb> symb;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected ExprSimpleImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return WhPackage.Literals.EXPR_SIMPLE;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getNil()
  {
    return nil;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setNil(String newNil)
  {
    String oldNil = nil;
    nil = newNil;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, WhPackage.EXPR_SIMPLE__NIL, oldNil, nil));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getName1()
  {
    return name1;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setName1(String newName1)
  {
    String oldName1 = name1;
    name1 = newName1;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, WhPackage.EXPR_SIMPLE__NAME1, oldName1, name1));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getName2()
  {
    return name2;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setName2(String newName2)
  {
    String oldName2 = name2;
    name2 = newName2;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, WhPackage.EXPR_SIMPLE__NAME2, oldName2, name2));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<cons> getCons()
  {
    if (cons == null)
    {
      cons = new EObjectContainmentEList<cons>(cons.class, this, WhPackage.EXPR_SIMPLE__CONS);
    }
    return cons;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<list> getList()
  {
    if (list == null)
    {
      list = new EObjectContainmentEList<list>(list.class, this, WhPackage.EXPR_SIMPLE__LIST);
    }
    return list;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<hd> getHd()
  {
    if (hd == null)
    {
      hd = new EObjectContainmentEList<hd>(hd.class, this, WhPackage.EXPR_SIMPLE__HD);
    }
    return hd;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<tl> getTl()
  {
    if (tl == null)
    {
      tl = new EObjectContainmentEList<tl>(tl.class, this, WhPackage.EXPR_SIMPLE__TL);
    }
    return tl;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<symb> getSymb()
  {
    if (symb == null)
    {
      symb = new EObjectContainmentEList<symb>(symb.class, this, WhPackage.EXPR_SIMPLE__SYMB);
    }
    return symb;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case WhPackage.EXPR_SIMPLE__CONS:
        return ((InternalEList<?>)getCons()).basicRemove(otherEnd, msgs);
      case WhPackage.EXPR_SIMPLE__LIST:
        return ((InternalEList<?>)getList()).basicRemove(otherEnd, msgs);
      case WhPackage.EXPR_SIMPLE__HD:
        return ((InternalEList<?>)getHd()).basicRemove(otherEnd, msgs);
      case WhPackage.EXPR_SIMPLE__TL:
        return ((InternalEList<?>)getTl()).basicRemove(otherEnd, msgs);
      case WhPackage.EXPR_SIMPLE__SYMB:
        return ((InternalEList<?>)getSymb()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case WhPackage.EXPR_SIMPLE__NIL:
        return getNil();
      case WhPackage.EXPR_SIMPLE__NAME1:
        return getName1();
      case WhPackage.EXPR_SIMPLE__NAME2:
        return getName2();
      case WhPackage.EXPR_SIMPLE__CONS:
        return getCons();
      case WhPackage.EXPR_SIMPLE__LIST:
        return getList();
      case WhPackage.EXPR_SIMPLE__HD:
        return getHd();
      case WhPackage.EXPR_SIMPLE__TL:
        return getTl();
      case WhPackage.EXPR_SIMPLE__SYMB:
        return getSymb();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case WhPackage.EXPR_SIMPLE__NIL:
        setNil((String)newValue);
        return;
      case WhPackage.EXPR_SIMPLE__NAME1:
        setName1((String)newValue);
        return;
      case WhPackage.EXPR_SIMPLE__NAME2:
        setName2((String)newValue);
        return;
      case WhPackage.EXPR_SIMPLE__CONS:
        getCons().clear();
        getCons().addAll((Collection<? extends cons>)newValue);
        return;
      case WhPackage.EXPR_SIMPLE__LIST:
        getList().clear();
        getList().addAll((Collection<? extends list>)newValue);
        return;
      case WhPackage.EXPR_SIMPLE__HD:
        getHd().clear();
        getHd().addAll((Collection<? extends hd>)newValue);
        return;
      case WhPackage.EXPR_SIMPLE__TL:
        getTl().clear();
        getTl().addAll((Collection<? extends tl>)newValue);
        return;
      case WhPackage.EXPR_SIMPLE__SYMB:
        getSymb().clear();
        getSymb().addAll((Collection<? extends symb>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case WhPackage.EXPR_SIMPLE__NIL:
        setNil(NIL_EDEFAULT);
        return;
      case WhPackage.EXPR_SIMPLE__NAME1:
        setName1(NAME1_EDEFAULT);
        return;
      case WhPackage.EXPR_SIMPLE__NAME2:
        setName2(NAME2_EDEFAULT);
        return;
      case WhPackage.EXPR_SIMPLE__CONS:
        getCons().clear();
        return;
      case WhPackage.EXPR_SIMPLE__LIST:
        getList().clear();
        return;
      case WhPackage.EXPR_SIMPLE__HD:
        getHd().clear();
        return;
      case WhPackage.EXPR_SIMPLE__TL:
        getTl().clear();
        return;
      case WhPackage.EXPR_SIMPLE__SYMB:
        getSymb().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case WhPackage.EXPR_SIMPLE__NIL:
        return NIL_EDEFAULT == null ? nil != null : !NIL_EDEFAULT.equals(nil);
      case WhPackage.EXPR_SIMPLE__NAME1:
        return NAME1_EDEFAULT == null ? name1 != null : !NAME1_EDEFAULT.equals(name1);
      case WhPackage.EXPR_SIMPLE__NAME2:
        return NAME2_EDEFAULT == null ? name2 != null : !NAME2_EDEFAULT.equals(name2);
      case WhPackage.EXPR_SIMPLE__CONS:
        return cons != null && !cons.isEmpty();
      case WhPackage.EXPR_SIMPLE__LIST:
        return list != null && !list.isEmpty();
      case WhPackage.EXPR_SIMPLE__HD:
        return hd != null && !hd.isEmpty();
      case WhPackage.EXPR_SIMPLE__TL:
        return tl != null && !tl.isEmpty();
      case WhPackage.EXPR_SIMPLE__SYMB:
        return symb != null && !symb.isEmpty();
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (nil: ");
    result.append(nil);
    result.append(", name1: ");
    result.append(name1);
    result.append(", name2: ");
    result.append(name2);
    result.append(')');
    return result.toString();
  }

} //ExprSimpleImpl
