/**
 */
package me.qfdk.esir.wh.wh.impl;

import java.util.Collection;

import me.qfdk.esir.wh.wh.ExprEgal;
import me.qfdk.esir.wh.wh.ExprSimple;
import me.qfdk.esir.wh.wh.WhPackage;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Expr Egal</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link me.qfdk.esir.wh.wh.impl.ExprEgalImpl#getExprSimple1 <em>Expr Simple1</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.impl.ExprEgalImpl#getExprSimple2 <em>Expr Simple2</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ExprEgalImpl extends MinimalEObjectImpl.Container implements ExprEgal
{
  /**
   * The cached value of the '{@link #getExprSimple1() <em>Expr Simple1</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getExprSimple1()
   * @generated
   * @ordered
   */
  protected EList<ExprSimple> exprSimple1;

  /**
   * The cached value of the '{@link #getExprSimple2() <em>Expr Simple2</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getExprSimple2()
   * @generated
   * @ordered
   */
  protected EList<ExprSimple> exprSimple2;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected ExprEgalImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return WhPackage.Literals.EXPR_EGAL;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<ExprSimple> getExprSimple1()
  {
    if (exprSimple1 == null)
    {
      exprSimple1 = new EObjectContainmentEList<ExprSimple>(ExprSimple.class, this, WhPackage.EXPR_EGAL__EXPR_SIMPLE1);
    }
    return exprSimple1;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<ExprSimple> getExprSimple2()
  {
    if (exprSimple2 == null)
    {
      exprSimple2 = new EObjectContainmentEList<ExprSimple>(ExprSimple.class, this, WhPackage.EXPR_EGAL__EXPR_SIMPLE2);
    }
    return exprSimple2;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case WhPackage.EXPR_EGAL__EXPR_SIMPLE1:
        return ((InternalEList<?>)getExprSimple1()).basicRemove(otherEnd, msgs);
      case WhPackage.EXPR_EGAL__EXPR_SIMPLE2:
        return ((InternalEList<?>)getExprSimple2()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case WhPackage.EXPR_EGAL__EXPR_SIMPLE1:
        return getExprSimple1();
      case WhPackage.EXPR_EGAL__EXPR_SIMPLE2:
        return getExprSimple2();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case WhPackage.EXPR_EGAL__EXPR_SIMPLE1:
        getExprSimple1().clear();
        getExprSimple1().addAll((Collection<? extends ExprSimple>)newValue);
        return;
      case WhPackage.EXPR_EGAL__EXPR_SIMPLE2:
        getExprSimple2().clear();
        getExprSimple2().addAll((Collection<? extends ExprSimple>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case WhPackage.EXPR_EGAL__EXPR_SIMPLE1:
        getExprSimple1().clear();
        return;
      case WhPackage.EXPR_EGAL__EXPR_SIMPLE2:
        getExprSimple2().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case WhPackage.EXPR_EGAL__EXPR_SIMPLE1:
        return exprSimple1 != null && !exprSimple1.isEmpty();
      case WhPackage.EXPR_EGAL__EXPR_SIMPLE2:
        return exprSimple2 != null && !exprSimple2.isEmpty();
    }
    return super.eIsSet(featureID);
  }

} //ExprEgalImpl
