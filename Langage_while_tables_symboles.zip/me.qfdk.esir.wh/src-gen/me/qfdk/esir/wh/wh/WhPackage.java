/**
 */
package me.qfdk.esir.wh.wh;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see me.qfdk.esir.wh.wh.WhFactory
 * @model kind="package"
 * @generated
 */
public interface WhPackage extends EPackage
{
  /**
   * The package name.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  String eNAME = "wh";

  /**
   * The package namespace URI.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  String eNS_URI = "http://www.qfdk.me/esir/wh/Wh";

  /**
   * The package namespace name.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  String eNS_PREFIX = "wh";

  /**
   * The singleton instance of the package.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  WhPackage eINSTANCE = me.qfdk.esir.wh.wh.impl.WhPackageImpl.init();

  /**
   * The meta object id for the '{@link me.qfdk.esir.wh.wh.impl.whImpl <em>wh</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see me.qfdk.esir.wh.wh.impl.whImpl
   * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getwh()
   * @generated
   */
  int WH = 0;

  /**
   * The feature id for the '<em><b>Elements</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int WH__ELEMENTS = 0;

  /**
   * The number of structural features of the '<em>wh</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int WH_FEATURE_COUNT = 1;

  /**
   * The meta object id for the '{@link me.qfdk.esir.wh.wh.impl.FunctionImpl <em>Function</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see me.qfdk.esir.wh.wh.impl.FunctionImpl
   * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getFunction()
   * @generated
   */
  int FUNCTION = 1;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FUNCTION__NAME = 0;

  /**
   * The feature id for the '<em><b>Def</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FUNCTION__DEF = 1;

  /**
   * The number of structural features of the '<em>Function</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FUNCTION_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link me.qfdk.esir.wh.wh.impl.DefinitionImpl <em>Definition</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see me.qfdk.esir.wh.wh.impl.DefinitionImpl
   * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getDefinition()
   * @generated
   */
  int DEFINITION = 2;

  /**
   * The feature id for the '<em><b>Entree</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DEFINITION__ENTREE = 0;

  /**
   * The feature id for the '<em><b>Cmd</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DEFINITION__CMD = 1;

  /**
   * The feature id for the '<em><b>Sortie</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DEFINITION__SORTIE = 2;

  /**
   * The number of structural features of the '<em>Definition</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DEFINITION_FEATURE_COUNT = 3;

  /**
   * The meta object id for the '{@link me.qfdk.esir.wh.wh.impl.InputImpl <em>Input</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see me.qfdk.esir.wh.wh.impl.InputImpl
   * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getInput()
   * @generated
   */
  int INPUT = 3;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT__NAME = 0;

  /**
   * The feature id for the '<em><b>Entree</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT__ENTREE = 1;

  /**
   * The number of structural features of the '<em>Input</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link me.qfdk.esir.wh.wh.impl.OutputImpl <em>Output</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see me.qfdk.esir.wh.wh.impl.OutputImpl
   * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getOutput()
   * @generated
   */
  int OUTPUT = 4;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT__NAME = 0;

  /**
   * The feature id for the '<em><b>Sortie</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT__SORTIE = 1;

  /**
   * The number of structural features of the '<em>Output</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link me.qfdk.esir.wh.wh.impl.CommandsImpl <em>Commands</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see me.qfdk.esir.wh.wh.impl.CommandsImpl
   * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getCommands()
   * @generated
   */
  int COMMANDS = 5;

  /**
   * The feature id for the '<em><b>Cmd1</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int COMMANDS__CMD1 = 0;

  /**
   * The feature id for the '<em><b>Cmd</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int COMMANDS__CMD = 1;

  /**
   * The number of structural features of the '<em>Commands</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int COMMANDS_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link me.qfdk.esir.wh.wh.impl.CommandImpl <em>Command</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see me.qfdk.esir.wh.wh.impl.CommandImpl
   * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getCommand()
   * @generated
   */
  int COMMAND = 6;

  /**
   * The feature id for the '<em><b>Nop</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int COMMAND__NOP = 0;

  /**
   * The feature id for the '<em><b>Affectation</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int COMMAND__AFFECTATION = 1;

  /**
   * The feature id for the '<em><b>While Command</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int COMMAND__WHILE_COMMAND = 2;

  /**
   * The feature id for the '<em><b>For Command</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int COMMAND__FOR_COMMAND = 3;

  /**
   * The feature id for the '<em><b>If Command</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int COMMAND__IF_COMMAND = 4;

  /**
   * The feature id for the '<em><b>Foreach Command</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int COMMAND__FOREACH_COMMAND = 5;

  /**
   * The number of structural features of the '<em>Command</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int COMMAND_FEATURE_COUNT = 6;

  /**
   * The meta object id for the '{@link me.qfdk.esir.wh.wh.impl.affectationImpl <em>affectation</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see me.qfdk.esir.wh.wh.impl.affectationImpl
   * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getaffectation()
   * @generated
   */
  int AFFECTATION = 7;

  /**
   * The feature id for the '<em><b>Vars</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AFFECTATION__VARS = 0;

  /**
   * The feature id for the '<em><b>Exprs</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AFFECTATION__EXPRS = 1;

  /**
   * The number of structural features of the '<em>affectation</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AFFECTATION_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link me.qfdk.esir.wh.wh.impl.whileCommandImpl <em>while Command</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see me.qfdk.esir.wh.wh.impl.whileCommandImpl
   * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getwhileCommand()
   * @generated
   */
  int WHILE_COMMAND = 8;

  /**
   * The feature id for the '<em><b>Expr</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int WHILE_COMMAND__EXPR = 0;

  /**
   * The feature id for the '<em><b>Cmd</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int WHILE_COMMAND__CMD = 1;

  /**
   * The number of structural features of the '<em>while Command</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int WHILE_COMMAND_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link me.qfdk.esir.wh.wh.impl.forCommandImpl <em>for Command</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see me.qfdk.esir.wh.wh.impl.forCommandImpl
   * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getforCommand()
   * @generated
   */
  int FOR_COMMAND = 9;

  /**
   * The feature id for the '<em><b>Expr</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FOR_COMMAND__EXPR = 0;

  /**
   * The feature id for the '<em><b>Cmd</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FOR_COMMAND__CMD = 1;

  /**
   * The number of structural features of the '<em>for Command</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FOR_COMMAND_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link me.qfdk.esir.wh.wh.impl.ifCommandImpl <em>if Command</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see me.qfdk.esir.wh.wh.impl.ifCommandImpl
   * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getifCommand()
   * @generated
   */
  int IF_COMMAND = 10;

  /**
   * The feature id for the '<em><b>Expr</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int IF_COMMAND__EXPR = 0;

  /**
   * The feature id for the '<em><b>Cmd1</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int IF_COMMAND__CMD1 = 1;

  /**
   * The feature id for the '<em><b>Cmd2</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int IF_COMMAND__CMD2 = 2;

  /**
   * The number of structural features of the '<em>if Command</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int IF_COMMAND_FEATURE_COUNT = 3;

  /**
   * The meta object id for the '{@link me.qfdk.esir.wh.wh.impl.foreachCommandImpl <em>foreach Command</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see me.qfdk.esir.wh.wh.impl.foreachCommandImpl
   * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getforeachCommand()
   * @generated
   */
  int FOREACH_COMMAND = 11;

  /**
   * The feature id for the '<em><b>Expr1</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FOREACH_COMMAND__EXPR1 = 0;

  /**
   * The feature id for the '<em><b>Expr2</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FOREACH_COMMAND__EXPR2 = 1;

  /**
   * The feature id for the '<em><b>Cmd</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FOREACH_COMMAND__CMD = 2;

  /**
   * The number of structural features of the '<em>foreach Command</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FOREACH_COMMAND_FEATURE_COUNT = 3;

  /**
   * The meta object id for the '{@link me.qfdk.esir.wh.wh.impl.VarsImpl <em>Vars</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see me.qfdk.esir.wh.wh.impl.VarsImpl
   * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getVars()
   * @generated
   */
  int VARS = 12;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int VARS__NAME = 0;

  /**
   * The feature id for the '<em><b>Vars</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int VARS__VARS = 1;

  /**
   * The number of structural features of the '<em>Vars</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int VARS_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link me.qfdk.esir.wh.wh.impl.ExprsImpl <em>Exprs</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see me.qfdk.esir.wh.wh.impl.ExprsImpl
   * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getExprs()
   * @generated
   */
  int EXPRS = 13;

  /**
   * The feature id for the '<em><b>Expr1</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EXPRS__EXPR1 = 0;

  /**
   * The feature id for the '<em><b>Expr</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EXPRS__EXPR = 1;

  /**
   * The number of structural features of the '<em>Exprs</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EXPRS_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link me.qfdk.esir.wh.wh.impl.ExprImpl <em>Expr</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see me.qfdk.esir.wh.wh.impl.ExprImpl
   * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getExpr()
   * @generated
   */
  int EXPR = 14;

  /**
   * The feature id for the '<em><b>Expr Simple</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EXPR__EXPR_SIMPLE = 0;

  /**
   * The feature id for the '<em><b>Expr And</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EXPR__EXPR_AND = 1;

  /**
   * The number of structural features of the '<em>Expr</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EXPR_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link me.qfdk.esir.wh.wh.impl.ExprSimpleImpl <em>Expr Simple</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see me.qfdk.esir.wh.wh.impl.ExprSimpleImpl
   * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getExprSimple()
   * @generated
   */
  int EXPR_SIMPLE = 15;

  /**
   * The feature id for the '<em><b>Nil</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EXPR_SIMPLE__NIL = 0;

  /**
   * The feature id for the '<em><b>Name1</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EXPR_SIMPLE__NAME1 = 1;

  /**
   * The feature id for the '<em><b>Name2</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EXPR_SIMPLE__NAME2 = 2;

  /**
   * The feature id for the '<em><b>Cons</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EXPR_SIMPLE__CONS = 3;

  /**
   * The feature id for the '<em><b>List</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EXPR_SIMPLE__LIST = 4;

  /**
   * The feature id for the '<em><b>Hd</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EXPR_SIMPLE__HD = 5;

  /**
   * The feature id for the '<em><b>Tl</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EXPR_SIMPLE__TL = 6;

  /**
   * The feature id for the '<em><b>Symb</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EXPR_SIMPLE__SYMB = 7;

  /**
   * The number of structural features of the '<em>Expr Simple</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EXPR_SIMPLE_FEATURE_COUNT = 8;

  /**
   * The meta object id for the '{@link me.qfdk.esir.wh.wh.impl.consImpl <em>cons</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see me.qfdk.esir.wh.wh.impl.consImpl
   * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getcons()
   * @generated
   */
  int CONS = 16;

  /**
   * The feature id for the '<em><b>Lexpr</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CONS__LEXPR = 0;

  /**
   * The number of structural features of the '<em>cons</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CONS_FEATURE_COUNT = 1;

  /**
   * The meta object id for the '{@link me.qfdk.esir.wh.wh.impl.listImpl <em>list</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see me.qfdk.esir.wh.wh.impl.listImpl
   * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getlist()
   * @generated
   */
  int LIST = 17;

  /**
   * The feature id for the '<em><b>Lexpr</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int LIST__LEXPR = 0;

  /**
   * The number of structural features of the '<em>list</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int LIST_FEATURE_COUNT = 1;

  /**
   * The meta object id for the '{@link me.qfdk.esir.wh.wh.impl.hdImpl <em>hd</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see me.qfdk.esir.wh.wh.impl.hdImpl
   * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#gethd()
   * @generated
   */
  int HD = 18;

  /**
   * The feature id for the '<em><b>Expr</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int HD__EXPR = 0;

  /**
   * The number of structural features of the '<em>hd</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int HD_FEATURE_COUNT = 1;

  /**
   * The meta object id for the '{@link me.qfdk.esir.wh.wh.impl.tlImpl <em>tl</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see me.qfdk.esir.wh.wh.impl.tlImpl
   * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#gettl()
   * @generated
   */
  int TL = 19;

  /**
   * The feature id for the '<em><b>Expr</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TL__EXPR = 0;

  /**
   * The number of structural features of the '<em>tl</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TL_FEATURE_COUNT = 1;

  /**
   * The meta object id for the '{@link me.qfdk.esir.wh.wh.impl.symbImpl <em>symb</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see me.qfdk.esir.wh.wh.impl.symbImpl
   * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getsymb()
   * @generated
   */
  int SYMB = 20;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SYMB__NAME = 0;

  /**
   * The feature id for the '<em><b>Lexpr</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SYMB__LEXPR = 1;

  /**
   * The number of structural features of the '<em>symb</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SYMB_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link me.qfdk.esir.wh.wh.impl.LexprImpl <em>Lexpr</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see me.qfdk.esir.wh.wh.impl.LexprImpl
   * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getLexpr()
   * @generated
   */
  int LEXPR = 21;

  /**
   * The feature id for the '<em><b>Expr</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int LEXPR__EXPR = 0;

  /**
   * The feature id for the '<em><b>Lexpr</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int LEXPR__LEXPR = 1;

  /**
   * The number of structural features of the '<em>Lexpr</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int LEXPR_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link me.qfdk.esir.wh.wh.impl.ExprAndImpl <em>Expr And</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see me.qfdk.esir.wh.wh.impl.ExprAndImpl
   * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getExprAnd()
   * @generated
   */
  int EXPR_AND = 22;

  /**
   * The feature id for the '<em><b>Expr Or</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EXPR_AND__EXPR_OR = 0;

  /**
   * The feature id for the '<em><b>Expr And</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EXPR_AND__EXPR_AND = 1;

  /**
   * The number of structural features of the '<em>Expr And</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EXPR_AND_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link me.qfdk.esir.wh.wh.impl.ExprOrImpl <em>Expr Or</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see me.qfdk.esir.wh.wh.impl.ExprOrImpl
   * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getExprOr()
   * @generated
   */
  int EXPR_OR = 23;

  /**
   * The feature id for the '<em><b>Expr Not</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EXPR_OR__EXPR_NOT = 0;

  /**
   * The feature id for the '<em><b>Expr Or</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EXPR_OR__EXPR_OR = 1;

  /**
   * The number of structural features of the '<em>Expr Or</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EXPR_OR_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link me.qfdk.esir.wh.wh.impl.ExprNotImpl <em>Expr Not</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see me.qfdk.esir.wh.wh.impl.ExprNotImpl
   * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getExprNot()
   * @generated
   */
  int EXPR_NOT = 24;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EXPR_NOT__NAME = 0;

  /**
   * The feature id for the '<em><b>Expr Eq</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EXPR_NOT__EXPR_EQ = 1;

  /**
   * The number of structural features of the '<em>Expr Not</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EXPR_NOT_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link me.qfdk.esir.wh.wh.impl.ExprEqImpl <em>Expr Eq</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see me.qfdk.esir.wh.wh.impl.ExprEqImpl
   * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getExprEq()
   * @generated
   */
  int EXPR_EQ = 25;

  /**
   * The feature id for the '<em><b>Expr Egal</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EXPR_EQ__EXPR_EGAL = 0;

  /**
   * The feature id for the '<em><b>Expr Parent</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EXPR_EQ__EXPR_PARENT = 1;

  /**
   * The number of structural features of the '<em>Expr Eq</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EXPR_EQ_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link me.qfdk.esir.wh.wh.impl.ExprEgalImpl <em>Expr Egal</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see me.qfdk.esir.wh.wh.impl.ExprEgalImpl
   * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getExprEgal()
   * @generated
   */
  int EXPR_EGAL = 26;

  /**
   * The feature id for the '<em><b>Expr Simple1</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EXPR_EGAL__EXPR_SIMPLE1 = 0;

  /**
   * The feature id for the '<em><b>Expr Simple2</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EXPR_EGAL__EXPR_SIMPLE2 = 1;

  /**
   * The number of structural features of the '<em>Expr Egal</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EXPR_EGAL_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link me.qfdk.esir.wh.wh.impl.ExprParentImpl <em>Expr Parent</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see me.qfdk.esir.wh.wh.impl.ExprParentImpl
   * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getExprParent()
   * @generated
   */
  int EXPR_PARENT = 27;

  /**
   * The feature id for the '<em><b>Expr</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EXPR_PARENT__EXPR = 0;

  /**
   * The number of structural features of the '<em>Expr Parent</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EXPR_PARENT_FEATURE_COUNT = 1;


  /**
   * Returns the meta object for class '{@link me.qfdk.esir.wh.wh.wh <em>wh</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>wh</em>'.
   * @see me.qfdk.esir.wh.wh.wh
   * @generated
   */
  EClass getwh();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.wh#getElements <em>Elements</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Elements</em>'.
   * @see me.qfdk.esir.wh.wh.wh#getElements()
   * @see #getwh()
   * @generated
   */
  EReference getwh_Elements();

  /**
   * Returns the meta object for class '{@link me.qfdk.esir.wh.wh.Function <em>Function</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Function</em>'.
   * @see me.qfdk.esir.wh.wh.Function
   * @generated
   */
  EClass getFunction();

  /**
   * Returns the meta object for the attribute '{@link me.qfdk.esir.wh.wh.Function#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see me.qfdk.esir.wh.wh.Function#getName()
   * @see #getFunction()
   * @generated
   */
  EAttribute getFunction_Name();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.Function#getDef <em>Def</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Def</em>'.
   * @see me.qfdk.esir.wh.wh.Function#getDef()
   * @see #getFunction()
   * @generated
   */
  EReference getFunction_Def();

  /**
   * Returns the meta object for class '{@link me.qfdk.esir.wh.wh.Definition <em>Definition</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Definition</em>'.
   * @see me.qfdk.esir.wh.wh.Definition
   * @generated
   */
  EClass getDefinition();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.Definition#getEntree <em>Entree</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Entree</em>'.
   * @see me.qfdk.esir.wh.wh.Definition#getEntree()
   * @see #getDefinition()
   * @generated
   */
  EReference getDefinition_Entree();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.Definition#getCmd <em>Cmd</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Cmd</em>'.
   * @see me.qfdk.esir.wh.wh.Definition#getCmd()
   * @see #getDefinition()
   * @generated
   */
  EReference getDefinition_Cmd();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.Definition#getSortie <em>Sortie</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Sortie</em>'.
   * @see me.qfdk.esir.wh.wh.Definition#getSortie()
   * @see #getDefinition()
   * @generated
   */
  EReference getDefinition_Sortie();

  /**
   * Returns the meta object for class '{@link me.qfdk.esir.wh.wh.Input <em>Input</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Input</em>'.
   * @see me.qfdk.esir.wh.wh.Input
   * @generated
   */
  EClass getInput();

  /**
   * Returns the meta object for the attribute '{@link me.qfdk.esir.wh.wh.Input#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see me.qfdk.esir.wh.wh.Input#getName()
   * @see #getInput()
   * @generated
   */
  EAttribute getInput_Name();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.Input#getEntree <em>Entree</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Entree</em>'.
   * @see me.qfdk.esir.wh.wh.Input#getEntree()
   * @see #getInput()
   * @generated
   */
  EReference getInput_Entree();

  /**
   * Returns the meta object for class '{@link me.qfdk.esir.wh.wh.Output <em>Output</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Output</em>'.
   * @see me.qfdk.esir.wh.wh.Output
   * @generated
   */
  EClass getOutput();

  /**
   * Returns the meta object for the attribute '{@link me.qfdk.esir.wh.wh.Output#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see me.qfdk.esir.wh.wh.Output#getName()
   * @see #getOutput()
   * @generated
   */
  EAttribute getOutput_Name();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.Output#getSortie <em>Sortie</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Sortie</em>'.
   * @see me.qfdk.esir.wh.wh.Output#getSortie()
   * @see #getOutput()
   * @generated
   */
  EReference getOutput_Sortie();

  /**
   * Returns the meta object for class '{@link me.qfdk.esir.wh.wh.Commands <em>Commands</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Commands</em>'.
   * @see me.qfdk.esir.wh.wh.Commands
   * @generated
   */
  EClass getCommands();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.Commands#getCmd1 <em>Cmd1</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Cmd1</em>'.
   * @see me.qfdk.esir.wh.wh.Commands#getCmd1()
   * @see #getCommands()
   * @generated
   */
  EReference getCommands_Cmd1();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.Commands#getCmd <em>Cmd</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Cmd</em>'.
   * @see me.qfdk.esir.wh.wh.Commands#getCmd()
   * @see #getCommands()
   * @generated
   */
  EReference getCommands_Cmd();

  /**
   * Returns the meta object for class '{@link me.qfdk.esir.wh.wh.Command <em>Command</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Command</em>'.
   * @see me.qfdk.esir.wh.wh.Command
   * @generated
   */
  EClass getCommand();

  /**
   * Returns the meta object for the attribute '{@link me.qfdk.esir.wh.wh.Command#getNop <em>Nop</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Nop</em>'.
   * @see me.qfdk.esir.wh.wh.Command#getNop()
   * @see #getCommand()
   * @generated
   */
  EAttribute getCommand_Nop();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.Command#getAffectation <em>Affectation</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Affectation</em>'.
   * @see me.qfdk.esir.wh.wh.Command#getAffectation()
   * @see #getCommand()
   * @generated
   */
  EReference getCommand_Affectation();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.Command#getWhileCommand <em>While Command</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>While Command</em>'.
   * @see me.qfdk.esir.wh.wh.Command#getWhileCommand()
   * @see #getCommand()
   * @generated
   */
  EReference getCommand_WhileCommand();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.Command#getForCommand <em>For Command</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>For Command</em>'.
   * @see me.qfdk.esir.wh.wh.Command#getForCommand()
   * @see #getCommand()
   * @generated
   */
  EReference getCommand_ForCommand();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.Command#getIfCommand <em>If Command</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>If Command</em>'.
   * @see me.qfdk.esir.wh.wh.Command#getIfCommand()
   * @see #getCommand()
   * @generated
   */
  EReference getCommand_IfCommand();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.Command#getForeachCommand <em>Foreach Command</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Foreach Command</em>'.
   * @see me.qfdk.esir.wh.wh.Command#getForeachCommand()
   * @see #getCommand()
   * @generated
   */
  EReference getCommand_ForeachCommand();

  /**
   * Returns the meta object for class '{@link me.qfdk.esir.wh.wh.affectation <em>affectation</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>affectation</em>'.
   * @see me.qfdk.esir.wh.wh.affectation
   * @generated
   */
  EClass getaffectation();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.affectation#getVars <em>Vars</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Vars</em>'.
   * @see me.qfdk.esir.wh.wh.affectation#getVars()
   * @see #getaffectation()
   * @generated
   */
  EReference getaffectation_Vars();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.affectation#getExprs <em>Exprs</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Exprs</em>'.
   * @see me.qfdk.esir.wh.wh.affectation#getExprs()
   * @see #getaffectation()
   * @generated
   */
  EReference getaffectation_Exprs();

  /**
   * Returns the meta object for class '{@link me.qfdk.esir.wh.wh.whileCommand <em>while Command</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>while Command</em>'.
   * @see me.qfdk.esir.wh.wh.whileCommand
   * @generated
   */
  EClass getwhileCommand();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.whileCommand#getExpr <em>Expr</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Expr</em>'.
   * @see me.qfdk.esir.wh.wh.whileCommand#getExpr()
   * @see #getwhileCommand()
   * @generated
   */
  EReference getwhileCommand_Expr();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.whileCommand#getCmd <em>Cmd</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Cmd</em>'.
   * @see me.qfdk.esir.wh.wh.whileCommand#getCmd()
   * @see #getwhileCommand()
   * @generated
   */
  EReference getwhileCommand_Cmd();

  /**
   * Returns the meta object for class '{@link me.qfdk.esir.wh.wh.forCommand <em>for Command</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>for Command</em>'.
   * @see me.qfdk.esir.wh.wh.forCommand
   * @generated
   */
  EClass getforCommand();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.forCommand#getExpr <em>Expr</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Expr</em>'.
   * @see me.qfdk.esir.wh.wh.forCommand#getExpr()
   * @see #getforCommand()
   * @generated
   */
  EReference getforCommand_Expr();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.forCommand#getCmd <em>Cmd</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Cmd</em>'.
   * @see me.qfdk.esir.wh.wh.forCommand#getCmd()
   * @see #getforCommand()
   * @generated
   */
  EReference getforCommand_Cmd();

  /**
   * Returns the meta object for class '{@link me.qfdk.esir.wh.wh.ifCommand <em>if Command</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>if Command</em>'.
   * @see me.qfdk.esir.wh.wh.ifCommand
   * @generated
   */
  EClass getifCommand();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.ifCommand#getExpr <em>Expr</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Expr</em>'.
   * @see me.qfdk.esir.wh.wh.ifCommand#getExpr()
   * @see #getifCommand()
   * @generated
   */
  EReference getifCommand_Expr();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.ifCommand#getCmd1 <em>Cmd1</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Cmd1</em>'.
   * @see me.qfdk.esir.wh.wh.ifCommand#getCmd1()
   * @see #getifCommand()
   * @generated
   */
  EReference getifCommand_Cmd1();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.ifCommand#getCmd2 <em>Cmd2</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Cmd2</em>'.
   * @see me.qfdk.esir.wh.wh.ifCommand#getCmd2()
   * @see #getifCommand()
   * @generated
   */
  EReference getifCommand_Cmd2();

  /**
   * Returns the meta object for class '{@link me.qfdk.esir.wh.wh.foreachCommand <em>foreach Command</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>foreach Command</em>'.
   * @see me.qfdk.esir.wh.wh.foreachCommand
   * @generated
   */
  EClass getforeachCommand();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.foreachCommand#getExpr1 <em>Expr1</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Expr1</em>'.
   * @see me.qfdk.esir.wh.wh.foreachCommand#getExpr1()
   * @see #getforeachCommand()
   * @generated
   */
  EReference getforeachCommand_Expr1();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.foreachCommand#getExpr2 <em>Expr2</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Expr2</em>'.
   * @see me.qfdk.esir.wh.wh.foreachCommand#getExpr2()
   * @see #getforeachCommand()
   * @generated
   */
  EReference getforeachCommand_Expr2();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.foreachCommand#getCmd <em>Cmd</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Cmd</em>'.
   * @see me.qfdk.esir.wh.wh.foreachCommand#getCmd()
   * @see #getforeachCommand()
   * @generated
   */
  EReference getforeachCommand_Cmd();

  /**
   * Returns the meta object for class '{@link me.qfdk.esir.wh.wh.Vars <em>Vars</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Vars</em>'.
   * @see me.qfdk.esir.wh.wh.Vars
   * @generated
   */
  EClass getVars();

  /**
   * Returns the meta object for the attribute '{@link me.qfdk.esir.wh.wh.Vars#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see me.qfdk.esir.wh.wh.Vars#getName()
   * @see #getVars()
   * @generated
   */
  EAttribute getVars_Name();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.Vars#getVars <em>Vars</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Vars</em>'.
   * @see me.qfdk.esir.wh.wh.Vars#getVars()
   * @see #getVars()
   * @generated
   */
  EReference getVars_Vars();

  /**
   * Returns the meta object for class '{@link me.qfdk.esir.wh.wh.Exprs <em>Exprs</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Exprs</em>'.
   * @see me.qfdk.esir.wh.wh.Exprs
   * @generated
   */
  EClass getExprs();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.Exprs#getExpr1 <em>Expr1</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Expr1</em>'.
   * @see me.qfdk.esir.wh.wh.Exprs#getExpr1()
   * @see #getExprs()
   * @generated
   */
  EReference getExprs_Expr1();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.Exprs#getExpr <em>Expr</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Expr</em>'.
   * @see me.qfdk.esir.wh.wh.Exprs#getExpr()
   * @see #getExprs()
   * @generated
   */
  EReference getExprs_Expr();

  /**
   * Returns the meta object for class '{@link me.qfdk.esir.wh.wh.Expr <em>Expr</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Expr</em>'.
   * @see me.qfdk.esir.wh.wh.Expr
   * @generated
   */
  EClass getExpr();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.Expr#getExprSimple <em>Expr Simple</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Expr Simple</em>'.
   * @see me.qfdk.esir.wh.wh.Expr#getExprSimple()
   * @see #getExpr()
   * @generated
   */
  EReference getExpr_ExprSimple();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.Expr#getExprAnd <em>Expr And</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Expr And</em>'.
   * @see me.qfdk.esir.wh.wh.Expr#getExprAnd()
   * @see #getExpr()
   * @generated
   */
  EReference getExpr_ExprAnd();

  /**
   * Returns the meta object for class '{@link me.qfdk.esir.wh.wh.ExprSimple <em>Expr Simple</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Expr Simple</em>'.
   * @see me.qfdk.esir.wh.wh.ExprSimple
   * @generated
   */
  EClass getExprSimple();

  /**
   * Returns the meta object for the attribute '{@link me.qfdk.esir.wh.wh.ExprSimple#getNil <em>Nil</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Nil</em>'.
   * @see me.qfdk.esir.wh.wh.ExprSimple#getNil()
   * @see #getExprSimple()
   * @generated
   */
  EAttribute getExprSimple_Nil();

  /**
   * Returns the meta object for the attribute '{@link me.qfdk.esir.wh.wh.ExprSimple#getName1 <em>Name1</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name1</em>'.
   * @see me.qfdk.esir.wh.wh.ExprSimple#getName1()
   * @see #getExprSimple()
   * @generated
   */
  EAttribute getExprSimple_Name1();

  /**
   * Returns the meta object for the attribute '{@link me.qfdk.esir.wh.wh.ExprSimple#getName2 <em>Name2</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name2</em>'.
   * @see me.qfdk.esir.wh.wh.ExprSimple#getName2()
   * @see #getExprSimple()
   * @generated
   */
  EAttribute getExprSimple_Name2();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.ExprSimple#getCons <em>Cons</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Cons</em>'.
   * @see me.qfdk.esir.wh.wh.ExprSimple#getCons()
   * @see #getExprSimple()
   * @generated
   */
  EReference getExprSimple_Cons();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.ExprSimple#getList <em>List</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>List</em>'.
   * @see me.qfdk.esir.wh.wh.ExprSimple#getList()
   * @see #getExprSimple()
   * @generated
   */
  EReference getExprSimple_List();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.ExprSimple#getHd <em>Hd</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Hd</em>'.
   * @see me.qfdk.esir.wh.wh.ExprSimple#getHd()
   * @see #getExprSimple()
   * @generated
   */
  EReference getExprSimple_Hd();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.ExprSimple#getTl <em>Tl</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Tl</em>'.
   * @see me.qfdk.esir.wh.wh.ExprSimple#getTl()
   * @see #getExprSimple()
   * @generated
   */
  EReference getExprSimple_Tl();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.ExprSimple#getSymb <em>Symb</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Symb</em>'.
   * @see me.qfdk.esir.wh.wh.ExprSimple#getSymb()
   * @see #getExprSimple()
   * @generated
   */
  EReference getExprSimple_Symb();

  /**
   * Returns the meta object for class '{@link me.qfdk.esir.wh.wh.cons <em>cons</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>cons</em>'.
   * @see me.qfdk.esir.wh.wh.cons
   * @generated
   */
  EClass getcons();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.cons#getLexpr <em>Lexpr</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Lexpr</em>'.
   * @see me.qfdk.esir.wh.wh.cons#getLexpr()
   * @see #getcons()
   * @generated
   */
  EReference getcons_Lexpr();

  /**
   * Returns the meta object for class '{@link me.qfdk.esir.wh.wh.list <em>list</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>list</em>'.
   * @see me.qfdk.esir.wh.wh.list
   * @generated
   */
  EClass getlist();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.list#getLexpr <em>Lexpr</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Lexpr</em>'.
   * @see me.qfdk.esir.wh.wh.list#getLexpr()
   * @see #getlist()
   * @generated
   */
  EReference getlist_Lexpr();

  /**
   * Returns the meta object for class '{@link me.qfdk.esir.wh.wh.hd <em>hd</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>hd</em>'.
   * @see me.qfdk.esir.wh.wh.hd
   * @generated
   */
  EClass gethd();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.hd#getExpr <em>Expr</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Expr</em>'.
   * @see me.qfdk.esir.wh.wh.hd#getExpr()
   * @see #gethd()
   * @generated
   */
  EReference gethd_Expr();

  /**
   * Returns the meta object for class '{@link me.qfdk.esir.wh.wh.tl <em>tl</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>tl</em>'.
   * @see me.qfdk.esir.wh.wh.tl
   * @generated
   */
  EClass gettl();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.tl#getExpr <em>Expr</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Expr</em>'.
   * @see me.qfdk.esir.wh.wh.tl#getExpr()
   * @see #gettl()
   * @generated
   */
  EReference gettl_Expr();

  /**
   * Returns the meta object for class '{@link me.qfdk.esir.wh.wh.symb <em>symb</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>symb</em>'.
   * @see me.qfdk.esir.wh.wh.symb
   * @generated
   */
  EClass getsymb();

  /**
   * Returns the meta object for the attribute '{@link me.qfdk.esir.wh.wh.symb#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see me.qfdk.esir.wh.wh.symb#getName()
   * @see #getsymb()
   * @generated
   */
  EAttribute getsymb_Name();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.symb#getLexpr <em>Lexpr</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Lexpr</em>'.
   * @see me.qfdk.esir.wh.wh.symb#getLexpr()
   * @see #getsymb()
   * @generated
   */
  EReference getsymb_Lexpr();

  /**
   * Returns the meta object for class '{@link me.qfdk.esir.wh.wh.Lexpr <em>Lexpr</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Lexpr</em>'.
   * @see me.qfdk.esir.wh.wh.Lexpr
   * @generated
   */
  EClass getLexpr();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.Lexpr#getExpr <em>Expr</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Expr</em>'.
   * @see me.qfdk.esir.wh.wh.Lexpr#getExpr()
   * @see #getLexpr()
   * @generated
   */
  EReference getLexpr_Expr();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.Lexpr#getLexpr <em>Lexpr</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Lexpr</em>'.
   * @see me.qfdk.esir.wh.wh.Lexpr#getLexpr()
   * @see #getLexpr()
   * @generated
   */
  EReference getLexpr_Lexpr();

  /**
   * Returns the meta object for class '{@link me.qfdk.esir.wh.wh.ExprAnd <em>Expr And</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Expr And</em>'.
   * @see me.qfdk.esir.wh.wh.ExprAnd
   * @generated
   */
  EClass getExprAnd();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.ExprAnd#getExprOr <em>Expr Or</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Expr Or</em>'.
   * @see me.qfdk.esir.wh.wh.ExprAnd#getExprOr()
   * @see #getExprAnd()
   * @generated
   */
  EReference getExprAnd_ExprOr();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.ExprAnd#getExprAnd <em>Expr And</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Expr And</em>'.
   * @see me.qfdk.esir.wh.wh.ExprAnd#getExprAnd()
   * @see #getExprAnd()
   * @generated
   */
  EReference getExprAnd_ExprAnd();

  /**
   * Returns the meta object for class '{@link me.qfdk.esir.wh.wh.ExprOr <em>Expr Or</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Expr Or</em>'.
   * @see me.qfdk.esir.wh.wh.ExprOr
   * @generated
   */
  EClass getExprOr();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.ExprOr#getExprNot <em>Expr Not</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Expr Not</em>'.
   * @see me.qfdk.esir.wh.wh.ExprOr#getExprNot()
   * @see #getExprOr()
   * @generated
   */
  EReference getExprOr_ExprNot();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.ExprOr#getExprOr <em>Expr Or</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Expr Or</em>'.
   * @see me.qfdk.esir.wh.wh.ExprOr#getExprOr()
   * @see #getExprOr()
   * @generated
   */
  EReference getExprOr_ExprOr();

  /**
   * Returns the meta object for class '{@link me.qfdk.esir.wh.wh.ExprNot <em>Expr Not</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Expr Not</em>'.
   * @see me.qfdk.esir.wh.wh.ExprNot
   * @generated
   */
  EClass getExprNot();

  /**
   * Returns the meta object for the attribute '{@link me.qfdk.esir.wh.wh.ExprNot#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see me.qfdk.esir.wh.wh.ExprNot#getName()
   * @see #getExprNot()
   * @generated
   */
  EAttribute getExprNot_Name();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.ExprNot#getExprEq <em>Expr Eq</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Expr Eq</em>'.
   * @see me.qfdk.esir.wh.wh.ExprNot#getExprEq()
   * @see #getExprNot()
   * @generated
   */
  EReference getExprNot_ExprEq();

  /**
   * Returns the meta object for class '{@link me.qfdk.esir.wh.wh.ExprEq <em>Expr Eq</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Expr Eq</em>'.
   * @see me.qfdk.esir.wh.wh.ExprEq
   * @generated
   */
  EClass getExprEq();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.ExprEq#getExprEgal <em>Expr Egal</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Expr Egal</em>'.
   * @see me.qfdk.esir.wh.wh.ExprEq#getExprEgal()
   * @see #getExprEq()
   * @generated
   */
  EReference getExprEq_ExprEgal();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.ExprEq#getExprParent <em>Expr Parent</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Expr Parent</em>'.
   * @see me.qfdk.esir.wh.wh.ExprEq#getExprParent()
   * @see #getExprEq()
   * @generated
   */
  EReference getExprEq_ExprParent();

  /**
   * Returns the meta object for class '{@link me.qfdk.esir.wh.wh.ExprEgal <em>Expr Egal</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Expr Egal</em>'.
   * @see me.qfdk.esir.wh.wh.ExprEgal
   * @generated
   */
  EClass getExprEgal();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.ExprEgal#getExprSimple1 <em>Expr Simple1</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Expr Simple1</em>'.
   * @see me.qfdk.esir.wh.wh.ExprEgal#getExprSimple1()
   * @see #getExprEgal()
   * @generated
   */
  EReference getExprEgal_ExprSimple1();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.ExprEgal#getExprSimple2 <em>Expr Simple2</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Expr Simple2</em>'.
   * @see me.qfdk.esir.wh.wh.ExprEgal#getExprSimple2()
   * @see #getExprEgal()
   * @generated
   */
  EReference getExprEgal_ExprSimple2();

  /**
   * Returns the meta object for class '{@link me.qfdk.esir.wh.wh.ExprParent <em>Expr Parent</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Expr Parent</em>'.
   * @see me.qfdk.esir.wh.wh.ExprParent
   * @generated
   */
  EClass getExprParent();

  /**
   * Returns the meta object for the containment reference list '{@link me.qfdk.esir.wh.wh.ExprParent#getExpr <em>Expr</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Expr</em>'.
   * @see me.qfdk.esir.wh.wh.ExprParent#getExpr()
   * @see #getExprParent()
   * @generated
   */
  EReference getExprParent_Expr();

  /**
   * Returns the factory that creates the instances of the model.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the factory that creates the instances of the model.
   * @generated
   */
  WhFactory getWhFactory();

  /**
   * <!-- begin-user-doc -->
   * Defines literals for the meta objects that represent
   * <ul>
   *   <li>each class,</li>
   *   <li>each feature of each class,</li>
   *   <li>each enum,</li>
   *   <li>and each data type</li>
   * </ul>
   * <!-- end-user-doc -->
   * @generated
   */
  interface Literals
  {
    /**
     * The meta object literal for the '{@link me.qfdk.esir.wh.wh.impl.whImpl <em>wh</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see me.qfdk.esir.wh.wh.impl.whImpl
     * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getwh()
     * @generated
     */
    EClass WH = eINSTANCE.getwh();

    /**
     * The meta object literal for the '<em><b>Elements</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference WH__ELEMENTS = eINSTANCE.getwh_Elements();

    /**
     * The meta object literal for the '{@link me.qfdk.esir.wh.wh.impl.FunctionImpl <em>Function</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see me.qfdk.esir.wh.wh.impl.FunctionImpl
     * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getFunction()
     * @generated
     */
    EClass FUNCTION = eINSTANCE.getFunction();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute FUNCTION__NAME = eINSTANCE.getFunction_Name();

    /**
     * The meta object literal for the '<em><b>Def</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference FUNCTION__DEF = eINSTANCE.getFunction_Def();

    /**
     * The meta object literal for the '{@link me.qfdk.esir.wh.wh.impl.DefinitionImpl <em>Definition</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see me.qfdk.esir.wh.wh.impl.DefinitionImpl
     * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getDefinition()
     * @generated
     */
    EClass DEFINITION = eINSTANCE.getDefinition();

    /**
     * The meta object literal for the '<em><b>Entree</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference DEFINITION__ENTREE = eINSTANCE.getDefinition_Entree();

    /**
     * The meta object literal for the '<em><b>Cmd</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference DEFINITION__CMD = eINSTANCE.getDefinition_Cmd();

    /**
     * The meta object literal for the '<em><b>Sortie</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference DEFINITION__SORTIE = eINSTANCE.getDefinition_Sortie();

    /**
     * The meta object literal for the '{@link me.qfdk.esir.wh.wh.impl.InputImpl <em>Input</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see me.qfdk.esir.wh.wh.impl.InputImpl
     * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getInput()
     * @generated
     */
    EClass INPUT = eINSTANCE.getInput();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute INPUT__NAME = eINSTANCE.getInput_Name();

    /**
     * The meta object literal for the '<em><b>Entree</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference INPUT__ENTREE = eINSTANCE.getInput_Entree();

    /**
     * The meta object literal for the '{@link me.qfdk.esir.wh.wh.impl.OutputImpl <em>Output</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see me.qfdk.esir.wh.wh.impl.OutputImpl
     * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getOutput()
     * @generated
     */
    EClass OUTPUT = eINSTANCE.getOutput();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute OUTPUT__NAME = eINSTANCE.getOutput_Name();

    /**
     * The meta object literal for the '<em><b>Sortie</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference OUTPUT__SORTIE = eINSTANCE.getOutput_Sortie();

    /**
     * The meta object literal for the '{@link me.qfdk.esir.wh.wh.impl.CommandsImpl <em>Commands</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see me.qfdk.esir.wh.wh.impl.CommandsImpl
     * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getCommands()
     * @generated
     */
    EClass COMMANDS = eINSTANCE.getCommands();

    /**
     * The meta object literal for the '<em><b>Cmd1</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference COMMANDS__CMD1 = eINSTANCE.getCommands_Cmd1();

    /**
     * The meta object literal for the '<em><b>Cmd</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference COMMANDS__CMD = eINSTANCE.getCommands_Cmd();

    /**
     * The meta object literal for the '{@link me.qfdk.esir.wh.wh.impl.CommandImpl <em>Command</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see me.qfdk.esir.wh.wh.impl.CommandImpl
     * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getCommand()
     * @generated
     */
    EClass COMMAND = eINSTANCE.getCommand();

    /**
     * The meta object literal for the '<em><b>Nop</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute COMMAND__NOP = eINSTANCE.getCommand_Nop();

    /**
     * The meta object literal for the '<em><b>Affectation</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference COMMAND__AFFECTATION = eINSTANCE.getCommand_Affectation();

    /**
     * The meta object literal for the '<em><b>While Command</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference COMMAND__WHILE_COMMAND = eINSTANCE.getCommand_WhileCommand();

    /**
     * The meta object literal for the '<em><b>For Command</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference COMMAND__FOR_COMMAND = eINSTANCE.getCommand_ForCommand();

    /**
     * The meta object literal for the '<em><b>If Command</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference COMMAND__IF_COMMAND = eINSTANCE.getCommand_IfCommand();

    /**
     * The meta object literal for the '<em><b>Foreach Command</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference COMMAND__FOREACH_COMMAND = eINSTANCE.getCommand_ForeachCommand();

    /**
     * The meta object literal for the '{@link me.qfdk.esir.wh.wh.impl.affectationImpl <em>affectation</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see me.qfdk.esir.wh.wh.impl.affectationImpl
     * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getaffectation()
     * @generated
     */
    EClass AFFECTATION = eINSTANCE.getaffectation();

    /**
     * The meta object literal for the '<em><b>Vars</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference AFFECTATION__VARS = eINSTANCE.getaffectation_Vars();

    /**
     * The meta object literal for the '<em><b>Exprs</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference AFFECTATION__EXPRS = eINSTANCE.getaffectation_Exprs();

    /**
     * The meta object literal for the '{@link me.qfdk.esir.wh.wh.impl.whileCommandImpl <em>while Command</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see me.qfdk.esir.wh.wh.impl.whileCommandImpl
     * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getwhileCommand()
     * @generated
     */
    EClass WHILE_COMMAND = eINSTANCE.getwhileCommand();

    /**
     * The meta object literal for the '<em><b>Expr</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference WHILE_COMMAND__EXPR = eINSTANCE.getwhileCommand_Expr();

    /**
     * The meta object literal for the '<em><b>Cmd</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference WHILE_COMMAND__CMD = eINSTANCE.getwhileCommand_Cmd();

    /**
     * The meta object literal for the '{@link me.qfdk.esir.wh.wh.impl.forCommandImpl <em>for Command</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see me.qfdk.esir.wh.wh.impl.forCommandImpl
     * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getforCommand()
     * @generated
     */
    EClass FOR_COMMAND = eINSTANCE.getforCommand();

    /**
     * The meta object literal for the '<em><b>Expr</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference FOR_COMMAND__EXPR = eINSTANCE.getforCommand_Expr();

    /**
     * The meta object literal for the '<em><b>Cmd</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference FOR_COMMAND__CMD = eINSTANCE.getforCommand_Cmd();

    /**
     * The meta object literal for the '{@link me.qfdk.esir.wh.wh.impl.ifCommandImpl <em>if Command</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see me.qfdk.esir.wh.wh.impl.ifCommandImpl
     * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getifCommand()
     * @generated
     */
    EClass IF_COMMAND = eINSTANCE.getifCommand();

    /**
     * The meta object literal for the '<em><b>Expr</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference IF_COMMAND__EXPR = eINSTANCE.getifCommand_Expr();

    /**
     * The meta object literal for the '<em><b>Cmd1</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference IF_COMMAND__CMD1 = eINSTANCE.getifCommand_Cmd1();

    /**
     * The meta object literal for the '<em><b>Cmd2</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference IF_COMMAND__CMD2 = eINSTANCE.getifCommand_Cmd2();

    /**
     * The meta object literal for the '{@link me.qfdk.esir.wh.wh.impl.foreachCommandImpl <em>foreach Command</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see me.qfdk.esir.wh.wh.impl.foreachCommandImpl
     * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getforeachCommand()
     * @generated
     */
    EClass FOREACH_COMMAND = eINSTANCE.getforeachCommand();

    /**
     * The meta object literal for the '<em><b>Expr1</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference FOREACH_COMMAND__EXPR1 = eINSTANCE.getforeachCommand_Expr1();

    /**
     * The meta object literal for the '<em><b>Expr2</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference FOREACH_COMMAND__EXPR2 = eINSTANCE.getforeachCommand_Expr2();

    /**
     * The meta object literal for the '<em><b>Cmd</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference FOREACH_COMMAND__CMD = eINSTANCE.getforeachCommand_Cmd();

    /**
     * The meta object literal for the '{@link me.qfdk.esir.wh.wh.impl.VarsImpl <em>Vars</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see me.qfdk.esir.wh.wh.impl.VarsImpl
     * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getVars()
     * @generated
     */
    EClass VARS = eINSTANCE.getVars();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute VARS__NAME = eINSTANCE.getVars_Name();

    /**
     * The meta object literal for the '<em><b>Vars</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference VARS__VARS = eINSTANCE.getVars_Vars();

    /**
     * The meta object literal for the '{@link me.qfdk.esir.wh.wh.impl.ExprsImpl <em>Exprs</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see me.qfdk.esir.wh.wh.impl.ExprsImpl
     * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getExprs()
     * @generated
     */
    EClass EXPRS = eINSTANCE.getExprs();

    /**
     * The meta object literal for the '<em><b>Expr1</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference EXPRS__EXPR1 = eINSTANCE.getExprs_Expr1();

    /**
     * The meta object literal for the '<em><b>Expr</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference EXPRS__EXPR = eINSTANCE.getExprs_Expr();

    /**
     * The meta object literal for the '{@link me.qfdk.esir.wh.wh.impl.ExprImpl <em>Expr</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see me.qfdk.esir.wh.wh.impl.ExprImpl
     * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getExpr()
     * @generated
     */
    EClass EXPR = eINSTANCE.getExpr();

    /**
     * The meta object literal for the '<em><b>Expr Simple</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference EXPR__EXPR_SIMPLE = eINSTANCE.getExpr_ExprSimple();

    /**
     * The meta object literal for the '<em><b>Expr And</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference EXPR__EXPR_AND = eINSTANCE.getExpr_ExprAnd();

    /**
     * The meta object literal for the '{@link me.qfdk.esir.wh.wh.impl.ExprSimpleImpl <em>Expr Simple</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see me.qfdk.esir.wh.wh.impl.ExprSimpleImpl
     * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getExprSimple()
     * @generated
     */
    EClass EXPR_SIMPLE = eINSTANCE.getExprSimple();

    /**
     * The meta object literal for the '<em><b>Nil</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute EXPR_SIMPLE__NIL = eINSTANCE.getExprSimple_Nil();

    /**
     * The meta object literal for the '<em><b>Name1</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute EXPR_SIMPLE__NAME1 = eINSTANCE.getExprSimple_Name1();

    /**
     * The meta object literal for the '<em><b>Name2</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute EXPR_SIMPLE__NAME2 = eINSTANCE.getExprSimple_Name2();

    /**
     * The meta object literal for the '<em><b>Cons</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference EXPR_SIMPLE__CONS = eINSTANCE.getExprSimple_Cons();

    /**
     * The meta object literal for the '<em><b>List</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference EXPR_SIMPLE__LIST = eINSTANCE.getExprSimple_List();

    /**
     * The meta object literal for the '<em><b>Hd</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference EXPR_SIMPLE__HD = eINSTANCE.getExprSimple_Hd();

    /**
     * The meta object literal for the '<em><b>Tl</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference EXPR_SIMPLE__TL = eINSTANCE.getExprSimple_Tl();

    /**
     * The meta object literal for the '<em><b>Symb</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference EXPR_SIMPLE__SYMB = eINSTANCE.getExprSimple_Symb();

    /**
     * The meta object literal for the '{@link me.qfdk.esir.wh.wh.impl.consImpl <em>cons</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see me.qfdk.esir.wh.wh.impl.consImpl
     * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getcons()
     * @generated
     */
    EClass CONS = eINSTANCE.getcons();

    /**
     * The meta object literal for the '<em><b>Lexpr</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference CONS__LEXPR = eINSTANCE.getcons_Lexpr();

    /**
     * The meta object literal for the '{@link me.qfdk.esir.wh.wh.impl.listImpl <em>list</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see me.qfdk.esir.wh.wh.impl.listImpl
     * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getlist()
     * @generated
     */
    EClass LIST = eINSTANCE.getlist();

    /**
     * The meta object literal for the '<em><b>Lexpr</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference LIST__LEXPR = eINSTANCE.getlist_Lexpr();

    /**
     * The meta object literal for the '{@link me.qfdk.esir.wh.wh.impl.hdImpl <em>hd</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see me.qfdk.esir.wh.wh.impl.hdImpl
     * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#gethd()
     * @generated
     */
    EClass HD = eINSTANCE.gethd();

    /**
     * The meta object literal for the '<em><b>Expr</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference HD__EXPR = eINSTANCE.gethd_Expr();

    /**
     * The meta object literal for the '{@link me.qfdk.esir.wh.wh.impl.tlImpl <em>tl</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see me.qfdk.esir.wh.wh.impl.tlImpl
     * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#gettl()
     * @generated
     */
    EClass TL = eINSTANCE.gettl();

    /**
     * The meta object literal for the '<em><b>Expr</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference TL__EXPR = eINSTANCE.gettl_Expr();

    /**
     * The meta object literal for the '{@link me.qfdk.esir.wh.wh.impl.symbImpl <em>symb</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see me.qfdk.esir.wh.wh.impl.symbImpl
     * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getsymb()
     * @generated
     */
    EClass SYMB = eINSTANCE.getsymb();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute SYMB__NAME = eINSTANCE.getsymb_Name();

    /**
     * The meta object literal for the '<em><b>Lexpr</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference SYMB__LEXPR = eINSTANCE.getsymb_Lexpr();

    /**
     * The meta object literal for the '{@link me.qfdk.esir.wh.wh.impl.LexprImpl <em>Lexpr</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see me.qfdk.esir.wh.wh.impl.LexprImpl
     * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getLexpr()
     * @generated
     */
    EClass LEXPR = eINSTANCE.getLexpr();

    /**
     * The meta object literal for the '<em><b>Expr</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference LEXPR__EXPR = eINSTANCE.getLexpr_Expr();

    /**
     * The meta object literal for the '<em><b>Lexpr</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference LEXPR__LEXPR = eINSTANCE.getLexpr_Lexpr();

    /**
     * The meta object literal for the '{@link me.qfdk.esir.wh.wh.impl.ExprAndImpl <em>Expr And</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see me.qfdk.esir.wh.wh.impl.ExprAndImpl
     * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getExprAnd()
     * @generated
     */
    EClass EXPR_AND = eINSTANCE.getExprAnd();

    /**
     * The meta object literal for the '<em><b>Expr Or</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference EXPR_AND__EXPR_OR = eINSTANCE.getExprAnd_ExprOr();

    /**
     * The meta object literal for the '<em><b>Expr And</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference EXPR_AND__EXPR_AND = eINSTANCE.getExprAnd_ExprAnd();

    /**
     * The meta object literal for the '{@link me.qfdk.esir.wh.wh.impl.ExprOrImpl <em>Expr Or</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see me.qfdk.esir.wh.wh.impl.ExprOrImpl
     * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getExprOr()
     * @generated
     */
    EClass EXPR_OR = eINSTANCE.getExprOr();

    /**
     * The meta object literal for the '<em><b>Expr Not</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference EXPR_OR__EXPR_NOT = eINSTANCE.getExprOr_ExprNot();

    /**
     * The meta object literal for the '<em><b>Expr Or</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference EXPR_OR__EXPR_OR = eINSTANCE.getExprOr_ExprOr();

    /**
     * The meta object literal for the '{@link me.qfdk.esir.wh.wh.impl.ExprNotImpl <em>Expr Not</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see me.qfdk.esir.wh.wh.impl.ExprNotImpl
     * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getExprNot()
     * @generated
     */
    EClass EXPR_NOT = eINSTANCE.getExprNot();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute EXPR_NOT__NAME = eINSTANCE.getExprNot_Name();

    /**
     * The meta object literal for the '<em><b>Expr Eq</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference EXPR_NOT__EXPR_EQ = eINSTANCE.getExprNot_ExprEq();

    /**
     * The meta object literal for the '{@link me.qfdk.esir.wh.wh.impl.ExprEqImpl <em>Expr Eq</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see me.qfdk.esir.wh.wh.impl.ExprEqImpl
     * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getExprEq()
     * @generated
     */
    EClass EXPR_EQ = eINSTANCE.getExprEq();

    /**
     * The meta object literal for the '<em><b>Expr Egal</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference EXPR_EQ__EXPR_EGAL = eINSTANCE.getExprEq_ExprEgal();

    /**
     * The meta object literal for the '<em><b>Expr Parent</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference EXPR_EQ__EXPR_PARENT = eINSTANCE.getExprEq_ExprParent();

    /**
     * The meta object literal for the '{@link me.qfdk.esir.wh.wh.impl.ExprEgalImpl <em>Expr Egal</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see me.qfdk.esir.wh.wh.impl.ExprEgalImpl
     * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getExprEgal()
     * @generated
     */
    EClass EXPR_EGAL = eINSTANCE.getExprEgal();

    /**
     * The meta object literal for the '<em><b>Expr Simple1</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference EXPR_EGAL__EXPR_SIMPLE1 = eINSTANCE.getExprEgal_ExprSimple1();

    /**
     * The meta object literal for the '<em><b>Expr Simple2</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference EXPR_EGAL__EXPR_SIMPLE2 = eINSTANCE.getExprEgal_ExprSimple2();

    /**
     * The meta object literal for the '{@link me.qfdk.esir.wh.wh.impl.ExprParentImpl <em>Expr Parent</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see me.qfdk.esir.wh.wh.impl.ExprParentImpl
     * @see me.qfdk.esir.wh.wh.impl.WhPackageImpl#getExprParent()
     * @generated
     */
    EClass EXPR_PARENT = eINSTANCE.getExprParent();

    /**
     * The meta object literal for the '<em><b>Expr</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference EXPR_PARENT__EXPR = eINSTANCE.getExprParent_Expr();

  }

} //WhPackage
