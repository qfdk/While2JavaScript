/**
 */
package me.qfdk.esir.wh.wh;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>foreach Command</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link me.qfdk.esir.wh.wh.foreachCommand#getExpr1 <em>Expr1</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.foreachCommand#getExpr2 <em>Expr2</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.foreachCommand#getCmd <em>Cmd</em>}</li>
 * </ul>
 *
 * @see me.qfdk.esir.wh.wh.WhPackage#getforeachCommand()
 * @model
 * @generated
 */
public interface foreachCommand extends EObject
{
  /**
   * Returns the value of the '<em><b>Expr1</b></em>' containment reference list.
   * The list contents are of type {@link me.qfdk.esir.wh.wh.Expr}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Expr1</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Expr1</em>' containment reference list.
   * @see me.qfdk.esir.wh.wh.WhPackage#getforeachCommand_Expr1()
   * @model containment="true"
   * @generated
   */
  EList<Expr> getExpr1();

  /**
   * Returns the value of the '<em><b>Expr2</b></em>' containment reference list.
   * The list contents are of type {@link me.qfdk.esir.wh.wh.Expr}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Expr2</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Expr2</em>' containment reference list.
   * @see me.qfdk.esir.wh.wh.WhPackage#getforeachCommand_Expr2()
   * @model containment="true"
   * @generated
   */
  EList<Expr> getExpr2();

  /**
   * Returns the value of the '<em><b>Cmd</b></em>' containment reference list.
   * The list contents are of type {@link me.qfdk.esir.wh.wh.Commands}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Cmd</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Cmd</em>' containment reference list.
   * @see me.qfdk.esir.wh.wh.WhPackage#getforeachCommand_Cmd()
   * @model containment="true"
   * @generated
   */
  EList<Commands> getCmd();

} // foreachCommand
