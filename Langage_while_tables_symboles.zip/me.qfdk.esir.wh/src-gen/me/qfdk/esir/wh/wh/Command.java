/**
 */
package me.qfdk.esir.wh.wh;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Command</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link me.qfdk.esir.wh.wh.Command#getNop <em>Nop</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.Command#getAffectation <em>Affectation</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.Command#getWhileCommand <em>While Command</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.Command#getForCommand <em>For Command</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.Command#getIfCommand <em>If Command</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.Command#getForeachCommand <em>Foreach Command</em>}</li>
 * </ul>
 *
 * @see me.qfdk.esir.wh.wh.WhPackage#getCommand()
 * @model
 * @generated
 */
public interface Command extends EObject
{
  /**
   * Returns the value of the '<em><b>Nop</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Nop</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Nop</em>' attribute.
   * @see #setNop(String)
   * @see me.qfdk.esir.wh.wh.WhPackage#getCommand_Nop()
   * @model
   * @generated
   */
  String getNop();

  /**
   * Sets the value of the '{@link me.qfdk.esir.wh.wh.Command#getNop <em>Nop</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Nop</em>' attribute.
   * @see #getNop()
   * @generated
   */
  void setNop(String value);

  /**
   * Returns the value of the '<em><b>Affectation</b></em>' containment reference list.
   * The list contents are of type {@link me.qfdk.esir.wh.wh.affectation}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Affectation</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Affectation</em>' containment reference list.
   * @see me.qfdk.esir.wh.wh.WhPackage#getCommand_Affectation()
   * @model containment="true"
   * @generated
   */
  EList<affectation> getAffectation();

  /**
   * Returns the value of the '<em><b>While Command</b></em>' containment reference list.
   * The list contents are of type {@link me.qfdk.esir.wh.wh.whileCommand}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>While Command</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>While Command</em>' containment reference list.
   * @see me.qfdk.esir.wh.wh.WhPackage#getCommand_WhileCommand()
   * @model containment="true"
   * @generated
   */
  EList<whileCommand> getWhileCommand();

  /**
   * Returns the value of the '<em><b>For Command</b></em>' containment reference list.
   * The list contents are of type {@link me.qfdk.esir.wh.wh.forCommand}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>For Command</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>For Command</em>' containment reference list.
   * @see me.qfdk.esir.wh.wh.WhPackage#getCommand_ForCommand()
   * @model containment="true"
   * @generated
   */
  EList<forCommand> getForCommand();

  /**
   * Returns the value of the '<em><b>If Command</b></em>' containment reference list.
   * The list contents are of type {@link me.qfdk.esir.wh.wh.ifCommand}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>If Command</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>If Command</em>' containment reference list.
   * @see me.qfdk.esir.wh.wh.WhPackage#getCommand_IfCommand()
   * @model containment="true"
   * @generated
   */
  EList<ifCommand> getIfCommand();

  /**
   * Returns the value of the '<em><b>Foreach Command</b></em>' containment reference list.
   * The list contents are of type {@link me.qfdk.esir.wh.wh.foreachCommand}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Foreach Command</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Foreach Command</em>' containment reference list.
   * @see me.qfdk.esir.wh.wh.WhPackage#getCommand_ForeachCommand()
   * @model containment="true"
   * @generated
   */
  EList<foreachCommand> getForeachCommand();

} // Command
