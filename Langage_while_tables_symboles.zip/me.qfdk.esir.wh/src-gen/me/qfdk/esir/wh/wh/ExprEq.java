/**
 */
package me.qfdk.esir.wh.wh;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Expr Eq</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link me.qfdk.esir.wh.wh.ExprEq#getExprEgal <em>Expr Egal</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.ExprEq#getExprParent <em>Expr Parent</em>}</li>
 * </ul>
 *
 * @see me.qfdk.esir.wh.wh.WhPackage#getExprEq()
 * @model
 * @generated
 */
public interface ExprEq extends EObject
{
  /**
   * Returns the value of the '<em><b>Expr Egal</b></em>' containment reference list.
   * The list contents are of type {@link me.qfdk.esir.wh.wh.ExprEgal}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Expr Egal</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Expr Egal</em>' containment reference list.
   * @see me.qfdk.esir.wh.wh.WhPackage#getExprEq_ExprEgal()
   * @model containment="true"
   * @generated
   */
  EList<ExprEgal> getExprEgal();

  /**
   * Returns the value of the '<em><b>Expr Parent</b></em>' containment reference list.
   * The list contents are of type {@link me.qfdk.esir.wh.wh.ExprParent}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Expr Parent</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Expr Parent</em>' containment reference list.
   * @see me.qfdk.esir.wh.wh.WhPackage#getExprEq_ExprParent()
   * @model containment="true"
   * @generated
   */
  EList<ExprParent> getExprParent();

} // ExprEq
