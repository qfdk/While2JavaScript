/**
 */
package me.qfdk.esir.wh.wh;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>if Command</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link me.qfdk.esir.wh.wh.ifCommand#getExpr <em>Expr</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.ifCommand#getCmd1 <em>Cmd1</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.ifCommand#getCmd2 <em>Cmd2</em>}</li>
 * </ul>
 *
 * @see me.qfdk.esir.wh.wh.WhPackage#getifCommand()
 * @model
 * @generated
 */
public interface ifCommand extends EObject
{
  /**
   * Returns the value of the '<em><b>Expr</b></em>' containment reference list.
   * The list contents are of type {@link me.qfdk.esir.wh.wh.Expr}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Expr</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Expr</em>' containment reference list.
   * @see me.qfdk.esir.wh.wh.WhPackage#getifCommand_Expr()
   * @model containment="true"
   * @generated
   */
  EList<Expr> getExpr();

  /**
   * Returns the value of the '<em><b>Cmd1</b></em>' containment reference list.
   * The list contents are of type {@link me.qfdk.esir.wh.wh.Commands}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Cmd1</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Cmd1</em>' containment reference list.
   * @see me.qfdk.esir.wh.wh.WhPackage#getifCommand_Cmd1()
   * @model containment="true"
   * @generated
   */
  EList<Commands> getCmd1();

  /**
   * Returns the value of the '<em><b>Cmd2</b></em>' containment reference list.
   * The list contents are of type {@link me.qfdk.esir.wh.wh.Commands}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Cmd2</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Cmd2</em>' containment reference list.
   * @see me.qfdk.esir.wh.wh.WhPackage#getifCommand_Cmd2()
   * @model containment="true"
   * @generated
   */
  EList<Commands> getCmd2();

} // ifCommand
