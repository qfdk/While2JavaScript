/**
 */
package me.qfdk.esir.wh.wh;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>cons</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link me.qfdk.esir.wh.wh.cons#getLexpr <em>Lexpr</em>}</li>
 * </ul>
 *
 * @see me.qfdk.esir.wh.wh.WhPackage#getcons()
 * @model
 * @generated
 */
public interface cons extends EObject
{
  /**
   * Returns the value of the '<em><b>Lexpr</b></em>' containment reference list.
   * The list contents are of type {@link me.qfdk.esir.wh.wh.Lexpr}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Lexpr</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Lexpr</em>' containment reference list.
   * @see me.qfdk.esir.wh.wh.WhPackage#getcons_Lexpr()
   * @model containment="true"
   * @generated
   */
  EList<Lexpr> getLexpr();

} // cons
