/**
 */
package me.qfdk.esir.wh.wh.impl;

import java.util.Collection;

import me.qfdk.esir.wh.wh.Expr;
import me.qfdk.esir.wh.wh.ExprAnd;
import me.qfdk.esir.wh.wh.ExprSimple;
import me.qfdk.esir.wh.wh.WhPackage;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Expr</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link me.qfdk.esir.wh.wh.impl.ExprImpl#getExprSimple <em>Expr Simple</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.impl.ExprImpl#getExprAnd <em>Expr And</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ExprImpl extends MinimalEObjectImpl.Container implements Expr
{
  /**
   * The cached value of the '{@link #getExprSimple() <em>Expr Simple</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getExprSimple()
   * @generated
   * @ordered
   */
  protected EList<ExprSimple> exprSimple;

  /**
   * The cached value of the '{@link #getExprAnd() <em>Expr And</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getExprAnd()
   * @generated
   * @ordered
   */
  protected EList<ExprAnd> exprAnd;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected ExprImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return WhPackage.Literals.EXPR;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<ExprSimple> getExprSimple()
  {
    if (exprSimple == null)
    {
      exprSimple = new EObjectContainmentEList<ExprSimple>(ExprSimple.class, this, WhPackage.EXPR__EXPR_SIMPLE);
    }
    return exprSimple;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<ExprAnd> getExprAnd()
  {
    if (exprAnd == null)
    {
      exprAnd = new EObjectContainmentEList<ExprAnd>(ExprAnd.class, this, WhPackage.EXPR__EXPR_AND);
    }
    return exprAnd;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case WhPackage.EXPR__EXPR_SIMPLE:
        return ((InternalEList<?>)getExprSimple()).basicRemove(otherEnd, msgs);
      case WhPackage.EXPR__EXPR_AND:
        return ((InternalEList<?>)getExprAnd()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case WhPackage.EXPR__EXPR_SIMPLE:
        return getExprSimple();
      case WhPackage.EXPR__EXPR_AND:
        return getExprAnd();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case WhPackage.EXPR__EXPR_SIMPLE:
        getExprSimple().clear();
        getExprSimple().addAll((Collection<? extends ExprSimple>)newValue);
        return;
      case WhPackage.EXPR__EXPR_AND:
        getExprAnd().clear();
        getExprAnd().addAll((Collection<? extends ExprAnd>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case WhPackage.EXPR__EXPR_SIMPLE:
        getExprSimple().clear();
        return;
      case WhPackage.EXPR__EXPR_AND:
        getExprAnd().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case WhPackage.EXPR__EXPR_SIMPLE:
        return exprSimple != null && !exprSimple.isEmpty();
      case WhPackage.EXPR__EXPR_AND:
        return exprAnd != null && !exprAnd.isEmpty();
    }
    return super.eIsSet(featureID);
  }

} //ExprImpl
