/**
 */
package me.qfdk.esir.wh.wh;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Expr</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link me.qfdk.esir.wh.wh.Expr#getExprSimple <em>Expr Simple</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.Expr#getExprAnd <em>Expr And</em>}</li>
 * </ul>
 *
 * @see me.qfdk.esir.wh.wh.WhPackage#getExpr()
 * @model
 * @generated
 */
public interface Expr extends EObject
{
  /**
   * Returns the value of the '<em><b>Expr Simple</b></em>' containment reference list.
   * The list contents are of type {@link me.qfdk.esir.wh.wh.ExprSimple}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Expr Simple</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Expr Simple</em>' containment reference list.
   * @see me.qfdk.esir.wh.wh.WhPackage#getExpr_ExprSimple()
   * @model containment="true"
   * @generated
   */
  EList<ExprSimple> getExprSimple();

  /**
   * Returns the value of the '<em><b>Expr And</b></em>' containment reference list.
   * The list contents are of type {@link me.qfdk.esir.wh.wh.ExprAnd}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Expr And</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Expr And</em>' containment reference list.
   * @see me.qfdk.esir.wh.wh.WhPackage#getExpr_ExprAnd()
   * @model containment="true"
   * @generated
   */
  EList<ExprAnd> getExprAnd();

} // Expr
