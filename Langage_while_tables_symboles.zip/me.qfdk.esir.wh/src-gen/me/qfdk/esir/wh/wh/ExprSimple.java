/**
 */
package me.qfdk.esir.wh.wh;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Expr Simple</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link me.qfdk.esir.wh.wh.ExprSimple#getNil <em>Nil</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.ExprSimple#getName1 <em>Name1</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.ExprSimple#getName2 <em>Name2</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.ExprSimple#getCons <em>Cons</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.ExprSimple#getList <em>List</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.ExprSimple#getHd <em>Hd</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.ExprSimple#getTl <em>Tl</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.ExprSimple#getSymb <em>Symb</em>}</li>
 * </ul>
 *
 * @see me.qfdk.esir.wh.wh.WhPackage#getExprSimple()
 * @model
 * @generated
 */
public interface ExprSimple extends EObject
{
  /**
   * Returns the value of the '<em><b>Nil</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Nil</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Nil</em>' attribute.
   * @see #setNil(String)
   * @see me.qfdk.esir.wh.wh.WhPackage#getExprSimple_Nil()
   * @model
   * @generated
   */
  String getNil();

  /**
   * Sets the value of the '{@link me.qfdk.esir.wh.wh.ExprSimple#getNil <em>Nil</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Nil</em>' attribute.
   * @see #getNil()
   * @generated
   */
  void setNil(String value);

  /**
   * Returns the value of the '<em><b>Name1</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Name1</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Name1</em>' attribute.
   * @see #setName1(String)
   * @see me.qfdk.esir.wh.wh.WhPackage#getExprSimple_Name1()
   * @model
   * @generated
   */
  String getName1();

  /**
   * Sets the value of the '{@link me.qfdk.esir.wh.wh.ExprSimple#getName1 <em>Name1</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Name1</em>' attribute.
   * @see #getName1()
   * @generated
   */
  void setName1(String value);

  /**
   * Returns the value of the '<em><b>Name2</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Name2</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Name2</em>' attribute.
   * @see #setName2(String)
   * @see me.qfdk.esir.wh.wh.WhPackage#getExprSimple_Name2()
   * @model
   * @generated
   */
  String getName2();

  /**
   * Sets the value of the '{@link me.qfdk.esir.wh.wh.ExprSimple#getName2 <em>Name2</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Name2</em>' attribute.
   * @see #getName2()
   * @generated
   */
  void setName2(String value);

  /**
   * Returns the value of the '<em><b>Cons</b></em>' containment reference list.
   * The list contents are of type {@link me.qfdk.esir.wh.wh.cons}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Cons</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Cons</em>' containment reference list.
   * @see me.qfdk.esir.wh.wh.WhPackage#getExprSimple_Cons()
   * @model containment="true"
   * @generated
   */
  EList<cons> getCons();

  /**
   * Returns the value of the '<em><b>List</b></em>' containment reference list.
   * The list contents are of type {@link me.qfdk.esir.wh.wh.list}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>List</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>List</em>' containment reference list.
   * @see me.qfdk.esir.wh.wh.WhPackage#getExprSimple_List()
   * @model containment="true"
   * @generated
   */
  EList<list> getList();

  /**
   * Returns the value of the '<em><b>Hd</b></em>' containment reference list.
   * The list contents are of type {@link me.qfdk.esir.wh.wh.hd}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Hd</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Hd</em>' containment reference list.
   * @see me.qfdk.esir.wh.wh.WhPackage#getExprSimple_Hd()
   * @model containment="true"
   * @generated
   */
  EList<hd> getHd();

  /**
   * Returns the value of the '<em><b>Tl</b></em>' containment reference list.
   * The list contents are of type {@link me.qfdk.esir.wh.wh.tl}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Tl</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Tl</em>' containment reference list.
   * @see me.qfdk.esir.wh.wh.WhPackage#getExprSimple_Tl()
   * @model containment="true"
   * @generated
   */
  EList<tl> getTl();

  /**
   * Returns the value of the '<em><b>Symb</b></em>' containment reference list.
   * The list contents are of type {@link me.qfdk.esir.wh.wh.symb}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Symb</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Symb</em>' containment reference list.
   * @see me.qfdk.esir.wh.wh.WhPackage#getExprSimple_Symb()
   * @model containment="true"
   * @generated
   */
  EList<symb> getSymb();

} // ExprSimple
