/**
 */
package me.qfdk.esir.wh.wh.impl;

import java.util.Collection;

import me.qfdk.esir.wh.wh.Commands;
import me.qfdk.esir.wh.wh.Expr;
import me.qfdk.esir.wh.wh.WhPackage;
import me.qfdk.esir.wh.wh.foreachCommand;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>foreach Command</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link me.qfdk.esir.wh.wh.impl.foreachCommandImpl#getExpr1 <em>Expr1</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.impl.foreachCommandImpl#getExpr2 <em>Expr2</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.impl.foreachCommandImpl#getCmd <em>Cmd</em>}</li>
 * </ul>
 *
 * @generated
 */
public class foreachCommandImpl extends MinimalEObjectImpl.Container implements foreachCommand
{
  /**
   * The cached value of the '{@link #getExpr1() <em>Expr1</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getExpr1()
   * @generated
   * @ordered
   */
  protected EList<Expr> expr1;

  /**
   * The cached value of the '{@link #getExpr2() <em>Expr2</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getExpr2()
   * @generated
   * @ordered
   */
  protected EList<Expr> expr2;

  /**
   * The cached value of the '{@link #getCmd() <em>Cmd</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getCmd()
   * @generated
   * @ordered
   */
  protected EList<Commands> cmd;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected foreachCommandImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return WhPackage.Literals.FOREACH_COMMAND;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Expr> getExpr1()
  {
    if (expr1 == null)
    {
      expr1 = new EObjectContainmentEList<Expr>(Expr.class, this, WhPackage.FOREACH_COMMAND__EXPR1);
    }
    return expr1;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Expr> getExpr2()
  {
    if (expr2 == null)
    {
      expr2 = new EObjectContainmentEList<Expr>(Expr.class, this, WhPackage.FOREACH_COMMAND__EXPR2);
    }
    return expr2;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Commands> getCmd()
  {
    if (cmd == null)
    {
      cmd = new EObjectContainmentEList<Commands>(Commands.class, this, WhPackage.FOREACH_COMMAND__CMD);
    }
    return cmd;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case WhPackage.FOREACH_COMMAND__EXPR1:
        return ((InternalEList<?>)getExpr1()).basicRemove(otherEnd, msgs);
      case WhPackage.FOREACH_COMMAND__EXPR2:
        return ((InternalEList<?>)getExpr2()).basicRemove(otherEnd, msgs);
      case WhPackage.FOREACH_COMMAND__CMD:
        return ((InternalEList<?>)getCmd()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case WhPackage.FOREACH_COMMAND__EXPR1:
        return getExpr1();
      case WhPackage.FOREACH_COMMAND__EXPR2:
        return getExpr2();
      case WhPackage.FOREACH_COMMAND__CMD:
        return getCmd();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case WhPackage.FOREACH_COMMAND__EXPR1:
        getExpr1().clear();
        getExpr1().addAll((Collection<? extends Expr>)newValue);
        return;
      case WhPackage.FOREACH_COMMAND__EXPR2:
        getExpr2().clear();
        getExpr2().addAll((Collection<? extends Expr>)newValue);
        return;
      case WhPackage.FOREACH_COMMAND__CMD:
        getCmd().clear();
        getCmd().addAll((Collection<? extends Commands>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case WhPackage.FOREACH_COMMAND__EXPR1:
        getExpr1().clear();
        return;
      case WhPackage.FOREACH_COMMAND__EXPR2:
        getExpr2().clear();
        return;
      case WhPackage.FOREACH_COMMAND__CMD:
        getCmd().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case WhPackage.FOREACH_COMMAND__EXPR1:
        return expr1 != null && !expr1.isEmpty();
      case WhPackage.FOREACH_COMMAND__EXPR2:
        return expr2 != null && !expr2.isEmpty();
      case WhPackage.FOREACH_COMMAND__CMD:
        return cmd != null && !cmd.isEmpty();
    }
    return super.eIsSet(featureID);
  }

} //foreachCommandImpl
