/**
 */
package me.qfdk.esir.wh.wh;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Expr And</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link me.qfdk.esir.wh.wh.ExprAnd#getExprOr <em>Expr Or</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.ExprAnd#getExprAnd <em>Expr And</em>}</li>
 * </ul>
 *
 * @see me.qfdk.esir.wh.wh.WhPackage#getExprAnd()
 * @model
 * @generated
 */
public interface ExprAnd extends EObject
{
  /**
   * Returns the value of the '<em><b>Expr Or</b></em>' containment reference list.
   * The list contents are of type {@link me.qfdk.esir.wh.wh.ExprOr}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Expr Or</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Expr Or</em>' containment reference list.
   * @see me.qfdk.esir.wh.wh.WhPackage#getExprAnd_ExprOr()
   * @model containment="true"
   * @generated
   */
  EList<ExprOr> getExprOr();

  /**
   * Returns the value of the '<em><b>Expr And</b></em>' containment reference list.
   * The list contents are of type {@link me.qfdk.esir.wh.wh.ExprAnd}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Expr And</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Expr And</em>' containment reference list.
   * @see me.qfdk.esir.wh.wh.WhPackage#getExprAnd_ExprAnd()
   * @model containment="true"
   * @generated
   */
  EList<ExprAnd> getExprAnd();

} // ExprAnd
