/**
 */
package me.qfdk.esir.wh.wh.impl;

import java.util.Collection;

import me.qfdk.esir.wh.wh.Commands;
import me.qfdk.esir.wh.wh.Definition;
import me.qfdk.esir.wh.wh.Input;
import me.qfdk.esir.wh.wh.Output;
import me.qfdk.esir.wh.wh.WhPackage;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Definition</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link me.qfdk.esir.wh.wh.impl.DefinitionImpl#getEntree <em>Entree</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.impl.DefinitionImpl#getCmd <em>Cmd</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.impl.DefinitionImpl#getSortie <em>Sortie</em>}</li>
 * </ul>
 *
 * @generated
 */
public class DefinitionImpl extends MinimalEObjectImpl.Container implements Definition
{
  /**
   * The cached value of the '{@link #getEntree() <em>Entree</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getEntree()
   * @generated
   * @ordered
   */
  protected EList<Input> entree;

  /**
   * The cached value of the '{@link #getCmd() <em>Cmd</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getCmd()
   * @generated
   * @ordered
   */
  protected EList<Commands> cmd;

  /**
   * The cached value of the '{@link #getSortie() <em>Sortie</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getSortie()
   * @generated
   * @ordered
   */
  protected EList<Output> sortie;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected DefinitionImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return WhPackage.Literals.DEFINITION;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Input> getEntree()
  {
    if (entree == null)
    {
      entree = new EObjectContainmentEList<Input>(Input.class, this, WhPackage.DEFINITION__ENTREE);
    }
    return entree;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Commands> getCmd()
  {
    if (cmd == null)
    {
      cmd = new EObjectContainmentEList<Commands>(Commands.class, this, WhPackage.DEFINITION__CMD);
    }
    return cmd;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Output> getSortie()
  {
    if (sortie == null)
    {
      sortie = new EObjectContainmentEList<Output>(Output.class, this, WhPackage.DEFINITION__SORTIE);
    }
    return sortie;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case WhPackage.DEFINITION__ENTREE:
        return ((InternalEList<?>)getEntree()).basicRemove(otherEnd, msgs);
      case WhPackage.DEFINITION__CMD:
        return ((InternalEList<?>)getCmd()).basicRemove(otherEnd, msgs);
      case WhPackage.DEFINITION__SORTIE:
        return ((InternalEList<?>)getSortie()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case WhPackage.DEFINITION__ENTREE:
        return getEntree();
      case WhPackage.DEFINITION__CMD:
        return getCmd();
      case WhPackage.DEFINITION__SORTIE:
        return getSortie();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case WhPackage.DEFINITION__ENTREE:
        getEntree().clear();
        getEntree().addAll((Collection<? extends Input>)newValue);
        return;
      case WhPackage.DEFINITION__CMD:
        getCmd().clear();
        getCmd().addAll((Collection<? extends Commands>)newValue);
        return;
      case WhPackage.DEFINITION__SORTIE:
        getSortie().clear();
        getSortie().addAll((Collection<? extends Output>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case WhPackage.DEFINITION__ENTREE:
        getEntree().clear();
        return;
      case WhPackage.DEFINITION__CMD:
        getCmd().clear();
        return;
      case WhPackage.DEFINITION__SORTIE:
        getSortie().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case WhPackage.DEFINITION__ENTREE:
        return entree != null && !entree.isEmpty();
      case WhPackage.DEFINITION__CMD:
        return cmd != null && !cmd.isEmpty();
      case WhPackage.DEFINITION__SORTIE:
        return sortie != null && !sortie.isEmpty();
    }
    return super.eIsSet(featureID);
  }

} //DefinitionImpl
