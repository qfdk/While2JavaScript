/**
 */
package me.qfdk.esir.wh.wh;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Exprs</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link me.qfdk.esir.wh.wh.Exprs#getExpr1 <em>Expr1</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.Exprs#getExpr <em>Expr</em>}</li>
 * </ul>
 *
 * @see me.qfdk.esir.wh.wh.WhPackage#getExprs()
 * @model
 * @generated
 */
public interface Exprs extends EObject
{
  /**
   * Returns the value of the '<em><b>Expr1</b></em>' containment reference list.
   * The list contents are of type {@link me.qfdk.esir.wh.wh.Expr}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Expr1</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Expr1</em>' containment reference list.
   * @see me.qfdk.esir.wh.wh.WhPackage#getExprs_Expr1()
   * @model containment="true"
   * @generated
   */
  EList<Expr> getExpr1();

  /**
   * Returns the value of the '<em><b>Expr</b></em>' containment reference list.
   * The list contents are of type {@link me.qfdk.esir.wh.wh.Exprs}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Expr</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Expr</em>' containment reference list.
   * @see me.qfdk.esir.wh.wh.WhPackage#getExprs_Expr()
   * @model containment="true"
   * @generated
   */
  EList<Exprs> getExpr();

} // Exprs
