/**
 */
package me.qfdk.esir.wh.wh;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>list</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link me.qfdk.esir.wh.wh.list#getLexpr <em>Lexpr</em>}</li>
 * </ul>
 *
 * @see me.qfdk.esir.wh.wh.WhPackage#getlist()
 * @model
 * @generated
 */
public interface list extends EObject
{
  /**
   * Returns the value of the '<em><b>Lexpr</b></em>' containment reference list.
   * The list contents are of type {@link me.qfdk.esir.wh.wh.Lexpr}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Lexpr</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Lexpr</em>' containment reference list.
   * @see me.qfdk.esir.wh.wh.WhPackage#getlist_Lexpr()
   * @model containment="true"
   * @generated
   */
  EList<Lexpr> getLexpr();

} // list
