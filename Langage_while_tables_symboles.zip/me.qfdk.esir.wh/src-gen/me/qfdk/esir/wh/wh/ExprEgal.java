/**
 */
package me.qfdk.esir.wh.wh;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Expr Egal</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link me.qfdk.esir.wh.wh.ExprEgal#getExprSimple1 <em>Expr Simple1</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.ExprEgal#getExprSimple2 <em>Expr Simple2</em>}</li>
 * </ul>
 *
 * @see me.qfdk.esir.wh.wh.WhPackage#getExprEgal()
 * @model
 * @generated
 */
public interface ExprEgal extends EObject
{
  /**
   * Returns the value of the '<em><b>Expr Simple1</b></em>' containment reference list.
   * The list contents are of type {@link me.qfdk.esir.wh.wh.ExprSimple}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Expr Simple1</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Expr Simple1</em>' containment reference list.
   * @see me.qfdk.esir.wh.wh.WhPackage#getExprEgal_ExprSimple1()
   * @model containment="true"
   * @generated
   */
  EList<ExprSimple> getExprSimple1();

  /**
   * Returns the value of the '<em><b>Expr Simple2</b></em>' containment reference list.
   * The list contents are of type {@link me.qfdk.esir.wh.wh.ExprSimple}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Expr Simple2</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Expr Simple2</em>' containment reference list.
   * @see me.qfdk.esir.wh.wh.WhPackage#getExprEgal_ExprSimple2()
   * @model containment="true"
   * @generated
   */
  EList<ExprSimple> getExprSimple2();

} // ExprEgal
