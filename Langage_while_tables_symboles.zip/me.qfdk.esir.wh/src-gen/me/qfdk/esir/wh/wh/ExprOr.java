/**
 */
package me.qfdk.esir.wh.wh;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Expr Or</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link me.qfdk.esir.wh.wh.ExprOr#getExprNot <em>Expr Not</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.ExprOr#getExprOr <em>Expr Or</em>}</li>
 * </ul>
 *
 * @see me.qfdk.esir.wh.wh.WhPackage#getExprOr()
 * @model
 * @generated
 */
public interface ExprOr extends EObject
{
  /**
   * Returns the value of the '<em><b>Expr Not</b></em>' containment reference list.
   * The list contents are of type {@link me.qfdk.esir.wh.wh.ExprNot}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Expr Not</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Expr Not</em>' containment reference list.
   * @see me.qfdk.esir.wh.wh.WhPackage#getExprOr_ExprNot()
   * @model containment="true"
   * @generated
   */
  EList<ExprNot> getExprNot();

  /**
   * Returns the value of the '<em><b>Expr Or</b></em>' containment reference list.
   * The list contents are of type {@link me.qfdk.esir.wh.wh.ExprOr}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Expr Or</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Expr Or</em>' containment reference list.
   * @see me.qfdk.esir.wh.wh.WhPackage#getExprOr_ExprOr()
   * @model containment="true"
   * @generated
   */
  EList<ExprOr> getExprOr();

} // ExprOr
