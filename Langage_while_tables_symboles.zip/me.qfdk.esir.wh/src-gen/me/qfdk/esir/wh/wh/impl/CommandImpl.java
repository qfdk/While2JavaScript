/**
 */
package me.qfdk.esir.wh.wh.impl;

import java.util.Collection;

import me.qfdk.esir.wh.wh.Command;
import me.qfdk.esir.wh.wh.WhPackage;
import me.qfdk.esir.wh.wh.affectation;
import me.qfdk.esir.wh.wh.forCommand;
import me.qfdk.esir.wh.wh.foreachCommand;
import me.qfdk.esir.wh.wh.ifCommand;
import me.qfdk.esir.wh.wh.whileCommand;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Command</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link me.qfdk.esir.wh.wh.impl.CommandImpl#getNop <em>Nop</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.impl.CommandImpl#getAffectation <em>Affectation</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.impl.CommandImpl#getWhileCommand <em>While Command</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.impl.CommandImpl#getForCommand <em>For Command</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.impl.CommandImpl#getIfCommand <em>If Command</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.impl.CommandImpl#getForeachCommand <em>Foreach Command</em>}</li>
 * </ul>
 *
 * @generated
 */
public class CommandImpl extends MinimalEObjectImpl.Container implements Command
{
  /**
   * The default value of the '{@link #getNop() <em>Nop</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getNop()
   * @generated
   * @ordered
   */
  protected static final String NOP_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getNop() <em>Nop</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getNop()
   * @generated
   * @ordered
   */
  protected String nop = NOP_EDEFAULT;

  /**
   * The cached value of the '{@link #getAffectation() <em>Affectation</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getAffectation()
   * @generated
   * @ordered
   */
  protected EList<affectation> affectation;

  /**
   * The cached value of the '{@link #getWhileCommand() <em>While Command</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getWhileCommand()
   * @generated
   * @ordered
   */
  protected EList<whileCommand> whileCommand;

  /**
   * The cached value of the '{@link #getForCommand() <em>For Command</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getForCommand()
   * @generated
   * @ordered
   */
  protected EList<forCommand> forCommand;

  /**
   * The cached value of the '{@link #getIfCommand() <em>If Command</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getIfCommand()
   * @generated
   * @ordered
   */
  protected EList<ifCommand> ifCommand;

  /**
   * The cached value of the '{@link #getForeachCommand() <em>Foreach Command</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getForeachCommand()
   * @generated
   * @ordered
   */
  protected EList<foreachCommand> foreachCommand;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected CommandImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return WhPackage.Literals.COMMAND;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getNop()
  {
    return nop;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setNop(String newNop)
  {
    String oldNop = nop;
    nop = newNop;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, WhPackage.COMMAND__NOP, oldNop, nop));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<affectation> getAffectation()
  {
    if (affectation == null)
    {
      affectation = new EObjectContainmentEList<affectation>(affectation.class, this, WhPackage.COMMAND__AFFECTATION);
    }
    return affectation;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<whileCommand> getWhileCommand()
  {
    if (whileCommand == null)
    {
      whileCommand = new EObjectContainmentEList<whileCommand>(whileCommand.class, this, WhPackage.COMMAND__WHILE_COMMAND);
    }
    return whileCommand;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<forCommand> getForCommand()
  {
    if (forCommand == null)
    {
      forCommand = new EObjectContainmentEList<forCommand>(forCommand.class, this, WhPackage.COMMAND__FOR_COMMAND);
    }
    return forCommand;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<ifCommand> getIfCommand()
  {
    if (ifCommand == null)
    {
      ifCommand = new EObjectContainmentEList<ifCommand>(ifCommand.class, this, WhPackage.COMMAND__IF_COMMAND);
    }
    return ifCommand;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<foreachCommand> getForeachCommand()
  {
    if (foreachCommand == null)
    {
      foreachCommand = new EObjectContainmentEList<foreachCommand>(foreachCommand.class, this, WhPackage.COMMAND__FOREACH_COMMAND);
    }
    return foreachCommand;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case WhPackage.COMMAND__AFFECTATION:
        return ((InternalEList<?>)getAffectation()).basicRemove(otherEnd, msgs);
      case WhPackage.COMMAND__WHILE_COMMAND:
        return ((InternalEList<?>)getWhileCommand()).basicRemove(otherEnd, msgs);
      case WhPackage.COMMAND__FOR_COMMAND:
        return ((InternalEList<?>)getForCommand()).basicRemove(otherEnd, msgs);
      case WhPackage.COMMAND__IF_COMMAND:
        return ((InternalEList<?>)getIfCommand()).basicRemove(otherEnd, msgs);
      case WhPackage.COMMAND__FOREACH_COMMAND:
        return ((InternalEList<?>)getForeachCommand()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case WhPackage.COMMAND__NOP:
        return getNop();
      case WhPackage.COMMAND__AFFECTATION:
        return getAffectation();
      case WhPackage.COMMAND__WHILE_COMMAND:
        return getWhileCommand();
      case WhPackage.COMMAND__FOR_COMMAND:
        return getForCommand();
      case WhPackage.COMMAND__IF_COMMAND:
        return getIfCommand();
      case WhPackage.COMMAND__FOREACH_COMMAND:
        return getForeachCommand();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case WhPackage.COMMAND__NOP:
        setNop((String)newValue);
        return;
      case WhPackage.COMMAND__AFFECTATION:
        getAffectation().clear();
        getAffectation().addAll((Collection<? extends affectation>)newValue);
        return;
      case WhPackage.COMMAND__WHILE_COMMAND:
        getWhileCommand().clear();
        getWhileCommand().addAll((Collection<? extends whileCommand>)newValue);
        return;
      case WhPackage.COMMAND__FOR_COMMAND:
        getForCommand().clear();
        getForCommand().addAll((Collection<? extends forCommand>)newValue);
        return;
      case WhPackage.COMMAND__IF_COMMAND:
        getIfCommand().clear();
        getIfCommand().addAll((Collection<? extends ifCommand>)newValue);
        return;
      case WhPackage.COMMAND__FOREACH_COMMAND:
        getForeachCommand().clear();
        getForeachCommand().addAll((Collection<? extends foreachCommand>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case WhPackage.COMMAND__NOP:
        setNop(NOP_EDEFAULT);
        return;
      case WhPackage.COMMAND__AFFECTATION:
        getAffectation().clear();
        return;
      case WhPackage.COMMAND__WHILE_COMMAND:
        getWhileCommand().clear();
        return;
      case WhPackage.COMMAND__FOR_COMMAND:
        getForCommand().clear();
        return;
      case WhPackage.COMMAND__IF_COMMAND:
        getIfCommand().clear();
        return;
      case WhPackage.COMMAND__FOREACH_COMMAND:
        getForeachCommand().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case WhPackage.COMMAND__NOP:
        return NOP_EDEFAULT == null ? nop != null : !NOP_EDEFAULT.equals(nop);
      case WhPackage.COMMAND__AFFECTATION:
        return affectation != null && !affectation.isEmpty();
      case WhPackage.COMMAND__WHILE_COMMAND:
        return whileCommand != null && !whileCommand.isEmpty();
      case WhPackage.COMMAND__FOR_COMMAND:
        return forCommand != null && !forCommand.isEmpty();
      case WhPackage.COMMAND__IF_COMMAND:
        return ifCommand != null && !ifCommand.isEmpty();
      case WhPackage.COMMAND__FOREACH_COMMAND:
        return foreachCommand != null && !foreachCommand.isEmpty();
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (nop: ");
    result.append(nop);
    result.append(')');
    return result.toString();
  }

} //CommandImpl
