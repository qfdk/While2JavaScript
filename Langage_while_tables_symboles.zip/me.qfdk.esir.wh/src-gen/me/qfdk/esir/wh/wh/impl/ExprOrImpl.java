/**
 */
package me.qfdk.esir.wh.wh.impl;

import java.util.Collection;

import me.qfdk.esir.wh.wh.ExprNot;
import me.qfdk.esir.wh.wh.ExprOr;
import me.qfdk.esir.wh.wh.WhPackage;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Expr Or</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link me.qfdk.esir.wh.wh.impl.ExprOrImpl#getExprNot <em>Expr Not</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.impl.ExprOrImpl#getExprOr <em>Expr Or</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ExprOrImpl extends MinimalEObjectImpl.Container implements ExprOr
{
  /**
   * The cached value of the '{@link #getExprNot() <em>Expr Not</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getExprNot()
   * @generated
   * @ordered
   */
  protected EList<ExprNot> exprNot;

  /**
   * The cached value of the '{@link #getExprOr() <em>Expr Or</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getExprOr()
   * @generated
   * @ordered
   */
  protected EList<ExprOr> exprOr;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected ExprOrImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return WhPackage.Literals.EXPR_OR;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<ExprNot> getExprNot()
  {
    if (exprNot == null)
    {
      exprNot = new EObjectContainmentEList<ExprNot>(ExprNot.class, this, WhPackage.EXPR_OR__EXPR_NOT);
    }
    return exprNot;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<ExprOr> getExprOr()
  {
    if (exprOr == null)
    {
      exprOr = new EObjectContainmentEList<ExprOr>(ExprOr.class, this, WhPackage.EXPR_OR__EXPR_OR);
    }
    return exprOr;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case WhPackage.EXPR_OR__EXPR_NOT:
        return ((InternalEList<?>)getExprNot()).basicRemove(otherEnd, msgs);
      case WhPackage.EXPR_OR__EXPR_OR:
        return ((InternalEList<?>)getExprOr()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case WhPackage.EXPR_OR__EXPR_NOT:
        return getExprNot();
      case WhPackage.EXPR_OR__EXPR_OR:
        return getExprOr();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case WhPackage.EXPR_OR__EXPR_NOT:
        getExprNot().clear();
        getExprNot().addAll((Collection<? extends ExprNot>)newValue);
        return;
      case WhPackage.EXPR_OR__EXPR_OR:
        getExprOr().clear();
        getExprOr().addAll((Collection<? extends ExprOr>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case WhPackage.EXPR_OR__EXPR_NOT:
        getExprNot().clear();
        return;
      case WhPackage.EXPR_OR__EXPR_OR:
        getExprOr().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case WhPackage.EXPR_OR__EXPR_NOT:
        return exprNot != null && !exprNot.isEmpty();
      case WhPackage.EXPR_OR__EXPR_OR:
        return exprOr != null && !exprOr.isEmpty();
    }
    return super.eIsSet(featureID);
  }

} //ExprOrImpl
