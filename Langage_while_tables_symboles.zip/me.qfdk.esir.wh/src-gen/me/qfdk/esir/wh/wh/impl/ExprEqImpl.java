/**
 */
package me.qfdk.esir.wh.wh.impl;

import java.util.Collection;

import me.qfdk.esir.wh.wh.ExprEgal;
import me.qfdk.esir.wh.wh.ExprEq;
import me.qfdk.esir.wh.wh.ExprParent;
import me.qfdk.esir.wh.wh.WhPackage;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Expr Eq</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link me.qfdk.esir.wh.wh.impl.ExprEqImpl#getExprEgal <em>Expr Egal</em>}</li>
 *   <li>{@link me.qfdk.esir.wh.wh.impl.ExprEqImpl#getExprParent <em>Expr Parent</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ExprEqImpl extends MinimalEObjectImpl.Container implements ExprEq
{
  /**
   * The cached value of the '{@link #getExprEgal() <em>Expr Egal</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getExprEgal()
   * @generated
   * @ordered
   */
  protected EList<ExprEgal> exprEgal;

  /**
   * The cached value of the '{@link #getExprParent() <em>Expr Parent</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getExprParent()
   * @generated
   * @ordered
   */
  protected EList<ExprParent> exprParent;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected ExprEqImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return WhPackage.Literals.EXPR_EQ;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<ExprEgal> getExprEgal()
  {
    if (exprEgal == null)
    {
      exprEgal = new EObjectContainmentEList<ExprEgal>(ExprEgal.class, this, WhPackage.EXPR_EQ__EXPR_EGAL);
    }
    return exprEgal;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<ExprParent> getExprParent()
  {
    if (exprParent == null)
    {
      exprParent = new EObjectContainmentEList<ExprParent>(ExprParent.class, this, WhPackage.EXPR_EQ__EXPR_PARENT);
    }
    return exprParent;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case WhPackage.EXPR_EQ__EXPR_EGAL:
        return ((InternalEList<?>)getExprEgal()).basicRemove(otherEnd, msgs);
      case WhPackage.EXPR_EQ__EXPR_PARENT:
        return ((InternalEList<?>)getExprParent()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case WhPackage.EXPR_EQ__EXPR_EGAL:
        return getExprEgal();
      case WhPackage.EXPR_EQ__EXPR_PARENT:
        return getExprParent();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case WhPackage.EXPR_EQ__EXPR_EGAL:
        getExprEgal().clear();
        getExprEgal().addAll((Collection<? extends ExprEgal>)newValue);
        return;
      case WhPackage.EXPR_EQ__EXPR_PARENT:
        getExprParent().clear();
        getExprParent().addAll((Collection<? extends ExprParent>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case WhPackage.EXPR_EQ__EXPR_EGAL:
        getExprEgal().clear();
        return;
      case WhPackage.EXPR_EQ__EXPR_PARENT:
        getExprParent().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case WhPackage.EXPR_EQ__EXPR_EGAL:
        return exprEgal != null && !exprEgal.isEmpty();
      case WhPackage.EXPR_EQ__EXPR_PARENT:
        return exprParent != null && !exprParent.isEmpty();
    }
    return super.eIsSet(featureID);
  }

} //ExprEqImpl
